require('dotenv').load()
const Cloudant = require('@cloudant/cloudant')

//var url = process.env.cloudant_url

//var cloudant   = Cloudant("https://4e044d68-6793-44fc-b9e1-db81a691c2af-bluemix:ecdb8636d62807ce63d94f960f0435f267d76dcfcced693a6221c46278e12a72@4e044d68-6793-44fc-b9e1-db81a691c2af-bluemix.cloudant.com")

//var cloudant  = Cloudant(url)

var cloudant = Cloudant({account:process.env.cloudant_username, password:process.env.cloudant_password})

cloudant.db.list(function(err, allDbs) {
	
  if(err){
	  
	  console.log('Error has occured in the connection. Reason for failure : '+ err)
	  
  }else{
	  
      console.log('All my databases: %s', allDbs.join(', '))
  
  }
})
