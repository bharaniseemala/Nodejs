require('dotenv').load()

const Cloudant = require('@cloudant/cloudant')
const http     = require('http')
const url      = require('url')
const fs       = require('fs')

var cloudant   = Cloudant({ account: process.env.cloudant_username, password: process.env.cloudant_password}, function(err){
	
	if(err){
		console.log('Cloudant initialization is failed. Verify the configuration.')
	}else{
        console.log('Cloudent is now connected.')
	}

})

const server = http.createServer( (req,resp) => {
	
	var pathname = url.parse(req.url).pathname
	console.log(pathname.toLowerCase())
	if(pathname.toLowerCase() === '/signup'){

    console.log('.........')
	var queryparams = url.parse(req.url,true).query 
	console.log(JSON.stringify(queryparams))
	
	if( typeof queryparams.sname !== 'undefined' && typeof queryparams.cname !== 'undefined' && typeof queryparams.ename !== 'undefined' && typeof queryparams.psw !== 'undefined' && typeof queryparams.mob !== 'undefined'){
		
		if(queryparams.sname.toString().trim().length !== 0 && queryparams.cname.toString().trim().length !== 0 && queryparams.ename.toString().trim().length !== 0 && queryparams.psw.toString().trim().length !== 0 && queryparams.mob.toString().trim().length !== 0 ){
			
						
//			  cloudant.db.destroy('sellerdata', function(err){

//                   cloudant.db.create('sellerdata', function() {
   
                        var db = cloudant.db.use('sellerdata')
/*						var SellerName  = queryparams.sname.toString().trim()
						var CompanyName = queryparams.cname.toString().trim()
						var EmailID     = queryparams.ename.toString().trim()
						var MobileNo    = queryparams.mob.toString().trim()
						var Password    = queryparams.psw.toString().trim()
						var SellerID    = SellerName.substring(0,5) + MobileNo.substring(0,5)
						
                        db.insert({ "SellerID" : SellerID,"SellerName" : SellerName,"CompanyName" : CompanyName,"EmailID" : EmailID,"MobileNo" : MobileNo,"Password" : Password}, SellerID, function(err,body,header) {
        
		                     if(err){
		
		                           return console.log('[sellerdata.insert]', err.message)
			 
		                     }
		
		                     console.log('inserted connection successfully. Body : '+JSON.stringify(body))
		                     fs.readFile("../Api_Connect/public/SuccessfulReg.html", "UTF-8", function(err,html) {

                                    if(err){
                                    	console.log('unable to read reg.html')
                                    }
		                            resp.writeHead(200, { 'Content-Type': 'text/html'})
		                            resp.end(html)

	                          })

//		                     resp.writeHead(200, { 'Content-Type': 'text/html'})
//                             resp.end('<!DOCTYPE html><html><head><meta charset = "UTF-8"><meta name="viewport" content="width=device-width, initial-scale=1"><body><h3>You have successfully registered</h3></body></html>')
		

   
                       })


                   //............ creating individual params indexes for better&easy search options.....................//
                   

*/
 /*                       var index_names  = ['SellerID','SellerName','CompanyName','EmailID','MobileNo']

                        for(var ind=0; ind < index_names.length; ind++){ 
                            
                            
                        	var index_body = { name: index_names[ind]+'_index_name', type:'json', index:{fields:[index_names[ind]]}}
                        	console.log(index_names[ind]+'______'+index_body)
                            db.index(index_body, function(er, response) {
                            if (er) {
                                       throw er;
                             }

                            console.log('Index creation result: %s',index_names[ind]+' has status of '+ response.result);
                             })

                        }
*/
                        db.index( function(err,result) {

                        	 if(err){
                        	 	throw err
                        	 }

                        	 console.log('The database has %d indexes', result.indexes.length)

                        	 for(var i=0; i< result.indexes.length; i++) {

                                 console.log('  %s (%s): %j', result.indexes[i].name, result.indexes[i].type, result.indexes[i].def)

                        	 }

//                        	 result.should.have.a.property('indexes').which.is.an.Array
//                        	 done()
                        })

                        db.find({selector:{SellerID:'abcde91234', SellerName:'abcdef'}}, function(er, result) {
                             if (er) {
                                     throw er;
                              }

                        console.log('Found %d documents with name', result.docs.length);
                        for (var i = 0; i < result.docs.length; i++) {
                             console.log('  Doc id: %s', result.docs[i]._id);
                         }
                        })

//                   })	
	
//             })
//           resp.writeHead(200, { 'Content-Type': 'text/html'})
//            resp.end('<!DOCTYPE html><html><head><meta charset = "UTF-8"><meta name="viewport" content="width=device-width, initial-scale=1"><body><h3>You have successfully registered</h3></body></html>')
		
		}else{
			
			resp.writeHead(200, { 'Content-Type': 'text/html'})
		    resp.end('<!DOCTYPE html><html><head><meta charset = "UTF-8"><meta name="viewport" content="width=device-width, initial-scale=1"><body><h3>Ooopsy.........empty query params are received </h3></body></html>')

		}

	}else{
		
		resp.writeHead(200, { 'Content-Type': 'text/html'})
		resp.end('<!DOCTYPE html><html><head><meta charset = "UTF-8"><meta name="viewport" content="width=device-width, initial-scale=1"><body><h3>Ooopsy.........Query params are missing</h3></body></html>')

	}


	}else if(pathname.toLowerCase() === '/login'){


	}

    	
})

server.listen(8001,'localhost',function(){
	console.log('server is listening to 8001')
})
	



