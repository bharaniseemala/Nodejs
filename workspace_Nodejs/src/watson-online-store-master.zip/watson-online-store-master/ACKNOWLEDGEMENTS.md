# Acknowledgements

* Credit goes to [Josh Zheng](https://github.com/boxcarton) for his informative [blog](https://medium.com/ibm-watson-developer-cloud/build-a-chatbot-that-cares-part-1-d1c273e17a63)
* Credit goes to [Stef Sharp](https://github.com/sharpstef) for providing an awesome [example](https://github.com/sharpstef/watson-bot-starter)
* Credit goes to [Sunah Jang](https://github.com/hisunah) for providing Korean translations of [README.md](README_ko.md)
