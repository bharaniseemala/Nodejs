// ***************************************************** {COPYRIGHT-TOP} ***
//* Licensed Materials - Property of IBM
//* 5725-L30, 5725-Z22, 5725-Z63, 5725-U33
//*
//* (C) Copyright IBM Corporation 2016, 2017
//*
//* US Government Users Restricted Rights - Use, duplication, or
//* disclosure restricted by GSA ADP Schedule Contract with IBM Corp.
// ********************************************************** {COPYRIGHT-END}**
//
// Makes requests to the API /v1/catalogs/:id/managed-objects in an attempt to build a
// list of all managed-objects
//
// Returns managed-Objects
//
var apim = require('local:///isp/policy/apim.custom.js');
var apimutil = require('local:///isp/apim.util.js');
var headermeta = require('header-metadata');
var servicemeta = require('service-metadata');
var target = headermeta.current.get('X-Target-URL');
var catalogs = undefined;
var dbg = apim.verbose;
var managedObjectsDoc = undefined;
var uniqueCatalogs = undefined;
var allFetched = undefined;

// HEAD request - cache revalidation - return 200 OK
if (servicemeta.protocolMethod === 'HEAD') {
  servicemeta.mpgw.skipBackside = true;
  headermeta.response.statusCode = 200;
  return;
}

// Copy request headers:
headermeta.current.remove('X-Target-URL');
headermeta.current.remove('Host');

// ===========================================================================
// MAIN:
// - fetch /v1/catalogs
// ===========================================================================

// set defaults defined in GatewaysImpl.createDeployXml (GatewaysImpl.java)
var v1$catalog = target;

// use local://gwapi/deploy.xml values if provided
var deployInfo = apimutil.loadDeployInfo();

if (dbg) apim.console.debug('gateway-xml: fetching ' + v1$catalog);
apimutil.getDocument(v1$catalog, headermeta.current.headers, function (err, json) {
  catalogs = json || [ { 'error': err } ];
  apim.console.debug("Catalogs Before filtering->["+catalogs.length+"]");
  uniqueCatalogs = getUniqueCatalogEntries(catalogs);
  apim.console.debug("Catalogs After filtering->["+uniqueCatalogs.length+"]");
  allFetched = uniqueCatalogs.length;
  fetchMangedObjects_batch();

});

// Catalog fetch complete, create 'gateway.xml'
function done() {
  if (dbg) {
    apim.console.debug('managed-objects: done fetching ' + target);
    apim.console.debug('managed-objects: ' + JSON.stringify(managedObjectsDoc));
  }
  try {
    if (catalogs && catalogs[0] && catalogs[0].error) {
      session.output.write('<managed-objects><error>Error Fetching Managed-Objects</error></managed-objects>');
      throw catalogs[0].error;
    }
    else{
      session.output.write('<managed-objects><![CDATA[' + JSON.stringify(managedObjectsDoc) + ']]></managed-objects>');
    }
    servicemeta.mpgw.skipBackside = true;
    headermeta.current.set('Content-Type','application/json');
  }
  catch (error) {
    apim.console.error('managed-objects: failed to build: ' + JSON.stringify(managedObjectsDoc));
    if (error) apim.console.error('managed-objects: error: ' + error);
    servicemeta.mpgw.skipBackside = true;
    headermeta.response.statusCode = 500;
  }
}

// Batch - Request the managed objects in batches.
// Batch size is dependent on MAXBATCHSIZE
// Atmost MAXBATCHSIZE concurrent connections will be 
// made for each batch.

const MAXBATCHSIZE = 50;
function fetchMangedObjects_batch(){
  if (dbg) apim.console.debug("There are "+ allFetched + " unique Catalogs");
  managedObjectsDoc = {};
  if (allFetched === 0) {
    done();
  } else {
     fetchNextBatch();
  }
}

var batchCounter = 0;
var currentBatchIndex = 0;
function fetchNextBatch(){
  for ( ; uniqueCatalogs[currentBatchIndex] && batchCounter < MAXBATCHSIZE; currentBatchIndex++, batchCounter++){
    var currentCatalog = uniqueCatalogs[currentBatchIndex];
    var url = currentCatalog.url + "/managed-objects?type=edge-gateway";
    apimutil.getDocument(url, headermeta.current.headers, processData.bind({currentCatalog: currentCatalog}));
  }
}

function processData(err, managedObjects) {
  var currentCatalog = this.currentCatalog;
  var currentOrgID = currentCatalog.organization.id;
  if (err) {
    if (dbg) {
      apim.console.debug("Unable to retrieve Managed Objects for Catalog titled \""+currentCatalog.title+"\"")
      apim.console.debug(err);
    }
  }
  else {
    processManagedObjects(currentOrgID, managedObjects);
  }
  waitOnBatchCompletion();
}

function waitOnBatchCompletion(){
  batchCounter -= 1;
  allFetched -= 1;
  if ((allFetched === 0)){
    if (dbg) apim.console.debug("Managed Object Fetch Complete.");
    done();
  } else if (batchCounter === 0) {
    fetchNextBatch();
  }
}

//Get a list of unique Catalogs that have managed-objects Profiles
function getUniqueCatalogEntries(array) {
  var foundentry = [];
  var searchFor = undefined;
  var newArray = array.filter(tester);
  function tester(value, index, inputArray) {
    var hasManagedObjects = (value ? (value['managed-objects'] ? (value['managed-objects'].count > 0 ? true : false) : false) : false);
    if (value && value.organization && hasManagedObjects) {
      searchFor = value.organization.name + value.organization.id;
      if (foundentry.indexOf(searchFor) < 0) {
        foundentry.push(searchFor);
        return true;
      }
    }
    return false;
  }
  return newArray;
}

function processManagedObjects(currentOrgID, managedObjects){

  if (!managedObjects) return;
  var type = null;
  var version = null;
  var name = null;

  // Create a property named after the org
  managedObjectsDoc[currentOrgID] = {};
  
  for (var i = 0; i < managedObjects.length; i++){
    type = managedObjects[i].type;
    version = managedObjects[i].version;
    name = managedObjects[i].name;
    createIndices(currentOrgID, managedObjectsDoc, type, version, name, managedObjects[i]);
  }
}

function createIndices(currentOrgID, json, type, version, name, managedObject){
  if (!managedObject) return;
  
  if (!json[currentOrgID][type]) json[currentOrgID][type] = {};
  if (!json[currentOrgID][type]['by-id']) json[currentOrgID][type]['by-id'] = {};
  if (!json[currentOrgID][type]['by-name']) json[currentOrgID][type]['by-name'] = {};
  if (!json[currentOrgID][type]['by-nameAndVersion']) json[currentOrgID][type]['by-nameAndVersion'] = {};

  json[currentOrgID][type]['by-id'][managedObject.id] = name+':'+version;
  if (!json[currentOrgID][type]['by-name'][name]){
    json[currentOrgID][type]['by-name'][name] = [];
  }
  json[currentOrgID][type]['by-name'][name].push(name+':'+version);
  json[currentOrgID][type]['by-nameAndVersion'][name+':'+version] = managedObject;

}
