// ***************************************************** {COPYRIGHT-TOP} ***
//* Licensed Materials - Property of IBM
//* 5725-L30, 5725-Z22, 5725-Z63, 5725-U33
//*
//* (C) Copyright IBM Corporation 2016, 2017
//*
//* US Government Users Restricted Rights - Use, duplication, or
//* disclosure restricted by GSA ADP Schedule Contract with IBM Corp.
// ********************************************************** {COPYRIGHT-END}**
//
// Makes requests to the API /v1/catalogs in attempt to build the
// list of all catalogs
//
// Returns gateway.xml
//
var headermeta = require('header-metadata');
var servicemeta = require('service-metadata');
var apim = require('local:///isp/policy/apim.custom.js');
var apimutil = require('local:///isp/apim.util.js');
var deployInfo = apimutil.loadDeployInfo();

// Determine if we are fetching the new cloud-metadata API or a real ODCInfo XML file
var isOdcXml = deployInfo.gateway.xml.split(':')[0] !== 'catalog';

// Build /v1/catalog/cloud-metadata URI
var v1$catalog = isOdcXml ? deployInfo.gateway.xml : deployInfo.gateway.xml.substring(deployInfo.gateway.xml.indexOf(':'));
if (!isOdcXml) {
  v1$catalog = deployInfo.gateway.xml.substring(deployInfo.gateway.xml.indexOf(':')+1);
}
var v1$catalog$cloudmeta = v1$catalog + deployInfo.endpoints['cloud-metadata-suffix'];

//apim.console.debug('request.odcinfo: isXml' + isOdcXml);
//apim.console.debug('request.odcinfo: ' + v1$catalog$cloudmeta);

// Issue URL Open to retrieve cloud-metadata
var target = v1$catalog$cloudmeta + "?type=edge-gateway";
headermeta.current.remove('Host');
headermeta.current.set('X-Rule-Direction',isOdcXml ? 'odcinfo-xml' : 'odcinfo');
var headers = headermeta.current.headers;
if (isOdcXml) {
  apimutil.getDocumentAsBuffer(target, headers, fetchDocumentCallback);
}
else {
  apimutil.getDocument(target, headers, fetchDocumentCallback);
}


// Callback
function fetchDocumentCallback(error, response) {
  if (error) {
    apim.console.error('request.odcinfo: ' + error);
    done();
  }
  else if (isOdcXml) {
    finalWrite(response.toString());
  }
  else {
    done(response);
  }
}

// Reads the cloud metadata from Management server.
// SaaS Notes:
//   - SaaS does not use an external load balancer for analytics;
//   - Saas uses a different port number
function done(cloudMetadata) {
  var xml ='';
  xml += '<clusterData version="3.8.1.0">\n';
  xml += ' <cluster name="analytics-lb">\n';
  xml += '  <affinityMode value="null"/>\n';
  if (cloudMetadata) {
    var isSaaS = cloudMetadata['is-bluemix'];
    var anaCluster = cloudMetadata['analytics-clusters'][0];
    var port = isSaaS ? 443 : anaCluster.port;
    xml += '  <protocol type="http">\n';
    for (var i in anaCluster.servers) {
      if (anaCluster.servers.hasOwnProperty(i)) {
        var host = anaCluster.servers[i]['ip-address'];
        var stat = anaCluster.servers[i].status;
        if (stat === 'ACTIVE') {
          xml += '   <member weight="20" id="' + (i+1) + '" port="' + port + '" host="' + host + '"/>\n';
        }
      }
    }
    xml += '  </protocol>\n';
  }
  xml += ' </cluster>\n';
  xml += '</clusterData>\n';
  finalWrite(xml);
}

function finalWrite(data) {
  if (apim.verbose) {
    require('fs').writeFile('temporary:///odcinfo.xml', data, function(error){});
  }
  //apim.console.debug(data);
  session.output.write(data);
  servicemeta.mpgw.skipBackside = true;
  headermeta.current.set('Content-Type','application/xml');
}

