// ***************************************************** {COPYRIGHT-TOP} ***
//* Licensed Materials - Property of IBM
//* 5725-L30, 5725-Z22, 5725-Z63, 5725-U33
//*
//* (C) Copyright IBM Corporation 2016, 2017
//*
//* US Government Users Restricted Rights - Use, duplication, or
//* disclosure restricted by GSA ADP Schedule Contract with IBM Corp.
// ********************************************************** {COPYRIGHT-END}**
//
// Makes requests to the API /v1/catalogs in attempt to build the
// services.xml file required by DataPower.
//
var apim = require('local:///isp/policy/apim.custom.js');
var apimutil = require('local:///isp/apim.util.js');
var headermeta = require('header-metadata');
var servicemeta = require('service-metadata');
//var swaggerUtil = require('local:///isp/request.swagger.util.js');
var jsonx = require('local:///isp/policy/json2jsonx.js');
var mfpProvidersManager = require('local:///isp/policy/mobileFirst/mfp-providers-manager.js');
var mfpProviders  = undefined;

var fs = require('fs');
var products = undefined;
var subscriptions = undefined;
var apis = undefined;
var apisHead = undefined;
var registries = undefined;
var addQSTestApp = false;
var dbg = apim.verbose;

var verbose = apim.verbose;

// HEAD request - cache revalidation - return 200 OK
if (servicemeta.protocolMethod === 'HEAD') {
  servicemeta.mpgw.skipBackside = true;
  headermeta.response.statusCode = 200;
  return;
}

var target = headermeta.current.get('X-Target-URL');
var save2disk = headermeta.current.get('X-Save-To-Disk');
headermeta.current.remove('X-Target-URL');
headermeta.current.remove('X-Save-To-Disk');
headermeta.current.remove('Host');

var headers = headermeta.current.headers;

// MAIN:
// - fetch /registries
// - fetch /products
// - fetch /subscriptions
// - fetch /apis (swagger)
// using the proper configured endpoints
var deployInfo = apimutil.loadDeployInfo();
var clusterId = 'id:onpremi:cluster';  // just set the default to that used in onpremi tests
var productsURL = target + '/missing/deploy/info';
var subscriptionsURL = target + '/missing/deploy/info';
var swaggerURL = target + '/missing/deploy/info';
var registriesURL = target + "/registries";
var mpgw_ip = deployInfo.endpoints['loopback-ip'];
var mpgw_port = parseInt(deployInfo.endpoints['base-port']) + 1;
var mpgw_internal = "http://" + mpgw_ip + ":" + mpgw_port + "/";
var postfix = '?type=edge-gateway';
var internalPort = deployInfo ? parseInt(deployInfo.endpoints['base-port']) + 1 : 2444;
if (deployInfo) {
  productsURL = target + deployInfo.endpoints['products-suffix'] + postfix;
  subscriptionsURL = target + deployInfo.endpoints['subscriptions-suffix'] + postfix;
  swaggerURL = target + deployInfo.endpoints['swagger-suffix'] + postfix;
  registriesURL += postfix;
  if (deployInfo.gateway && deployInfo.gateway['cluster-id']) {
      clusterId = deployInfo.gateway['cluster-id'];
  }
}

apimutil.getDocument(productsURL, headers, function (err, json) {
  products = json || { 'error': err };
  apimutil.getDocument(subscriptionsURL, headers, function (err, json) {
    subscriptions = json || { 'error': err };
    apimutil.getDocument(registriesURL, headers, function (err, json) {
      registries = json || { 'error': err };
      apimutil.getDocument(swaggerURL, headers, function (err, json) {
        if (json) {
            if(json.length > 0 && json[0].catalog)
                mfpProvidersManager.loadMfpProivders(json[0].catalog, headers, function(error, mfpProvidersResponse){
                    if(error){
                        // Continue in the regular flow although the error
                        apim.console.error("Failed to read MobileFirst providers list");
                    }

                    mfpProviders = mfpProvidersResponse;

                    apis = json;
                    addQSTestApp = !apis[0] ? false :
                        !apis[0]['catalog'] ? false :
                        apis[0]['catalog']['test-app-enabled'] === true ? true : false
                    done();
                });
            else {
                apis = { 'error': err };
                done();
            }
        }
          else {
              apis = { 'error': err };
              done();
          }
      });
    });
  });
});

// fetch all APIs
var apiIndex = [];
function fetchAllApis(index) {
  if (! apisHead[index]) {
    addQSTestApp = !apis[0] ? false :
                   !apis[0]['catalog'] ? false :
                   apis[0]['catalog']['test-app-enabled'] === true ? true : false
    done();
  }
  else {
    apiIndex.push(index);
    apimutil.getDocument(apisHead[index].url + postfix, headers, function(err, json) {
      var index = apiIndex.pop();
      if (json) {
        apis[index] = apisHead[index];
        if (json.document && json.document.info) {
          apis[index].document = json.document;
          if (json.spaces && json.spaces.length >= 1) {
            apis[index].spaces = json.spaces;
          }
        }
        else if (json.info) {
          apis[index].document = json; //TODO remove after fixing all APIs in regression.sh
        }
        else {
          apim.console.error('request.services: failed to retrieve API (1):' + apisHead[index].url);
          apis[index] = apisHead[index];
          apis[index].document = { 'error': 'no info section' };
        }
      }
      else {
        apim.console.error('request.services: failed to retrieve API (2):' + apisHead[index].url);
        apis[index] = apisHead[index];
        apis[index].document = { 'error': err };
      }
      fetchAllApis(index+1);
    });
  }
}

function findGWServiceForCluster() {
    var gwService;
    if (products && products[0] && products[0].catalog && products[0].catalog['gw-services']) {
        for (var j = 0; j < products[0].catalog['gw-services'].length; j++) {
            var catGWService = products[0].catalog['gw-services'][j];
            if (catGWService.id === clusterId) {
                gwService = catGWService;
            }
        }
    }
    return gwService;
}

// done - all files retrieved, build and return the XML
function done() {
  var validresponse = false;
  var xml;
  if (dbg) apim.console.debug('req.services: build services.xml for ' + target);

  xml = '<tenants>\n';
  if (products.error)
    xml += ' <error name="products">' + products.error + '</error>\n';
  else if (subscriptions.error)
    xml += ' <error name="subscriptions">' + subscriptions.error + '</error>\n';
  else if (apis.error)
    xml += ' <error name="apis">' + apis.error + '</error>\n';
  else if (!products || !products[0]) {
    // this is not an error... just means this organization does not have any products
    // published (and in turn no APIs). Consider it a valid response.
    xml += ' <message>products not found</message>\n';
    if (dbg) apim.console.debug('services.xml - no products');
    validresponse = true;
  }
  else {
    try {
      var gwService = findGWServiceForCluster();
      var orgId = ' orgId="' + products[0].organization.id;
      var orgName = '" orgName="' + apimutil.escapeXML(products[0].organization.name);
      var orgTitle = '" orgTitle="' + apimutil.escapeXML(products[0].organization.title);
      var catId = '" envId="' + products[0].catalog.id;
      var catName = '" envName="' + apimutil.escapeXML(products[0].catalog.name);
      var catTitle = '" envTitle="' + apimutil.escapeXML(products[0].catalog.title);
      var catActv = '" active="1';
      var catCustomGWURL = '';
      if (gwService && gwService['endpoint-url'] !== undefined && gwService['endpoint-url'].length > 0) {
          catCustomGWURL = '" customGWURL="' + apimutil.escapeXML(gwService['endpoint-url']);
      }
      var isSpacesEnabled = '" spaces-enabled="' + (products[0].catalog['space-enabled'] !== undefined ? products[0].catalog['space-enabled'].toString() : 'false');
      xml += ' <tenant' + orgId + orgName + orgTitle + catId + catName + catTitle + catActv + catCustomGWURL + isSpacesEnabled + '">\n';
      try {
        xml += plans('    ');
        xml += apisAsXml('   ');
        xml += consumers('   ');
        xml += processRegistries('   ');
        xml += ' </tenant>\n';
        validresponse = true;
      }
      catch (error) {
        xml += ' </tenant>\n';
        throw error;
      }
    }
    catch (error) {
      apim.console.error(error.stack);
      apim.console.error('request.services: ' + target + ': ' + error);
    }
  }
  xml += '</tenants>\n';
  servicemeta.mpgw.skipBackside = true;
  if (validresponse) {
    session.output.write(xml);
    headermeta.current.set('Content-Type', 'application/xml');
  }
  else {
    headermeta.response.statusCode = 500;
  }
  if (save2disk && save2disk.length > 0) {
    fs.writeFile ('temporary:' + save2disk + '.xml',xml, function(error) {});
  }
}

// **********************************************************
// PRODUCE THE XML
// **********************************************************
var productDoc = undefined;
var productIdVer = undefined;
var productId = undefined;

function plans(indent) {
  var xml = indent + '<plans>\n';
  for (var i = 0; i < products.length; i++) {
    productDoc = products[i].document;
    productIdVer = productDoc.info.name + ':' + productDoc.info.version;
    productId = products[i].id;
    for (var planName in productDoc.plans) {
      if (productDoc.plans.hasOwnProperty(planName)) {
        xml += plan(indent + ' ', products[i], planName);
      }
    }
  }
  if (addQSTestApp){
    xml += addQuickStartPlan(indent)
  }
  xml += indent + '</plans>\n';
  return xml;
}

function plan(indent, product, planName) {
  if (dbg) apim.console.debug('req.services: plan(): ' + productIdVer + ': ' + planName);
  var xml;
  var prodId = productIdVer;
  var planId = apimutil.escapeXML(prodId) + ':' + apimutil.escapeXML(planName);
  var planVer = apimutil.escapeXML(product.document.info.version);
  var planObj = product.document.plans[planName];
  var planRateLimit = getRateLimit(planObj);
  var planBillingModel = getBillingModel(planObj);
  xml = indent + '<plan id="' + planId + '" name="' + apimutil.escapeXML(planName) + '" version="' + planVer;
  xml += '" productId="' + productId;
  xml += '">\n';

  if (planBillingModel != undefined)
  {
    var billingmodel = indent + ' <billing-model ';
    billingmodel += 'provider="' + planBillingModel["provider"] + '" ';
    billingmodel += 'model="' + planBillingModel["model"] + '" ';
    billingmodel += 'currency="' + planBillingModel["currency"] + '" ';
    billingmodel += 'amount="' + planBillingModel["amount"] + '" ';
    billingmodel += 'trial-period-days="' + planBillingModel["trial-period-days"] + '" />\n';
    xml += billingmodel;
  }

  // Add Burst Limits here, if any.
  if (planObj['burst-limits']) {
    var burstlimits = indent + ' <burst-limits>\n';
    var ratesArray = planObj['burst-limits'];
    var p = Object.keys(ratesArray);
    var count = 0;  // counter to track how many non-'unlimited' limits are present

    // max number of burst-limit policies is 4.
    for (var i = 0; i < p.length && count < 4; i++)
    {
      // filter out any "unlimited" limits
      if (ratesArray[p[i]].value !== "unlimited") {
        count++;
        burstlimits += indent + '  <burst-limit name="' + apimutil.escapeXML(p[i]) + '" value="' + ratesArray[p[i]].value + '" hard-limit="true"/>\n';
      }
    }
    burstlimits += indent + ' </burst-limits>\n';

    if (count > 0) {
      xml += burstlimits;
    }
  }

  // Add the Multiple rate limits here, if any.
  if (planObj['rate-limits'] || (planRateLimit && planRateLimit.value)) {
    var ratelimits = indent + ' <rate-limits>\n';
    var ratesArray = planObj['rate-limits'];
    if (planRateLimit && planRateLimit.value) {
        if (ratesArray===undefined) {
            ratesArray={};
            ratesArray['rate-limit']=planRateLimit;
        }
    }
    var p = Object.keys(ratesArray);
    p.sort(function(a, b) {
      var parsedA = getInterval(ratesArray[a].value);
      var parsedB = getInterval(ratesArray[b].value);
      return parsedA.interval === parsedB.interval ? parsedA.limit - parsedB.limit :
                                                     parsedA.interval - parsedB.interval;
    });
    var count = 0;  // counter to track how many non-'unlimited' limits are present

    // max number of rate-limit policies is 7
    for (var i = 0; i < p.length && count < 7; i++)
    {
      // filter out any "unlimited" limits
      if (ratesArray[p[i]].value !== "unlimited") {
        count++;
        ratelimits += indent + '  <rate-limit name="' + apimutil.escapeXML(p[i]) + '" value="' + ratesArray[p[i]].value + '" hard-limit="' + ratesArray[p[i]]["hard-limit"] + '" />\n';
      }
    }
    ratelimits += indent + ' </rate-limits>\n';

    if (count > 0) {
      xml += ratelimits;
    }
  }

  xml += resourcesInPlanAsXML(indent + ' ', planObj.apis);
  xml += indent + '</plan>\n';
  return xml;
}

function getInterval(unparsed) {
  var secs=3600, limit=1;
  if (typeof unparsed === 'string') {
    /*
     * The value can be one of the following formats
     * 100 ==> 100/1hour
     * 100/1 ==> 100/1hour
     * 100/1/hour ==> 100/1hour
     * Spaces are ignored
     */
    var parts;
    if (unparsed.toUpperCase() === 'UNLIMITED') {
      parts = [unparsed, 1, Number.MAX_SAFE_INTEGER, 'seconds'];
    } else {
      var pattern = /^([\d\s]+)(?:\/([\d\s]*)([a-zA-Z\s]*))?$/;
      parts = pattern.exec(unparsed);
    }
    //assert(parts, 'Rate limit value is invalid: ' + unparsed);
    limit = Number(parts[1]);
    var period = Number(parts[2]) || 1;
    var unit = (parts[3] || 'hour').trim();

    // Calculate duration of units
    var unitInSec;
    switch (unit) {
      case 'm':
      case 'min':
      case 'mins':
      case 'minute':
      case 'minutes':
        unitInSec = 60;
        break;
      case 's':
      case 'sec':
      case 'secs':
      case 'second':
      case 'seconds':
        unitInSec = 1;
        break;
      case 'h':
      case 'hr':
      case 'hrs':
      case 'hour':
      case 'hours':
        unitInSec = 3600;
        break;
      case 'd':
      case 'day':
      case 'days':
        unitInSec = 86400;
        break;
      case 'w':
      case 'wk':
      case 'wks':
      case 'week':
      case 'weeks':
        unitInSec = 604800;
        break;
      default:
        unitInSec = 3600;
        break;
    }
    secs = unitInSec * period;
  }
  return {"limit": limit, "interval": secs};
}

// ********************************************
// Read property 'rate-limit' from provided object
function getRateLimit(planOrOperation) {
  if (planOrOperation['rate-limit']) {
    return {
      'hard-limit' : planOrOperation['rate-limit']['hard-limit'],
      'value' : planOrOperation['rate-limit'].value
    }
  }
}

// ********************************************
// Read property 'billing-model' from provided object
function getBillingModel(planOrOperation) {
  if (planOrOperation['billing-model']) {
    return {
      'provider' : planOrOperation['billing-model']['provider'],
      'model' : planOrOperation['billing-model']['model'],
      'currency' : planOrOperation['billing-model']['currency'],
      'amount' : planOrOperation['billing-model']['amount'],
      'trial-period-days' : planOrOperation['billing-model']['trial-period-days']
    }
  }
}


// ********************************************
// Produces a plan containing all resources in
// the catalog to be used by the quickstart app

function addQuickStartPlan(indent){
  var xml = indent + '<plan id="__INTERNAL_QS__:1.0.0:default" name="default" version="1.0.0" productId="__INTERNAL_QS__">';
  xml += indent + '  ' + '<resources>';
  for (var i = 0; i < apis.length; i++) {
    xml += foreachOperationInAPI(indent, apis[i], function (indent, api, verb, path, operationObj) {
      var id = ' id="' + [apimutil.escapeXML(api.document.info['x-ibm-name']), apimutil.escapeXML(api.document.info.version), verb, apimutil.escapeXML(path)].join(':') + '"';
      var version = ' version="' + apimutil.escapeXML(api.document.info.version) + '"';
      return indent + '    ' +  '<resource' + id + version + '/>\n';
    });
  }
    xml += indent + '  ' + '</resources>';
    xml += indent + '</plan>';
  return xml;
}

// ********************************************
// Produce the list of resources of services.xml
// <resources>
//   <resource ... />
// </resources>
function resourcesInPlanAsXML(indent, plan$apis) {
  var xml;
  xml = indent + '<resources>\n';
  // check if product.plans.<plan>.apis is emtpy or undefined
  // is to be considered to be the same as selecting *all* APIs
  if (plan$apis === undefined || Object.keys(plan$apis).length === 0) {
    plan$apis = {};
    for (var i in productDoc.apis) {
      if (productDoc.apis.hasOwnProperty(i)) {
        plan$apis[i] = {};
      }
    }
  }
  for (var i in plan$apis) {
    if (plan$apis.hasOwnProperty(i)) {
      xml += resourceInPlanAsXML(indent + ' ', plan$apis, i);
    }
  }
  xml += indent + '</resources>\n';
  return xml;
}


function resourceInPlanAsXML(indent, plan$apis, index) {
  if (dbg) apim.console.debug('req.services: ' + productIdVer + ':resInPlan: ' + index + ' = ' + JSON.stringify(plan$apis[index]));
  var xml = '';
  // look up operations to add to this plan
  if (plan$apis[index].$ref) {
    // TODO remove - old schema, add all APIS for this schema
    // plans[planname].apis[index].$ref = "apiname:apiversion"
    var apiInfo = plan$apis[index].$ref.split(':');
    for (var i = 0; i < apis.length; i++) {
      if (apis[i].document.info['x-ibm-name'] === apiInfo[0] && apis[i].document.info.version === apiInfo[1]) {
        xml += foreachOperationInAPI(indent, apis[i], function (indent, api, verb, path, operationObj) {
          var id = ' id="' + [apimutil.escapeXML(api.document.info['x-ibm-name']), apimutil.escapeXML(api.document.info.version), verb, apimutil.escapeXML(path)].join(':') + '"';
          var version = ' version="' + apimutil.escapeXML(api.document.info.version) + '"';
          return indent + '<resource' + id + version + '/>\n';
        });
        break;
      }
    }
  }
  else if (isEmpty(plan$apis[index])) {
    // ** plans[planname].apis[apiname] = {}
    // indicates all operations for this api
    // locate the actual API reference that corresponds to apiname
    var apiname = index;
    if (! productDoc.apis[apiname]) {
      apim.console.error('request.services: ' + productIdVer + ':' + apiname + ' is not defined in this product!');
    } else {
    var apiInfo;
    if (productDoc.apis[apiname].name!==undefined) {
      apiInfo = productDoc.apis[apiname].name.split(':');
    } else {
        if (productDoc.apis[apiname].$ref!==undefined) {
          apiInfo = productDoc.apis[apiname].$ref.split(':');
        } else {
            if (dbg) apim.console.debug('request.services: unable to determine api name from: '+JSON.stringify(productDoc.apis[apiname]));
        }
     }
     for (var i = 0; i < apis.length; i++) {
      if (apis[i].document.error) {
        if (dbg) apim.console.debug('request.services: resInPlanAsXml skipped: ' + apis[i].url + ' reason:' + apis[i].document.error);
      }
      else if (apiInfo!==undefined && apis[i].document.info['x-ibm-name'] === apiInfo[0] && apis[i].document.info.version === apiInfo[1]) {
        xml += foreachOperationInAPI(indent, apis[i], function (indent, api, verb, path, operationObj) {
          var id = ' id="' + [apimutil.escapeXML(api.document.info['x-ibm-name']), apimutil.escapeXML(api.document.info.version), verb, apimutil.escapeXML(path)].join(':') + '"';
          var version = ' version="' + apimutil.escapeXML(api.document.info.version) + '"';
          return indent + '<resource' + id + version + '/>\n';
        });
        break;
      }
     }
    }
  }
  else if (plan$apis[index].operations) {
    // plan allows only a subset of operations of this API
    // ** plans[planname].apis[apiname] = {
    //      "operations": [
    //        { "operationId": "api02op01" },
    //        { "operation": "POST", "path": "/path" }
    //      ]
    //    }
    var ops = plan$apis[index].operations

    // locate the actual API referencethat corresponds to apiname
    var prod$api = productDoc.apis[index];
    if (prod$api !== undefined) {
     var apiDoc  = lookupAPI(prod$api.name);
     if (!apiDoc) {
      apim.console.warn(productIdVer + ': cannot find API document for ' + productDoc.apis[index].name);
     }
     else {
      // loop on all included operations
      var resource;
      var rateLimit;
      for (var op = 0; op < ops.length; op++) {
        resource = findOperationInAPI(apiDoc,ops[op]);
        rateLimit = getRateLimit(ops[op]);
        xml += indent + '<resource id="' + apimutil.escapeXML(resource.id) + '" version="' + apimutil.escapeXML(resource.ver);

        // Check here for Multi Rates at the operation level
        if (ops[op]["rate-limits"] || (rateLimit && rateLimit.value)) {
          var ratelimits = '"> <rate-limits> \n';
          var ratesArray = ops[op]["rate-limits"];
          if (rateLimit && rateLimit.value) {
              if (ratesArray===undefined) {
                  ratesArray={};
                  ratesArray['rate-limit']=rateLimit;
              }
          }
          var p = Object.keys(ratesArray);
          var count = 0;  // counter to track how many non-'unlimited' limits are present

          // max number of rate-limit policies is 7
          for (var i = 0; i < p.length && count < 7; i++)
          {
            if (ratesArray[p[i]].value !== "unlimited") {
              count++;
              ratelimits += '<rate-limit name="' + apimutil.escapeXML(p[i]) + '" value="' + ratesArray[p[i]].value + '" hard-limit="' + ratesArray[p[i]]["hard-limit"] + '" />';
            } else {
              count++;
              ratelimits += '<rate-limit name="' + apimutil.escapeXML(p[i]) + '" value="unlimited" />';
              break;
            }
          }
          ratelimits += '</rate-limits>\n</resource>\n';

          if (count > 0) {
            xml += ratelimits;
          } else {
            xml += '"/>\n';
          }
        } else {
          xml += '"/>\n';
        }
      }
     }
    } else {
      apim.console.error('request.services: ' + productIdVer + ':' + index + ' is not defined in a plan in this product!');
    }
  }
  return xml;
}

//TODO break ?apis and ?apps ????
function consumers(indent) {
  var c = {};
  for (var i = 0; i < subscriptions.length; i++) {
    var consumerId = subscriptions[i].application.id;
    if (c[consumerId] === undefined) {
      c[consumerId] = [subscriptions[i]];
    }
    else {
      c[consumerId] = c[consumerId].concat([subscriptions[i]]);
    }
  }
  if (addQSTestApp){
    addQuickStartConsumer(c);
  }
  var xml;
  xml = indent + '<consumers>\n';
  for (var i in c) {
    if (c.hasOwnProperty(i)) {
      xml += consumer(indent + ' ', c[i]);
    }
  }
  xml += indent + '</consumers>\n';
  return xml;
}


function consumer(indent, consumer) {
  var xml;
  var cId = consumer[0].application.id;
  var cName = apimutil.escapeXML(consumer[0].application.title);
  var cEnabld = consumer[0].application.enabled;
  var cActive = consumer[0].application.state.toLowerCase();
  var cType = consumer[0].application.type;
  if (cType === undefined) cType = 'PRODUCTION';
  var cOrgId = consumer[0].organization.id;
  var cOrgName = apimutil.escapeXML(consumer[0].organization.name);
  var cOrgTitle = apimutil.escapeXML(consumer[0].organization.title);
  if (consumer[0]['developer-organization'] !== undefined) {
    cOrgId = consumer[0]['developer-organization'].id;
    cOrgName = apimutil.escapeXML(consumer[0]['developer-organization'].name);
    cOrgTitle = apimutil.escapeXML(consumer[0]['developer-organization'].title);
  }
  xml = indent + '<consumer id="' + cId + '" appDisplayName="' + cName + '" type="' + cType + '" enabled="' + cEnabld + '" state="' + cActive + '" orgId="' + cOrgId + '" orgName="' + cOrgName + '" orgTitle="' + cOrgTitle + '">\n';
  xml += consumerCredentialsAsXML(indent + ' ', consumer);
  xml += consumerRegistrations(indent + ' ', consumer);
  xml += indent + '</consumer>\n';
  return xml;
}


function consumerCredentialsAsXML(indent, consumer) {
  var xml;
  xml = indent + '<clients>\n';
  for (var i in consumer[0].application['app-credentials']) {
    if (consumer[0].application['app-credentials'].hasOwnProperty(i)) {
      var cred = consumer[0].application['app-credentials'][i];
      xml += indent + ' <client appId="' + cred['client-id'] + '" appSecret="' + cred['client-secret'] + '"/>\n';
    }
  }
  xml += indent + '</clients>\n';
  return xml;
}


function consumerRegistrations(indent, consumer) {
  var oauthRedirUri = apimutil.escapeXML(consumer[0].application['oauth-redirection-uri']);
  var certificate = apimutil.escapeXML(consumer[0].application['certificate']);
  var xml;
  xml = indent + '<registrations>\n';
  if (oauthRedirUri) {
    xml += indent + ' <oauth-redirect-uri>' + oauthRedirUri + '</oauth-redirect-uri>\n';
  }
  if (certificate !== undefined && certificate && certificate !== '') {
    xml += indent + ' <certificate>' + certificate + '</certificate>\n';
  }
  for (var i = 0; i < consumer.length; i++) {
    var planversion = "";
    var spaceId = "";
    if (consumer[i]['plan-registration'].product != undefined && consumer[i]['plan-registration'].product.document != undefined ) {
        planversion = ' planversion="' + apimutil.escapeXML(consumer[i]['plan-registration'].product.document.info.version) + '"';
    }
    // get the spaceid if present in the plan registration
    if (consumer[i]['plan-registration'].spaces != undefined && consumer[i]['plan-registration'].spaces[0] &&
        consumer[i]['plan-registration'].spaces[0].id != undefined ) {
      spaceId = ' spaceid="' + consumer[i]['plan-registration'].spaces[0].id + '" ';
    }
    xml += indent + ' <registration plan="' + consumer[i]['plan-registration'].id + '"' + planversion + ' active="' + consumer[i].active + '"' + spaceId + '/>\n';
  }
  xml += indent + '</registrations>\n';
  return xml;
}


function apisAsXml(indent) {
  var xml = '';

  for (var i = 0; i < apis.length; i++) {
    try {
      xml += apiAsXml(indent, apis[i], mfpProviders);
    }
    catch (error) {
      apim.console.error(error.stack);
      apim.console.error('request.services: ' + apis[i].url + ': ' + error);
    }
  }

  return xml;
}

//@@ Writes out the API section of services.xml
//@@ == REST APIS ==
//@@ <api id="" version="" contextRoot="" swagger="" type="REST" >
//@@  <resource id="" verb="" pattern="" uri="" state="" target-url=""/>
//@@ </api>
//@@ == SOAP APIS ==
//@@ <api id="" version="" contextRoot="" swagger="" type="SOAP" wsdlLocation="">
//@@  <resource id="" verb="" pattern="" uri="" state="" target-url=""
//@@            soapAction="" operationNamespace="" operationLocalName=""/>
//@@ </api>
function apiAsXml(indent, api, providers) {
  if (api.document.error) {
    if (dbg) apim.console.debug('request.services: apiAsXml skipped:' + api.url + ' reason:' + api.document.error);
    return '';
  }
  //var id = api.document.info['x-ibm-name']; // use x-ibm-name api.id;
  var id = api.id; // use GUID provided by /v1/catalogs/:catalog/apis
  var ver = apimutil.escapeXML(api.document.info.version);
  var croot = api.document.basePath;

  //var swagger = api.url;  //We now POST each individual API into webapi-internal instead of fetching it from MGMT
  var swagger = mpgw_internal +"cacheJS/v1/catalogs/"+ api.catalog.id +"/apis/"+ api.id;

  if (dbg) apim.console.debug('req.services: apiAsXml: ' + JSON.stringify(api));
  if (croot && croot[0] === '/') {
    croot = croot.substring(1);
  }
  if (croot === undefined) {
    croot = '';
  }
  if (!id) {
    apim.console.error('API document missing x-ibm-name: ' + JSON.stringify(api.document.info));
  }
  var xIbmConfig = api.document['x-ibm-configuration'];
  var xIbmName = apimutil.escapeXML(api.document.info['x-ibm-name']);
  var apiTypeAttrs = ' type="REST"';
  //@@ SOAP APIs: compute wsdlLocation: /v1/catalogs/:id/apis/:id/wsdl
  //@@ Regression Environment: use /v1/catalogs/:id/apis/api??.wsdl
  if (xIbmConfig && xIbmConfig.type === 'wsdl') {
    var wsdlUrl = api.url + '/wsdl';
    if (api.url.indexOf('.json', api.url.length-5) !== -1) {
      wsdlUrl = api.url.substring(0,api.url.length-5) + '.wsdl';
    }
    apiTypeAttrs = ' type="SOAP" wsdlLocation="' + wsdlUrl + '"';
  }
  var xml;
  xml = indent + '<api id="' + id;
  xml += '" name="' + xIbmName;
  xml += '" version="' + ver;
  xml += '" contextRoot="' + croot;
  xml += '" swagger="' + swagger + '"';
  xml += apiTypeAttrs;
  xml += '>\n';
  xml += apiSpacesAsXML(indent + ' ', api);
  xml += apiResourcesAsXML(indent + ' ', api);

  //xml += swaggerUtil.translateSwaggerToXML(api.document, providers);
  xml += indent + '</api>\n';
  return xml;
}

function apiSpacesAsXML(indent, api) {
  var xml = '';
  if (api.spaces !== undefined) {
    api.spaces.forEach(function(space) {
      xml += indent + '<space id="' + space.id +
                      '" name="' + apimutil.escapeXML(space.name) + '"/>\n';
    });
  }
  return xml;
}

function apiResourcesAsXML(indent, api) {
  return foreachOperationInAPI(indent, api, function (indent, api, verb, path, operationObj) {
    var xIbmConfig = api.document['x-ibm-configuration'];
    var pathNoSlash = path[0] === '/' ? path.substring(1) : path;
    var pathNoQuery = pathNoSlash.split('?')[0];

    // check if any params begins with {+, if so replace it with a * match
    // for parity, {+name} is a match on *
    // also check for parenthesis
    var pathPlus = pathNoQuery.replace('\(','\\(').replace('\)','\\)');
    pathPlus = pathPlus.replace(/(\{\+.*?\})/g, '(.*)');    
    var pathPattern = '^' + pathPlus.replace(/(\{.*?\})/g, '([^\\/]*)') + '$';
    var id = ' id="' + [apimutil.escapeXML(api.document.info['x-ibm-name']), apimutil.escapeXML(api.document.info.version), verb, apimutil.escapeXML(path)].join(':') + '"';
    var method = ' verb="' + verb + '"';
    var uri = ' uri="' + apimutil.escapeXML(pathNoSlash) + '"';
    var pattern = ' pattern="' + apimutil.escapeXML(pathPattern) + '"';
    var state = ' state="' + api.state + '"';
    var targetUrl = ' target-url="http://127.0.0.1:'+internalPort+'/echo/"';
    var soapAttrs = '';
    var operationId = ''
    if (operationObj.operationId!==undefined && operationObj.operationId != null) {
        operationId = ' operationId="' + apimutil.escapeXML(operationObj.operationId) + '"';
    }
    if (xIbmConfig && xIbmConfig.type==="wsdl") {
      var xIbmSoap = operationObj['x-ibm-soap'];
      if (xIbmSoap && xIbmSoap['soap-action']) {
        soapAttrs += ' soapAction="' + xIbmSoap['soap-action'] + '"';
      }
      if (xIbmSoap && xIbmSoap['soap-operation']) {
        var re = /[\{\}]/;
        var operation = xIbmSoap['soap-operation'].split(re).filter(function(element) {
          return element.length !== 0;
        });
        soapAttrs += ' operationNamespace="' + operation[0] + '"';
        soapAttrs += ' operationLocalName="' + operation[1] + '"';
      }
    }
    return indent + '<resource' + id + method + pattern + uri + operationId + state + targetUrl + soapAttrs + '/>\n';
  });
}


// Iterates on all operations within an API and foreach operation, invokes a callback.
// Callback is expected to return an XML snippet to be merged to document being built.
// function callback(indent,api,verb,path,operationObj);
function foreachOperationInAPI(indent, api, callback) {
  var xml = '';
  for (var path in api.document.paths) {
    if (api.document.paths.hasOwnProperty(path)) {

      for (var verb in api.document.paths[path]) {
        if (api.document.paths[path].hasOwnProperty(verb)) {
          // some APIs may include a &, we need to escape it here to %26
          var escaped_path = path.replace(/&/g, '%26');
          xml += callback(indent, api, verb, escaped_path, api.document.paths[path][verb]);

        }
      }
    }
  }
  return xml;
}


// *********
// Look up in the list of APIs the document corresponding to an API's name
// @param info - the x-ibm-name + version of the API
// @return the API document
function lookupAPI(info) {
  var doc = undefined;
  var $info = info.split(':');
  for (var i = 0; i < apis.length; i++) {
    if (apis[i].document && apis[i].document.info && apis[i].document.info['x-ibm-name'] === $info[0] && apis[i].document.info.version === $info[1]) {
      doc = apis[i].document;
      break;
    }
  }
  return doc;
}

// *************************
// Returns the "id" and "version" that is used in services.xml for this operation.
// * In case we get an operationId, we look it up in the Swagger doc.
// * In case we get an operation name and path, we won't look it up in the Swagger;
//   We could lookup for a valid name & path and report it, but that would only
//   benefit the plan/product document author and not the runtime processing.
//
// Returns an object, { "id" : "", "ver" : "" }
function findOperationInAPI(apiDoc,operation) {
  //apim.console.debug('findOpInAPI: + ' + JSON.stringify(operation) + ' apiDoc: ' + JSON.stringify(apiDoc));
  var rsrc = {};
  if (operation.operationId) {
    for (var path in apiDoc.paths) {
      if (apiDoc.paths.hasOwnProperty(path)) {

        for (var verb in apiDoc.paths[path]) {
          if (apiDoc.paths[path].hasOwnProperty(verb) && (operation.operationId === apiDoc.paths[path][verb].operationId)) {
            rsrc.id = [apiDoc.info['x-ibm-name'], apiDoc.info.version, verb, path].join(':');
            rsrc.ver = apiDoc.info.version;
          }
        }
      }
    }
  }
  else if (operation.operation && operation.path) {
    rsrc.id = [apiDoc.info['x-ibm-name'], apiDoc.info.version, operation.operation.toLowerCase(), operation.path].join(':')
    rsrc.ver = apiDoc.info.version;
  }
  else {
    apim.console.warn('expected operation ID or verb+path - got ' + JSON.stringify(operation));
    return undefined;
  }
  return rsrc;
}

// *********
// Simple function to determine if an object has zero non-inherited properties
function isEmpty(obj) {
  for (var i in obj) {
    if (obj.hasOwnProperty(i)) {
      return false;
    }
  }
  return true;
}

// *********
// Registries
function processRegistries(indent) {
  var xml = '';
  xml += indent + '<registries>\n';
  try {
    for (var registry in registries) {
      if (registries.hasOwnProperty(registry) && (registries[registry].type === 'ldap')) {
        xml += processLdapRegistry(indent+' ', registries[registry]);
      }
    }
  }
  finally {
    xml += indent + '</registries>\n';
  }
  return xml;
}

function processLdapRegistry(indent,ldapRegistry) {
  var xml='';
  xml += indent + '<ldap id="' + ldapRegistry.id;
  xml += '" name="' + apimutil.escapeXML(ldapRegistry.name);
  xml += '" title="' + apimutil.escapeXML(ldapRegistry.title);
  xml += '">\n';
  for (var i in ldapRegistry['ldap-config']) {
    if (ldapRegistry['ldap-config'].hasOwnProperty(i)) {
      xml += indent + ' <property name="' + apimutil.escapeXML(i);
      xml += '">' + apimutil.escapeXML(ldapRegistry['ldap-config'][i]);
      xml += '</property>\n';
    }
  }
  xml += indent + '</ldap>\n';
  return xml;
}

function addQuickStartConsumer(c) {
  var consumerId = 'testconsumerid';
  c[consumerId] = [];
  c[consumerId][0] = {};
  c[consumerId][0].active = true;
  c[consumerId][0].application = {};
  c[consumerId][0].application.id = '__INTERNAL_QS__:1.0.0:default';
  c[consumerId][0].application.title = '__INTERNAL_QS__';
  c[consumerId][0].application.enabled = true;
  c[consumerId][0].application.state = 'ACTIVE';
  c[consumerId][0].application['oauth-redirection-url'] = '';
  c[consumerId][0].application['app-credentials'] = [];
  c[consumerId][0].application['app-credentials'][0] = {};
  c[consumerId][0].application['app-credentials'][0]['client-id'] = apis[0]['catalog']['test-app-credentials']['client-id'];
  c[consumerId][0].application['app-credentials'][0]['client-secret'] = apis[0]['catalog']['test-app-credentials']['client-secret'];
  c[consumerId][0].organization = {};
  c[consumerId][0].organization.id = '__internal__';
  c[consumerId][0].organization.name = '__internal__';
  c[consumerId][0]['developer-organization'] = {};
  c[consumerId][0]['developer-organization'].id = apis[0]['organization']['id'];
  c[consumerId][0]['developer-organization'].name = apis[0]['organization']['name'];
  c[consumerId][0]['plan-registration'] = {};
  c[consumerId][0]['plan-registration'].id = '__INTERNAL_QS__:1.0.0:default';
  c[consumerId][0]['plan-registration'].product = {};
  c[consumerId][0]['plan-registration'].product.document = {};
  c[consumerId][0]['plan-registration'].product.document.info = {};
  c[consumerId][0]['plan-registration'].product.document.info.version = '1.0.0';
}
