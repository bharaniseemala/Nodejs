// ***************************************************** {COPYRIGHT-TOP} ***
//* Licensed Materials - Property of IBM
//* 5725-L30, 5725-Z22, 5725-Z63, 5725-U33
//*
//* (C) Copyright IBM Corporation 2016, 2017
//*
//* US Government Users Restricted Rights - Use, duplication, or
//* disclosure restricted by GSA ADP Schedule Contract with IBM Corp.
// ********************************************************** {COPYRIGHT-END}**

var dbglog = console.options({'category':'xsltmsg'});
var apim = require('local:///isp/policy/apim.custom.js');
var properties = apim.getPolicyPropertyAsEntered();
var exprResult = false;
var util = require('util');
var verbose = apim.verbose;

var logprefix = 'policy: apim.conditional: ' + properties.title + ':';

//@@ Load up the context, so it can be accessed during evaluation
var context = apim.getContext();
var request = context.request;
var api = context.api;

//@@ If we find $(variables), resolve them to regular JS variables
//@@ Use regular expressions. Won't allow more than 30 variables in
//@@ this expression, safeguard against an infinite loop caused by
//@@ the regex.exec code.
var loopmax = 30;
var regex = /.*(\$\([a-zA-Z\-\.\_0-9]+\)).*/;
var expr = properties.condition;
var m;

m = regex.exec(expr);
var i=0;
while (m !== null && loopmax-->0)
{
  //dbglog.debug(logprefix + loopmax + ' M1='+m[1]+' expr='+ expr);
  expr = replaceWithGetVariable(expr, m[1]);
  regex.lastIndex = 0; //@@ this allows me to reuse the same regex object
  m = regex.exec(expr);
}

//@@ Finally, evaluate the expression
try
{
  /* 
   * Wrapper to eval(). This will disable sensitive modules before invoking the actual eval().
   * Note: This wrapper is duplicated in three files apim.policy.gatewayscript.js,
   * apim.conditional.js and apim.map.js as it not exportable.
   *
   * */
  function evalSafe(expr) 
  { 
    var _require = require;
    return (function(){
      var require = function(mod) {
        if (mod === 'mgmt') 
          throw new Error("Error: Cannot find module 'mgmt'"); 
        if (mod === 'multistep') 
          throw new Error("Error: Cannod find module 'multistep'"); 
        if (mod === 'fs') 
          throw new Error("Error: Cannot find module 'fs'"); 
        if (mod === 'service-metadata') 
          throw new Error("Error: Cannot find module 'service-metadata'"); 
        return _require(mod);
      };
      return eval(expr); 
    })();
  }
  exprResult = evalSafe(expr);
}

catch (error)
{
  dbglog.error(logprefix + ' ' + error);
  exprResult = false;
}

if (verbose)
{
  dbglog.debug(logprefix + ' expr  : ' + properties.condition);
  dbglog.debug(logprefix + ' resolv: ' + expr);
  dbglog.debug(logprefix + ' result: ' + exprResult);
}

//@@ Indicate to Policy Framework the condition didn't evaluate and
//@@ next policy must be the one following the end of this if() block
if (!exprResult)
{
  session.name('policy').setVar('fw/next-policy', '_SKIP_BLOCK_');
}


function replaceWithGetVariable(expr, match)
{
  var quote = "'";
  var varName = match.substring(2,match.length-1);
  var value = apim.getvariable(varName);
  if (!value){
    if (verbose) dbglog.debug(logprefix + ' variable ' + "\""+ varName +"\"" +" is undefined or null");
  }
  else if (util.isError(value) || util.safeTypeOf(value) == 'object') {
    value = 'apim.getvariable("' + varName + '")';
  }
  else if (typeof(value) === 'string'){
     //Quote the value in single quote IFF its a string
     value = quote + value + quote;
  }

  expr = expr.replace(match, value);
  return expr;
}
