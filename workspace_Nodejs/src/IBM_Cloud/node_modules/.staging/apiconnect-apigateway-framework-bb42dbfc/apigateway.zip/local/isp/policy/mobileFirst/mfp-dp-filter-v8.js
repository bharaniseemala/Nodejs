// ***************************************************** {COPYRIGHT-TOP} ***
//* Licensed Materials - Property of IBM
//* 5725-L30
//*
//* (C) Copyright IBM Corporation 2016
//*
//* US Government Users Restricted Rights - Use, duplication, or
//* disclosure restricted by GSA ADP Schedule Contract with IBM Corp.
// ********************************************************** {COPYRIGHT-END}**

/*
  "version": "8.0.0",
  "description": "The passport-mfp-token-validation module provides the passport strategy and verification method to validate the access token contained in authorization header for IBM Mobile First Platform.",

*/

// @Author: Lior Luker <liorlu@il.ibm.com>

var hm = require('header-metadata');
var mfpApicUtils = require('local:///isp/policy/mobileFirst/util/mfp-apic-utils');
var mfpStrategy = require('local:///isp/policy/mobileFirst/mfp-strategy');

let scope = mfpApicUtils.getScopesForApiEndpoint();
let azserver = mfpApicUtils.getMfpProviderAuthorizationUrl();
let confClientID = mfpApicUtils.getMfpProviderClientId();
let confClientPass = mfpApicUtils.getMfpProviderClientSecret();
let mfpProviderName = mfpApicUtils.getMfpProviderName();
let tlsProfile = mfpApicUtils.getTlsProfile();

var options = {
    authServerUrl: azserver,
    confClientID: confClientID,
    confClientPass: confClientPass,
    certificate: tlsProfile,
    scope: scope,
    mfpProviderName: mfpProviderName,
};

var startegy = new mfpStrategy(options);
var req = {};
req.headers = hm.current.headers;
startegy.authenticate(req);
