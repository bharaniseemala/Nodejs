// ***************************************************** {COPYRIGHT-TOP} ***
//* Licensed Materials - Property of IBM
//* 5725-L30, 5725-Z22, 5725-Z63, 5725-U33
//*
//* (C) Copyright IBM Corporation 2016, 2017
//*
//* US Government Users Restricted Rights - Use, duplication, or
//* disclosure restricted by GSA ADP Schedule Contract with IBM Corp.
// ********************************************************** {COPYRIGHT-END}**
//
var apim = require('local:///isp/policy/apim.custom.js');
var apimutil = require('local:///isp/apim.util.js');
var jsonx = require('local:///isp/policy/json2jsonx.js');
var headermeta = require('header-metadata');
var mfpProvidersManager = require('local:///isp/policy/mobileFirst/mfp-providers-manager.js');
var mfpProviders  = undefined;

var verbose = apim.verbose;
var xmlFlowDirection = 'request';
var legacyJSONEncoding = true;

const PolicyVersionString = 'version';
const NoName = undefined;
const SkipExecute = [ 'execute' ];
const MarkerImplFlowStart = {'IMPL-FLOW-STARTS':{}};
const MarkerRespFlowStart = {'RESP-FLOW-STARTS':{}};

// MAIN:
// - fetch API document (Swagger)
//
var operationIds = {};

// Traverse Swagger Object, building policies.xml as it navigates the tree
function translateSwaggerToXML(swaggerDoc, providers)
{
   mfpProviders = providers;
   var xIbmConfig = swaggerDoc['x-ibm-configuration'];
   var policiesXml = "<policies>\n";
   var operCond = undefined;
   var indent = ' ';
   var theFlow = xIbmConfig.assembly ? xIbmConfig.assembly.execute : undefined;
   var injectToFlow = [];
   var injectIndex = 0;
   var globalHandler = xIbmConfig.assembly ? xIbmConfig.assembly.catch: [];
   operationIds = {};
   xmlFlowDirection = 'request';

   // Consolidate the Request, Implementation and Response flows.
   // Temporarily, so we don't break every thing yet, we will support the Beta-like flow,
   // i.e. a single flow (horseshoe) if the swagger we read has it like that. TODO remove before V5 GA.
   //
   // Use a temporary marker to indicate the sub-flows transitions in the flow.
   if (!theFlow)
   {
     var newFlow = [];
     if (xIbmConfig.assembly && xIbmConfig.assembly.request && xIbmConfig.assembly.request.execute)
     {
       newFlow = newFlow.concat(xIbmConfig.assembly.request.execute);
     }
     if (xIbmConfig.assembly && xIbmConfig.assembly.implementation && xIbmConfig.assembly.implementation.execute)
     {
       newFlow = newFlow.concat([MarkerImplFlowStart]).concat(xIbmConfig.assembly.implementation.execute);
     }
     if (xIbmConfig.assembly && xIbmConfig.assembly.response && xIbmConfig.assembly.response.execute)
     {
       newFlow = newFlow.concat([MarkerRespFlowStart]).concat(xIbmConfig.assembly.response.execute);
     }
     theFlow = newFlow;
   }

   // CORS Policy
   if (xIbmConfig.cors && xIbmConfig.cors.enabled)
   {
     injectToFlow.push({ "apim.cors": { "title": "CORS" }});
   }

   // mutual certificate
   if (xIbmConfig["application-authentication"] &&
       xIbmConfig["application-authentication"].certificate &&
       xIbmConfig["application-authentication"].certificate === true) {
     injectToFlow.push({ "apim.mtls": { "title": "MutualTLS" }});
   }

   // oauth2
   if (xIbmConfig.oauth2)
   {
     if(mfpProvidersManager.isMobileFirstOauthProvider(xIbmConfig.assembly)){
        // in case of MobileFirst OauthProivder, we want to use API assembly flow for enabling proxy endpoint
        // do nothing. assembly is parsed later in the code
        apim.console.debug('The OAuthProvider is MobileFirst type. Will use assembly flow instead of oauth2-server policy');
     }
     else{
        injectToFlow.push(injectOAuthProviderExtension(swaggerDoc));
     }
   }

   //injectToFlow[injectIndex++] = { "foo": { "title": "The Foo Policy", "prop1": "value1", "prop2": "value2" }};

   //@@ SECURITY Policies
   //@@  (a) APP.Identity
   //@@  Basic & OAuth
   //@@  Security may be present at a Global or a local, Path
   //@@  Level, when present at the local level it will override
   //@@  the Global.
    var globalSecPolicy = undefined;  //@@ empty security policy.
    if (swaggerDoc.security && swaggerDoc.security.length >= 1)
    {
      globalSecPolicy = processSecuritySection(swaggerDoc.security, swaggerDoc.securityDefinitions, (swaggerDoc['x-ibm-configuration'].oauth2));
    }

    operationIds = getOperationIds(swaggerDoc.paths);

    //@@ Check and see if any of the APIs have security section.
    if (anyAPIPathsContainsSec(swaggerDoc.paths) === true)
    {
        //@@ We need to generate policy for each path we find
        //@@ if none present, use global for that path using
        //@@ an op-switch
        var secOpSwitch = generateOpSwitchSecPol(globalSecPolicy, swaggerDoc.paths, swaggerDoc.securityDefinitions);

        //@@ Here we need to check if the request flow already has an operation-switch
        //@@ if so, merge or insert the policy into the appropriate case.
        if (!assemblyContainsOpSwitch(theFlow))
        {
            //@@ inject into the flow as-is
            injectToFlow.push(secOpSwitch);
        }
        else
        {
            //@@ merge the two op-switch policies
            mergeOpSwitchPolicy(theFlow, secOpSwitch);
        }
    }
    else if (globalSecPolicy != undefined)
    {
      //@@ if globalSecPolicy was returned as an array
      //@@ add the Global policy to the flow as-is
      //@@ to be applied to all the APIs
      if (globalSecPolicy.constructor == Array) {
          injectToFlow = injectToFlow.concat(globalSecPolicy);
      } else {
          // otherwise push at the end of the array
          // as an element
          injectToFlow.push(globalSecPolicy);
      }
    }

   // Rebuild the flow:
   // - Take the list of policies injected to the beginning of the array
   theFlow = injectToFlow.concat( theFlow );

   // API Properties
   policiesXml += addApiProperties(indent,swaggerDoc);

   // Write the received swagger (minus assembly)
   policiesXml += saveDocument(indent,swaggerDoc);

   // Assembly Flow - Array
   policiesXml += traverseFlow(theFlow, operCond, indent);

   // Traverse Main Error handler
   if (globalHandler !== undefined)
   {
     policiesXml += traverseCatch(globalHandler, indent);
   }

   policiesXml += '</policies>\n';
   //apim.console.debug('XML==\n' + policiesXml);

   return policiesXml;
}


function traverseFlow(flow, operCond, indent)
{
  if (verbose) apim.console.debug('traverseFlow:' + JSON.stringify(flow));
  var xml = "";
  var policyType = Object.keys(flow)[0]; // this is the name of the first property in this object.
  //apim.console.debug("traversing..." + indent + policyType);
  //apim.console.debug(flow[policyType]);

  //
  if (flow.constructor === Array)
  {
    for (var i = 0; i < flow.length; i++)
    {
      xml+= traverseFlow(flow[i], operCond, indent);
    }
    return xml;
  }

  // Marks the start of the 'implementation' sub-flow. Currently, not interesting.
  if (MarkerImplFlowStart[policyType] !== undefined) {
    return xml;
  }

  // Marks the start of the 'response' sub-flow.
  if (MarkerRespFlowStart[policyType] !== undefined) {
    xmlFlowDirection = 'response';
    return xml;
  }

  // Language construct - operation-switch.case is an array ...
  //                      operation-switch.case[n].operations == array ...
  //                      operation-switch.case[n].execute    == array ... (see language construct execute)
  //
  // First locate the conditions and iterate over the policies adding the match conditions.
  if (policyType === 'operation-switch')
  {
    for (var i=0; i<flow[policyType].case.length; i++)
    {
      var stCase = flow[policyType].case[i];
      for (var j=0; j<stCase.operations.length; j++)
      {
        var cond = addConditions(stCase.operations[j], indent + ' ');
        xml+= traverseFlow(stCase.execute, cond, indent);
      }
    }
    return xml;
  }

  var policyVersion = flow[policyType][PolicyVersionString];
  var policyTitle = flow[policyType].title;

  // switch is a special policy. it will be flatten into several policies.
  if (policyType === 'switch')
  {
    var cases = flow[policyType].case;
    if (cases === undefined)

    var otherwise;
    for (var k=0; k<cases.length; k++) {
      otherwise = cases[k].otherwise;

      var type;
      if (k === 0)
          type = "switch";
      else if (otherwise)
          type = "switch.otherwise";
      else
          type = "switch.case";

      xml += xmlPolicyStart(indent, type, policyTitle, xmlFlowDirection, policyVersion);

      if (otherwise) {
        var props = { 'condition': true,
                      'execute': otherwise };
        xml += populatePolicyBody(operCond, indent, props, ['execute']);
      }
      else
        xml += populatePolicyBody(operCond, indent, cases[k], ['execute']);

      xml += xmlPolicyEnd(indent);

      if (otherwise)
        break;
    }
    return xml;
  }

  // This is a typical policyType

  // 'skipProperties' indicate the reserved words that must not be considered a
  // property for a policy, and must be, instead, used to traverse a new subflow
  var skipProperties = [];
  if (policyType === 'if')
    skipProperties = [ 'execute' ];

  xml += xmlPolicyStart(indent, policyType, policyTitle, xmlFlowDirection, policyVersion);
  xml += populatePolicyBody(operCond, indent, flow[policyType], skipProperties);
  xml += xmlPolicyEnd(indent);

  return xml;
}

function populatePolicyBody(operCond, indent, policy, skipProperties) {
  var xml = "";
  if (operCond !== undefined)
    xml+= operCond;

  // add properties and flatten policies
  xml += addProperties(indent + ' ', NoName, policy, skipProperties);

  var skippedProperty;
  for (var idx = 0; idx < skipProperties.length; idx++)
  {
    skippedProperty = skipProperties[idx];
    if (verbose)
      apim.console.debug('req.swagger: newflow: skipped' + skippedProperty);
    xml += traverseFlow(policy[skippedProperty], operCond, indent + ' ');
  }

  return xml;
}

function getPolicyType(name)
{
  switch(name)
  {
  case "set-variable" : return "apim.setvariable";
  case "redact"       : return "redaction";
  case "activity-log" : return "activitylog";
  default             : return name;
  }
}


function addConditions(input, indent)
{
  var path ='';
  var verb = '';
  var opNamespace = '';
  var opLocalName = '';
  var operationId = '';
  
  if (input.verb!==undefined) {
      // we have a verb and hopefully a path
      verb = input.verb.toUpperCase();
      path = input.path;
  } else {
      // we probably have an operation id
      var operation = operationIds[input];
      if (operation!==undefined) {
          // Here we need to find if the operationID comes
          // from a WSDL.
          if (operation.soap !== undefined && operation.soap['soap-operation'] !== undefined && operation.soap['soap-operation'] !== null)
          {
              var re = /[\{\}]/;
              var op = operation.soap['soap-operation'].split(re).filter(function(element) {
                                return element.length !== 0;
                       });
                opNamespace = op[0];
                opLocalName = op[1];
          } else {
              operationId = operation.id;
              verb = operation.verb.toUpperCase();
              path = operation.path;
          }
      }
  }
  var pathslash = false;
  if (path[0] === '/')
  {
    if (path.length == 1) {
        pathslash = true;
    }  
    path = path.substring(1);
  }

  // check if any params begins with {+, if so replace it with a * match
  // for parity, {+name} is a match on *
  path = path.replace(/(\{\+.*?\})/g, '(.*)');
  // Replace {name} params
  path = path.replace(/(\{.*?\})/g,'([^\\/]*)');

  var xml = indent + '<condition>\n';
  if (path.length > 0 || pathslash) {
      xml    += indent + ' <match name="method" type="string">' + verb + '</match>\n';
      xml    += indent + ' <match name="path" type="string">^' + apimutil.escapeXML(path) + '$</match>\n';
  } else {
      xml    += indent + ' <match name="operationLocalName">' + opLocalName + '</match>\n';
      xml    += indent + ' <match name="operationNamespace">' + opNamespace + '</match>\n';
  }

  if (operationId!==undefined && operationId != null && operationId.length > 0) {
      xml    += indent + ' <match name="operationId">' + apimutil.escapeXML(operationId) + '</match>\n';
  }
  
  xml    += indent + '</condition>\n';
  return xml;
}


//@@ ==========================================================================
//@@   <policyA>:
//@@      <p1>: [ 'a', 'b', 3 ]
//@@      <p2>: 'value'
//@@      <p3>: {...}
//@@
//@@
//@@     <properties>
//@@       <properties name="p1">
//@@         <property name="0">a</property>
//@@         <property name="1">b</property>
//@@         <property name="2">3</property>
//@@       </properties>
//@@       <property name="p2">value</property>
//@@       <properties name="p3">
//@@       </properties/
//@@     </properties>
//@@
//@@ ==========================================================================
function addProperties(indent, name, input, skipNames)
{
  if (verbose)
  {
    apim.console.debug('\n');
    apim.console.debug('addP: name:' + name + ' type:' + typeof input + ' value:' + JSON.stringify(input));
    apim.console.debug('addP: skip: ' + skipNames);
  }

  var xml = '';

  if (skipNames !== undefined && skipNames.indexOf(name) > -1) {}
  else if (input !== null && typeof input === 'object')
  {
    xml+= xmlPropertiesStart(indent,name,input);
    for (var childName in input)
    {
      if (input.hasOwnProperty(childName)) {
        xml+= addProperties(indent + ' ', childName, input[childName], skipNames);
      }
    }
    xml+= xmlPropertiesEnd(indent);
  }
  else
  {
    xml+= xmlPropertyAdd(indent, name, input);
  }

  return xml;
}



//@@ ==========================================================================
//@@   catch:
//@@     - errors:
//@@         - error1
//@@         - error2
//@@       execute:
//@@         <A FLOW>
//@@     - errors:
//@@         - error3
//@@         - error4
//@@       execute:
//@@         <A FLOW>
//@@     - default
//@@         <A FLOW>
//@@
function traverseCatch(flow, indent)
{
  var xml = '';
  var operCond;
  // the flow is an array of "errors" and "default"
  if (flow.constructor !== Array)
  {
    apim.console.error('traverse catch: not an array');
    apim.console.error(flow);
    return '';
  }

  var key;
  for (var i = 0; i < flow.length; i++)
  {
    key = Object.keys(flow[i])[0];
    xml+= xmlPolicyStart(indent,'catch');
    if (key === 'errors')
    {
      xml+= addProperties(indent + ' ', NoName, flow[i], SkipExecute);

      if (flow[i].execute !== undefined)
      {
        xml+= traverseFlow(flow[i].execute, operCond, indent + ' ');
      }
    }
    else
    {
      xml+= traverseFlow(flow[i][key], operCond, indent + ' ');
    }
    xml+= xmlPolicyEnd(indent);
  }
  return xml;
}

//@@ ===================================================
//@@ Inject the OAuth2 Provider Policy into the Flow
//@@ ===================================================
function injectOAuthProviderExtension(swaggerDoc)
{
  var xIbmConfig = swaggerDoc['x-ibm-configuration'];

  var oauth2server = {
    "client-type" : xIbmConfig.oauth2['client-type'],
    "grants" : xIbmConfig.oauth2.grants.join("+"),
    "identity-extraction.type": xIbmConfig.oauth2['identity-extraction'].type,
    "authorization.type": xIbmConfig.oauth2.authorization.type
  };

  if (xIbmConfig.oauth2['identity-extraction'].type === 'redirect') {
    oauth2server['identity-extraction.redirect-url'] = xIbmConfig.oauth2['identity-extraction']['redirect-url'];
  }
  else if (xIbmConfig.oauth2['identity-extraction'].type === 'custom-form') {
    // the oauth editor really needs some tlc, so perform some sanity check before it goes further and causes issue
    if (typeof(xIbmConfig.oauth2['identity-extraction']['custom-form'].url) === 'undefined') {
      oauth2server['identity-extraction.custom-form.url'] = '';
    }
    else {
      oauth2server['identity-extraction.custom-form.url'] = xIbmConfig.oauth2['identity-extraction']['custom-form'].url;
    }
    if (typeof(xIbmConfig.oauth2['identity-extraction']['custom-form']['tls-profile']) === 'undefined') {
      oauth2server['identity-extraction.custom-form.tls-profile'] = '';
    }
    else {
      oauth2server['identity-extraction.custom-form.tls-profile'] = xIbmConfig.oauth2['identity-extraction']['custom-form']['tls-profile'];
    }
  }

  for (var scope in xIbmConfig.oauth2.scopes)
  {
    if (xIbmConfig.oauth2.scopes.hasOwnProperty(scope)) {
      var name = 'scopes.' + scope;
      oauth2server[name] = xIbmConfig.oauth2.scopes[scope];
    }
  }

  // advanced scope check is needed
  if (xIbmConfig.oauth2['scope-validators'] !== undefined) {
    // application
    if (xIbmConfig.oauth2['scope-validators'].application !== undefined &&
        xIbmConfig.oauth2['scope-validators'].application.url !== undefined &&
        xIbmConfig.oauth2['scope-validators'].application.url.trim().length > 0) {
      oauth2server['scope-validators.application.url'] = xIbmConfig.oauth2['scope-validators'].application.url;
      if (xIbmConfig.oauth2['scope-validators'].application['tls-profile'] !== undefined &&
          xIbmConfig.oauth2['scope-validators'].application['tls-profile'].trim().length > 0) {
        oauth2server['scope-validators.application.tls-profile'] =
          xIbmConfig.oauth2['scope-validators'].application['tls-profile'];
      }
    }
    // owner
    if (xIbmConfig.oauth2['scope-validators'].owner !== undefined &&
        xIbmConfig.oauth2['scope-validators'].owner.url !== undefined &&
        xIbmConfig.oauth2['scope-validators'].owner.url.trim().length > 0) {
      oauth2server['scope-validators.owner.url'] = xIbmConfig.oauth2['scope-validators'].owner.url;
      if (xIbmConfig.oauth2['scope-validators'].owner['tls-profile'] !== undefined &&
          xIbmConfig.oauth2['scope-validators'].owner['tls-profile'].trim().length > 0) {
        oauth2server['scope-validators.owner.tls-profile'] =
          xIbmConfig.oauth2['scope-validators'].owner['tls-profile'];
      }
    }
  }

  // this does not make sense for client_credential/application grant type
  if (!(xIbmConfig.oauth2.grants.length === 1 &&
        xIbmConfig.oauth2.grants.indexOf('application') > -1)) {
    if (xIbmConfig.oauth2.authentication.file !== undefined) {
      oauth2server.type = 'file';
    }
    else if (xIbmConfig.oauth2.authentication['x-ibm-authentication-registry']) {
      oauth2server.type = 'ldap';
      oauth2server['authentication.x-ibm-authentication-registry'] =
        xIbmConfig.oauth2.authentication['x-ibm-authentication-registry'];
    }
    else if (xIbmConfig.oauth2.authentication['x-ibm-authentication-url']) {
      oauth2server.type = 'authUrl';
      oauth2server['authentication.x-ibm-authentication-url.url'] =
        xIbmConfig.oauth2.authentication['x-ibm-authentication-url'].url;
      if (typeof(xIbmConfig.oauth2.authentication['x-ibm-authentication-url']['tls-profile']) === 'undefined') 
         oauth2server['authentication.x-ibm-authentication-url.tls-profile'] = '';
      else
         oauth2server['authentication.x-ibm-authentication-url.tls-profile'] = 
           xIbmConfig.oauth2.authentication['x-ibm-authentication-url']['tls-profile'];
    }
  }
  if (xIbmConfig.oauth2.authorization.type) {
    oauth2server['authorization.type'] = xIbmConfig.oauth2.authorization.type;
    if (oauth2server['authorization.type'] === 'custom-form') {
      // the oauth editor really needs some tlc, so perform some sanity check before it goes further and causes issue
      if (xIbmConfig.oauth2.authorization['custom-form'] === undefined || xIbmConfig.oauth2.authorization['custom-form'].url === undefined)
        oauth2server['authorization.custom-form.url'] = '';
      else
        oauth2server['authorization.custom-form.url'] = xIbmConfig.oauth2.authorization['custom-form'].url;
      if (xIbmConfig.oauth2.authorization['custom-form'] === undefined || xIbmConfig.oauth2.authorization['custom-form']['tls-profile'] === undefined)
        oauth2server['authorization.custom-form.tls-profile'] = '';
      else
        oauth2server['authorization.custom-form.tls-profile'] = xIbmConfig.oauth2.authorization['custom-form']['tls-profile'];
    }
  }

  oauth2server['access-token.ttl'] = 3600;
  if (xIbmConfig.oauth2['access-token'] && xIbmConfig.oauth2['access-token'].ttl !== undefined) {
    oauth2server['access-token.ttl'] = xIbmConfig.oauth2['access-token'].ttl;
  }

  if (xIbmConfig.oauth2['refresh-token'] && xIbmConfig.oauth2['refresh-token'].count !== undefined) {
    oauth2server['refresh-token.count'] = xIbmConfig.oauth2['refresh-token'].count;
    if (oauth2server['refresh-token.count'] > 0) {
      oauth2server['refresh-token.ttl'] = 2682000;
      if (xIbmConfig.oauth2['refresh-token'].ttl !== undefined)
        oauth2server['refresh-token.ttl'] = xIbmConfig.oauth2['refresh-token'].ttl;
    }
    oauth2server['maximum-consent.ttl'] = 0;
    if (xIbmConfig.oauth2['maximum-consent'] && xIbmConfig.oauth2['maximum-consent'].ttl !== undefined) {
      oauth2server['maximum-consent.ttl'] = xIbmConfig.oauth2['maximum-consent'].ttl;
    }
  }

  if (xIbmConfig.oauth2['revocation']) {
    if (xIbmConfig.oauth2['revocation'].url !== undefined) {
        oauth2server['revocation.url'] = xIbmConfig.oauth2['revocation'].url;
    }
    else if (xIbmConfig.oauth2['revocation'].type === 'gateway') {
      oauth2server['revocation.type'] = xIbmConfig.oauth2['revocation'].type;
    }
  }

  if (xIbmConfig.oauth2['metadata']) {
    if (xIbmConfig.oauth2['metadata']['metadata-url'].url !== undefined) {
      oauth2server['metadata.metadata-url.url'] = xIbmConfig.oauth2['metadata']['metadata-url'].url;
      if (typeof(xIbmConfig.oauth2['metadata']['metadata-url']['tls-profile']) === 'undefined') {
        oauth2server['metadata.metadata-url.tls-profile'] = '';
      }
      else {
        oauth2server['metadata.metadata-url.tls-profile'] = xIbmConfig.oauth2['metadata']['metadata-url']['tls-profile'];
      }
    }
  }

  var operations = [];
  var operationsIdx = 0;
  for (var path in swaggerDoc.paths) {
    if (swaggerDoc.paths.hasOwnProperty(path)) {

      for (var verb in swaggerDoc.paths[path]) {
        if (swaggerDoc.paths[path].hasOwnProperty(verb)) {
          operations[operationsIdx++] = { "path": path, "verb": verb };
        }
      }
    }
  }
  var policy = { "oauth2-server" : oauth2server };
  var opSwitch = {
    "operation-switch" : {
      "case" : [ { "operations" : operations, "execute": [policy] } ]
    }
  };
  return opSwitch;
}

//@@ ==========================================================================
//@@
//@@ Utility functions to create XML strings (elements, attributes, etc)
//@@
//@@ ==========================================================================


//@@ <policy> element
//@@   attributes:
//@@     - @type       - the policy type, CORS, Validate, Proxy, etc.
//@@     - @name       - title provided in Swagger (optional)
//@@     - @direction  - request | response
//@@     - @depth      - indicates the scope of this policy, parent/@depth+1
var policyDepth = 0;
function xmlPolicyStart(indent,type,name,direction,version)
{
  policyDepth++;
  var xml = indent + '<policy type="' + getPolicyType(type) + '"';
  xml+= ' name="' + (name===undefined?type:apimutil.escapeXML(name)) + '"';
  if (version!==undefined) {
      xml+= ' policyVersion="' + apimutil.escapeXML(version) + '"';
  }
  xml+= ' direction="' + (direction===undefined?'request':direction) + '"';
  if (type === 'proxy' || type === 'activity-log' || type === 'apim.appidentity')
    xml+= ' JSONNotRequired="true"';
  return xml + ' depth="' + policyDepth + '">\n';
}
function xmlPolicyEnd(indent)
{
  policyDepth--;
  return indent + '</policy>\n';
}


//@@ <properties> element
//@@   attributes:
//@@     - @name       - name as in swagger (optional)
//@@     - @array      - true if this represents an array (optional, omitted indicates false)
function xmlPropertiesStart(indent,name,input)
{
  var attrName = '';
  var attrArray = '';
  if (name !== undefined)
  {
    attrName = ' name="' + apimutil.escapeXML(name) + '"';
  }
  if (input.constructor === Array)
  {
    attrArray = ' array="true"';
  }
  return indent + '<properties' + attrName + attrArray + '>\n';
}
function xmlPropertiesEnd(indent)
{
  return indent + '</properties>\n';
}

//@@ <property> element
//@@   attributes:
//@@     - @name       - name as in swagger or index if indicates an array element
function xmlPropertyAdd(indent,name,value)
{
  var property = '';
  // if the property name is the ibm policy version (used for custom policies)
  // then do not store in the actual policy properties
  if (name!=PolicyVersionString) {
    var additionalProperties = '';
    if (value === null)
    {
      additionalProperties = ' type="null"';
      value = '';
    }
    else
    {
      additionalProperties = ' type="' + typeof value + '"';
    }
    if (typeof value === 'string')
    {
      if(!legacyJSONEncoding && value.slice(0,1) != "[" && value.slice(-1) != "]"){
        value = JSON.stringify(value).slice(1,-1);
      }

      // The only ASCII control characters which are valid in XML are &#x9; &#xA; and &#xD;
      // We need to throw an error if we cannot represent the character to prevent producing invalid XML
      var regExp = /[\u0000-\u0008\u000b-\u000c\u000e-\u001f]/
      var matchedChar = value.match(regExp);
      if (matchedChar)
        throw new Error('Cannot add xml property because ' + matchedChar + ' is illegal in XML');

      if (value.indexOf('&') > -1 || value.indexOf('<') > -1)
      {
        // a value with its own CDATA will interfere with the CDATA we will be wrapping it with below, 
        // so modify the CDATA end tags to terminate and restart the CDATA tag so the end result will be
        // multiple CDATA tags that properly wrap the data
        if (value.indexOf(']]>') > -1) {
          var regex = /\]\]>/g;
          value = value.replace(regex, ']]]]><![CDATA[>');
        }
        value = '<![CDATA[' + value + ']]>';
      }
    }
    property =  indent + '<property name="' + apimutil.escapeXML(name) + '"' + additionalProperties + '>' + value + '</property>\n';
  }
  return property;
}

// =====================================================
// Read x-ibm-configuration.properties into policy.xml
// Snippet/sample document:
//
// x-ibm-configuration:
//   properties:
//     - routes-host:
//         value: api.goclimbarock.com
//         description: Backend hostname
//         hidden: false
//         encoded: true
//     - routes-port:
//         value: 8443
//
function addApiProperties(indent,xIbmConfig) {
  var xml = '';
  if (xIbmConfig['x-ibm-configuration'].properties) {
    for (var name in xIbmConfig['x-ibm-configuration'].properties) {
      if (xIbmConfig['x-ibm-configuration'].properties.hasOwnProperty(name)) {
        if(name == "x-ibm-gateway-framework-legacy-json-encoding" && xIbmConfig['x-ibm-configuration'].properties[name].value === "false"){
          legacyJSONEncoding = false;
        }
        xml += apimutil.swaggerApiProperties2xmlApiProperties(indent,'cfgProperty',name,xIbmConfig['x-ibm-configuration'].properties[name]);
      }
    }
  }
  return xml;
}

// ======================================================
// Save JSON document into policies.xml
// TODO should it be base64 encoded?
function saveDocument(indent,document) {
  var partial = document;
  if (document['x-ibm-configuration'] && document['x-ibm-configuration'].assembly) {
    partial['x-ibm-configuration'].assembly = {};
  }
  var jsonxdoc = jsonx.transform(partial,{ 'xmlprolog': false });
  return ' <document>' + jsonxdoc + '</document>\n';
}

//@@ combine oauth enforcer into one
//    enforcer by default is *and*, APIC will support an *or* in regard to
//    scope enforcing during resource validation
function combineOAuthEnforcer(oauth) {
    var jsonscopes = [];
    for (var n = 0; n < oauth.length; n++) {
        var ascope = oauth[n];
        jsonscopes.push(JSON.parse(ascope["oauth2-validate"]["jsonscopes"]));
    }

    var oauth2Policy = {
              "oauth2-validate": {
                "title" : "security-oauth2-validate",
                "scopes": genScopeToXML(jsonscopes),
                "jsonscopes" : JSON.stringify(jsonscopes),
            }};

    return oauth2Policy;
}

//@@ Function to generate the Security Policy
function processSecuritySection(securitySection, securityDefinitions, OAuthProvider) {
    if (securitySection) {
        var secPolicyArray = [];
        //@@ More than one entry here is an OR scenario
        var securityCount = securitySection.length;
        var oauthEnforcer = []; // in case we need to combine oauth enforcement
        var mfpOauthEnforcer = []; // MobileFirst OAuth policies (won't be aggregated like datapower type)
        //@@ create empty object
        var polAggregator = {};
        var securityEntry;
        for (var index = 0; index < securityCount; index++) {
            polAggregator = {};
            securityEntry = Object.keys(securitySection[index]);
            //More than one entry in securityKey is the AND scenario
            for (var n = 0; n < securityEntry.length; n++) {
                var curEntry = securityEntry[n];
                var a = securityDefinitions[curEntry];
                var e = securityProcessor(curEntry, a, securitySection[index][curEntry]);
                if (a && a.type === 'oauth2' &&
                    e['oauth2-validate'] !== undefined) {
                    if (a['x-tokenIntrospect'] !== undefined && a['x-tokenIntrospect'].url !== undefined &&
                        a['x-tokenIntrospect'].url.trim().length > 0) {
                        e['oauth2-validate']['introspection-url'] = a['x-tokenIntrospect'].url;
                        if (a['x-tokenIntrospect']['tls-profile'] !== undefined) {
                            e['oauth2-validate']['introspection-tls-profile'] = a['x-tokenIntrospect']['tls-profile'];
                        }
                    }
                    if (a['x-scopeValidate'] !== undefined && a['x-scopeValidate'].url !== undefined &&
                        a['x-scopeValidate'].url.trim().length > 0) {
                        e['oauth2-validate']['scope-validate-url'] = a['x-scopeValidate'].url;
                        if (a['x-scopeValidate']['tls-profile'] !== undefined) {
                            e['oauth2-validate']['scope-validate-tls-profile'] = a['x-scopeValidate']['tls-profile'];
                        }
                    }
                    oauthEnforcer.push(e);
                    continue;
                } else if (a && a.type === 'oauth2' &&
                    e['oauth2-validate-mfp'] != undefined &&
                    e['oauth2-validate-mfp']['scopes'] != undefined) {
                    mfpOauthEnforcer.push(e);
                    continue;
                } else {
                    var p = Object.keys(e);
                    var policy = p[0];
                    //@@ check for dup apim Identities
                    //@@ and merge into a single entry
                    if (p.length != 0 && e[policy].type === "apiKey" && polAggregator.hasOwnProperty("apim.appidentity")) {
                        // apim.appidentity.xsl also uses requires property
                        // instead of reworking that logic, and to accommodate
                        // future work to offer customizable policy name
                        // continue using required property and inject it
                        // into the resulting policy.
                        var polName = e[policy].name.toUpperCase();
                        if (polName === 'CLIENT_SECRET' || polName === 'X-IBM-CLIENT-SECRET') {
                            e[policy].requires = 'clientIDAndSecret';
                        } else {
                            e[policy].requires = 'clientID';
                        }
                        if (e[policy].requires === 'clientID' || e[policy].requires === 'clientIDAndSecret') {
                            //@@ Loop here and consolidate any apiKey
                            //@@ Client/Secret into a single entry.
                            if (polAggregator["apim.appidentity"].requires === "clientID" &&
                                e[policy].requires === "clientIDAndSecret") {
                                polAggregator["apim.appidentity"].requires = "clientIDAndSecret";
                            } else if (polAggregator["apim.appidentity"].requires === "clientIDAndSecret" &&
                                e[policy].requires === "clientID") {
                                e[policy].requires = "clientIDAndSecret";
                                polAggregator["apim.appidentity"] = e[policy];
                            }
                        } else {
                            polAggregator[policy] = e[policy];
                        }
                    } else if (p.length != 0) {
                        polAggregator[policy] = e[policy];
                    }
                } // end of else
            } // end of for (n<securityEntry.length)

            // all non-oauth security policies have been aggregated
            // and oauth policies pushed
            // now that all policies are done, check to see whether we still
            // need to deal with oauth
            // notice we group all oauth scope at the end, the implication is
            // all security check will happen, before the scope check
            if (oauthEnforcer.length > 0) {
                var enforcer;
                if (oauthEnforcer.length === 1) {
                    enforcer = oauthEnforcer[0];
                } else {
                    enforcer = combineOAuthEnforcer(oauthEnforcer);
                }
                var enforcerPolicy = (Object.keys(enforcer))[0];
                polAggregator[enforcerPolicy] = enforcer[enforcerPolicy];
                oauthEnforcer = [];
            }

            // add MobileFirst oauth policy (Can't be combined)
            else if (mfpOauthEnforcer.length > 0) {
                var enforcer;
                for (var n = 0; n < mfpOauthEnforcer.length; n++) {
                    enforcer = mfpOauthEnforcer[n];
                    var enforcerPolicy = (Object.keys(enforcer))[0];
                    polAggregator[enforcerPolicy] = enforcer[enforcerPolicy];
                }
                mfpOauthEnforcer = [];
            }
            // Check a valid security was created before appending.
            if (Object.keys(polAggregator).length != 0)
                secPolicyArray.push(polAggregator);
        } // end of for (index<securityCount)

        //client_id and client_secret could be combined as ClientIdAndSecret
        //which will change the count of policies in array and could
        //differ with the count of policies in securityEntry.
        //Use a flag to denote if this is a single entry (or null)
        //checking for len<=1 is an overkill compared to testing for 1
        var isSingleSecEntry = (secPolicyArray && secPolicyArray[0] && Object.getOwnPropertyNames(secPolicyArray[0]).length <= 1 );

        //simply checking for OAuthProvider is insufficient since it
        //could be empty but valid. Instead set a flag to denote
        //when the object actually contains at least one property
        //as an indication of instantiated object
        var isOAuthProvider = (OAuthProvider && Object.keys(OAuthProvider).length > 0);

        //Policy can be injected directly (unwrapped) if
        //it is the only policy in security section
        //or if it is part of OAuth provider.
        //OAuth provider is injected later elsewhere in this file.
        //or if the section is empty, we do not want to return an
        //empty apim.security:{} object
        if (securitySection.length <= 1 && (securityEntry.length <= 1 || isSingleSecEntry || isOAuthProvider)) {
               return secPolicyArray;
        }

        var secPolicy = {
            "apim.security": secPolicyArray
        };
        if (verbose)
            apim.console.debug('request.swagger.js: processSecuritySection: secPolicy=' + secPolicy);

        return secPolicy;
    } //end of if (securitySection)
}

function getOperationIds(paths)
{
    var operationIds = {};
    //@@ Look for operationId within paths
    //@@ return true when we find one
    for (var pathURL in paths) {
        //@@ skip loop if the property is from prototype
        if (!paths.hasOwnProperty(pathURL)) continue;

        var obj = paths[pathURL];
        for (var httpVerb in obj) {
            if(!obj.hasOwnProperty(httpVerb)) continue;
            var operationId = paths[pathURL][httpVerb].operationId;
            if (operationId!==undefined && operationId != null)
            {
                var operation = {};
                operation.verb = httpVerb;
                operation.path = pathURL;
                operation.id = operationId;
                if (paths[pathURL][httpVerb]['x-ibm-soap']!==undefined)
                {
                    operation.soap = paths[pathURL][httpVerb]['x-ibm-soap'];
                }
                operationIds[operationId] = operation;
            }
        }
    }
    //@@ inspected all the paths and operations for operationIds
    return operationIds;
}


//@@ Function to check if any of the APIs
//@@ contain their own security section
function anyAPIPathsContainsSec(paths)
{
    //@@ Look for security within paths
    //@@ return true when we find one
    for (var pathURL in paths) {
        //@@ skip loop if the property is from prototype
        if (!paths.hasOwnProperty(pathURL)) continue;

        var obj = paths[pathURL];
        for (var httpVerb in obj) {
            if(!obj.hasOwnProperty(httpVerb)) continue;

            if (paths[pathURL][httpVerb].security)
            {
                //@@ SecurityDefined for this path
                return true;
            }
        }
    }

    //@@ inspected all the paths and operations
    //@@ without finding a security section
    return false;
}


//@@ Function to go thru and generate the security policy for each path
//@@ and then wrap them around an op-switch
function generateOpSwitchSecPol(globalPolicy, paths, securityDefinitions)
{
    var opSwitchPol = { "operation-switch": {
                "title": "security-OpSwitch",
                "case" : [] }};
    var caseCount = 0;

    //@@ Look for security within paths
    for (var pathURL in paths) {
        //@@ skip loop if the property is from prototype
        if (!paths.hasOwnProperty(pathURL)) continue;

        var obj = paths[pathURL];
        for (var httpVerb in obj) {
            if(!obj.hasOwnProperty(httpVerb)) continue;

            if (paths[pathURL][httpVerb].security)
            {
                //@@ SecurityDefined for this path
                if (paths[pathURL][httpVerb].security.length >= 1)
                {
                    var localPol = processSecuritySection(paths[pathURL][httpVerb].security, securityDefinitions, {});
                    opSwitchPol["operation-switch"].case[caseCount++] = genSecurityOpSwitchEntry(pathURL, httpVerb, paths[pathURL][httpVerb].operationId, localPol);
                }
                //@@ if policy is defined but, empty [], we do not add
                //@@ a security entry for this path/verb.
            } else if(globalPolicy != undefined){
                //@@ Use Global Policy
                opSwitchPol["operation-switch"].case[caseCount++] = genSecurityOpSwitchEntry(pathURL, httpVerb, paths[pathURL][httpVerb].operationId, globalPolicy);
            }
        }
    }
    return opSwitchPol;
}

//@@ quick function to look thru the incoming flow
//@@ for an operation-switch
function assemblyContainsOpSwitch(theFlow)
{
    //@@ Search the assembly function for any op-switch.
    if (theFlow)
    {
        for (var i in theFlow)
        {
            if (!theFlow.hasOwnProperty(i)) continue;

            var obj = theFlow[i];
            if (obj.hasOwnProperty("operation-switch"))
                return true;
        }
    }
    return false;
}


//@@ the incoming theFlow is guaranteed to contain
//@@ an operation switch.  Need to merge the
//@@ incoming security operation switch with it
function mergeOpSwitchPolicy(theFlow, secOpSwitch)
{
        //@@ Search the assembly function for any op-switch.
    if (theFlow)
    {
        for (var i in theFlow)
        {
            if (!theFlow.hasOwnProperty(i)) continue;

            var obj = theFlow[i];
            if (obj.hasOwnProperty("operation-switch"))
            {
                //@@ this is the entry we need to merge
                obj["operation-switch"]["case"] = secOpSwitch["operation-switch"]["case"].concat(obj["operation-switch"]["case"]);
                break;
            }
        }
    }
}

//@@ create the body of an operation switch
function genSecurityOpSwitchEntry(pathURL, httpVerb, operationId, policy)
{
    var match = {};
    if (operationId===undefined || operationId == null) {
        match =  {
                "verb": httpVerb,
                "path": pathURL
            };  
    } else {
        match = operationId;
    }
    
    var entry = {
        "operations": [
                        match
                    ],
                    "execute": [ policy ]
                };
    return entry;
}

function securityProcessor(secDefName, sec, scope)
{
    if (!sec) {
      apim.console.error('securityProcessor: definition not found:' + secDefName);
      return {};
    }
    if (sec.type === "apiKey")
    {   //@@ (a) APP.identity
        //@@ valid secret query name values: appSecret, client_secret
        //@@ valid secret header name values: X-IBM-Client-Secret
        //@@ valid client ID query name values: appID, client_id
        //@@ valid client ID header name values: X-IBM-Client-Id
        var nameAttr = sec.name;
        if (nameAttr === "appId" || nameAttr === "client_id" || nameAttr === "X-IBM-Client-Id")
        {
            var securityPolicy = genAPIMIdentity("clientID", sec.in, sec.type, sec.name);
            return securityPolicy;
        }
        else if(nameAttr === "appSecret" || nameAttr === "client_secret" || nameAttr === "X-IBM-Client-Secret")
        {
            var securityPolicy = genAPIMIdentity("clientIDAndSecret", sec.in, sec.type, sec.name);
            return securityPolicy;
        } else {
            // need to return some data for security items that are not apim specific - so use name
            var securityPolicy = genAPIMIdentity(nameAttr, sec.in, sec.type, sec.name);
            return securityPolicy;
        }
    }
    else if (sec.type === "basic")
    {
        // Basic Auth
        // (a) URL
        // (b) SSL Profile
        if (sec["x-ibm-authentication-url"])
        {   // (a) URL
            var basicAuthPolicy = genAPIMBasicAuthURL(sec["x-ibm-authentication-url"].url, sec["x-ibm-authentication-url"]["tls-profile"]);
            return basicAuthPolicy;
        }
        else if (sec["x-ibm-authentication-registry"])
        {
          // Basic Auth with LDAP
          return getAPIMBasicAuthLDAP(sec);
        }
        else
        {
          apim.console.error('Security of type \'basic\' missing required property.');
        }
    }
    else if(sec.type === "oauth2")
    {
        if (scope !== undefined)
        {
           var oauth2Policy;
           var isMobileFirstSecDefOauth = mfpProvidersManager.isMobileFirstSecDef(mfpProviders, sec.authorizationUrl);
            if(isMobileFirstSecDefOauth){
              var mfpParams = mfpProvidersManager.createMobileFirstSecDefParams(mfpProviders, sec.authorizationUrl);
              // Read scopes from SecDef for case of local security policy - see https://github.ibm.com/apimesh/apim-ui/issues/1254 more details
              var mfpScopes = Object.keys(sec.scopes);
              oauth2Policy = {
                "oauth2-validate-mfp": {
                "title" : "security-oauth2-validate-mfp",
                "mfpProviderName" : mfpParams.mfpProviderName,
                "azserver" : mfpParams.azserver,
                "confClientID" : mfpParams.confClientID,
                "confClientPass" : mfpParams.confClientPass,
                "tlsProfile": mfpParams.tlsProfile,
                "scopes": mfpScopes.join(' ')
                 }
              }; 
            }
            else{
                oauth2Policy = {  
                  "oauth2-validate": {
                  "title" : "security-oauth2-validate",
                  "scopes": genScopeToXML(scope), 
                  "jsonscopes" : JSON.stringify(scope), 
                }};
            } 

            return oauth2Policy;
        } 
        else
        {
            apim.console.error("Oauth Configuration requires scope.");
        }
    }
    // LDAP or Registry
    // Not a known or supported type.
    return {};
}

//@@ function to convert scope to xml
function genScopeToXML(scopes)
{
  var beforestr = "<set><scope>";
  var afterstr  = "</scope></set>";
  var scopestr = "";
  
  for (var i in scopes) {
    if (scopes.hasOwnProperty(i)) {

      if (Array.isArray(scopes[i])) {
        beforestr = "<set>";
        afterstr  = "</set>";
        scopestr += "<scope>";
        for (var j = 0; j < scopes[i].length; j++) {
           scopestr += scopes[i][j] + " ";
        }
        scopestr = scopestr.trim() + "</scope>";
      }
      else {
        scopestr += scopes[i] + " ";
      }
    }
  }
  scopestr = beforestr + scopestr.trim() + afterstr;
  return scopestr;
}

//@@ Funtion to generate the apim.identity policy
//@@
function genAPIMIdentity(req_str, in_str, type_str, name_str)
{
    var apimId = {"apim.appidentity" : {
            "title": "security-appID",
            "requires": req_str,
            "in": in_str,
            "type": type_str,
            "name": name_str
           }};
    return apimId;
}

//@@ function to generate apim.basicauth url policy
//@@
function genAPIMBasicAuthURL(url_str, url_tls)
{
    if (url_str !== undefined)
    {
      var basicAuthURL = { "apim.basicauth": {
            "title" : "security-basic-auth-url",
            "type" : "authUrl",
            "authenticationURL" : url_str,
            "authenticationURLsslProfile" : (typeof(url_tls) === 'undefined' ? '' : url_tls) 
           }};
       return basicAuthURL;
     } else {
       apim.console.error('security BasicAuth missing required property.');
       return {};
     }
}

//@@ Security Definition for Basic with LDAP
//@@ <securityDefinitionName>:
//@@   type: basic
//@@   x-ibm-authentication-registry: <nameofregistryobject>
function getAPIMBasicAuthLDAP(secDef) {
  return {
    "apim.basicauth": {
      "title": secDef.description ? secDef.description: "",
      "type": "ldap",
      "x-ibm-authentication-registry": secDef['x-ibm-authentication-registry']
    }
  };
}

exports.translateSwaggerToXML = translateSwaggerToXML;
