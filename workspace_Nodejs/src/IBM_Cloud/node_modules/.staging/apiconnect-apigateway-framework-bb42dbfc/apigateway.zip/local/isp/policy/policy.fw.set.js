// ***************************************************** {COPYRIGHT-TOP} ***
//* Licensed Materials - Property of IBM
//* 5725-L30, 5725-Z22, 5725-Z63, 5725-U33
//*
//* (C) Copyright IBM Corporation 2016, 2017
//*
//* US Government Users Restricted Rights - Use, duplication, or
//* disclosure restricted by GSA ADP Schedule Contract with IBM Corp.
// ********************************************************** {COPYRIGHT-END}**
//
var apim = require('local:///isp/policy/apim.custom.js');
var hm = require('header-metadata');
//
//var dbglog = console.options({'category':'xsltmsg'});
//dbglog.debug('policy.gw.set.js: context === ' + JSON.stringify(apim.getContext()));

// Ensure we set a User-Agent header
var userAgent = hm.current.get('User-Agent');
if (userAgent!==undefined) {
    var _apimgmt = session.name('_apimgmt');
    _apimgmt.setVar('user-agent', userAgent);
}
hm.current.set('User-Agent', apim.APIM_USER_AGENT);

//PLACEHOLDER

