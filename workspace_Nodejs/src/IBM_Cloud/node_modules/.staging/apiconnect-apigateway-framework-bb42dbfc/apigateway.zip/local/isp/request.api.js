// ***************************************************** {COPYRIGHT-TOP} ***
//* Licensed Materials - Property of IBM
//* 5725-L30, 5725-Z22, 5725-Z63, 5725-U33 
//*
//* (C) Copyright IBM Corporation 2017
//*
//* US Government Users Restricted Rights - Use, duplication, or
//* disclosure restricted by GSA ADP Schedule Contract with IBM Corp.
// ********************************************************** {COPYRIGHT-END}**
//
// Makes requests to the API's list for a catalog and writes the api we are looking for to session.out/cache
//

var apimutil = require('./apim.util.js');
var headermeta = require('header-metadata');
var servicemeta = require('service-metadata');
var dpglog = console.options({'category':'apiconnect'});
var deployInfo = apimutil.loadDeployInfo();
//dpglog.error("Deploy Info: " + JSON.stringify(deployInfo));

var urlPrefix = deployInfo.gateway.xml.replace("catalog:", "");
//dpglog.error("urlPrefix: " + urlPrefix);

servicemeta.mpgw.skipBackside = true;
var headers = headermeta.current.headers;
var postfix = '?type=edge-gateway';
var sourceUri = servicemeta.URI;

//Grab id of the api we want to cache
var apiId = sourceUri.substring(sourceUri.indexOf("/apis") + 6, sourceUri.indexOf("?"));
var catalogId = sourceUri.substring(sourceUri.indexOf("/catalogs") + 10, sourceUri.indexOf("/apis"));

//Build apisUrl to get list of apis in the catalog
var apisUrl = urlPrefix + "/"+ catalogId + deployInfo.endpoints['swagger-suffix'] + postfix; 
//dpglog.error("apisUrl: " + apisUrl);

//Send request
apimutil.getDocument(apisUrl, headers, function (err, json) {
    if(json){
        //Find API
        var keys = Object.keys(json);
        for(var i=0;i<keys.length;i++){
            if(json[keys[i]].id === apiId){
                 //Found API, cache it
                 session.output.write(json[keys[i]]);
                 return;
            }
        }
        session.output.write({ 'error': 'Not Found In List.' });
    }else{
        session.output.write({ 'error': err });
    }
});