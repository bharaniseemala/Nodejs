// ***************************************************** {COPYRIGHT-TOP} ***
//* Licensed Materials - Property of IBM
//* 5725-L30, 5725-Z22, 5725-Z63, 5725-U33
//*
//* (C) Copyright IBM Corporation 2016, 2017
//*
//* US Government Users Restricted Rights - Use, duplication, or
//* disclosure restricted by GSA ADP Schedule Contract with IBM Corp.
// ********************************************************** {COPYRIGHT-END}**
var headermeta = require('header-metadata');
var _apimgmt = session.name('_apimgmt');

//@@ restore saved headers
//@@ if they were saved before routing to internal echo service (webapi-internal)
//@@ remove them once we restored, no need for that information to stay in the context.
var savedHeaders = _apimgmt.getVariable('headers-saved');
if (savedHeaders) {
  for (var hdr in savedHeaders) {
    if (savedHeaders.hasOwnProperty(hdr)) {
      headermeta.current.set(hdr,savedHeaders[hdr]);
    }
  }
  _apimgmt.deleteVariable('headers-saved');
}
