// ***************************************************** {COPYRIGHT-TOP} ***
//* Licensed Materials - Property of IBM
//* 5725-L30, 5725-Z22, 5725-Z63, 5725-U33
//*
//* (C) Copyright IBM Corporation 2016, 2017
//*
//* US Government Users Restricted Rights - Use, duplication, or
//* disclosure restricted by GSA ADP Schedule Contract with IBM Corp.
// ********************************************************** {COPYRIGHT-END}**

var apim = require('local:///isp/policy/apim.custom.js');
var properties = apim.getPolicyProperty();
var exceptionName = properties.name;
var verbose = apim.verbose;

if (exceptionName === undefined || exceptionName.length === 0)
{
  exceptionName = 'runtime exception';
  if (verbose) apim.console.debug('policy: apim.throw: missing name');
}

apim.error(exceptionName, '500', 'Internal Server Error', properties.message );
