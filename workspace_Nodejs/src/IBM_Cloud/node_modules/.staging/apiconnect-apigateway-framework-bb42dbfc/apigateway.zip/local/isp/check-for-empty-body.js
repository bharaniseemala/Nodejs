// ***************************************************** {COPYRIGHT-TOP} ***
//* Licensed Materials - Property of IBM
//* 5725-L30, 5725-Z22, 5725-Z63, 5725-U33
//*
//* (C) Copyright IBM Corporation 2016, 2017
//*
//* US Government Users Restricted Rights - Use, duplication, or
//* disclosure restricted by GSA ADP Schedule Contract with IBM Corp.
// ********************************************************** {COPYRIGHT-END}**

session.INPUT.readAsBuffers(function(err, dataBuffers){
  if(err){
      //
  } else {
      if (dataBuffers.length === 0){
        session.name('_apimgmt').setVar('zero-length-body', true);
      } else {
          session.name('_apimgmt').setVar('zero-length-body', false);
      }
  }
});
