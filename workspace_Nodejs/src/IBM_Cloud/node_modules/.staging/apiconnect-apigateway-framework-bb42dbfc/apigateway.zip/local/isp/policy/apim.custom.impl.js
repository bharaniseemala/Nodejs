// ***************************************************** {COPYRIGHT-TOP} ***
// Licensed Materials - Property of IBM
// 5725-L30, 5725-Z22, 5725-Z63, 5725-U33
//
// (C) Copyright IBM Corporation 2016, 2017
//
// US Government Users Restricted Rights - Use, duplication, or
// disclosure restricted by GSA ADP Schedule Contract with IBM Corp.
// ********************************************************** {COPYRIGHT-END}**
var dbg = false;
var context = session.name('_apimgmt');
if (context !== undefined) {
  var verbose_level = context.getVar('policy/verbose_level');
  if (verbose_level !== undefined)
  {
    if (verbose_level > 0)
    {
      dbg = true;
    }
  }
}
const dbglog = console.options({'category':'apiconnect'});

// ****************************************************************************
// Find and Replace context variables and parameters
// - context variables - $(variable)
// - parameters - {parameter}
// @param input - the original input, e.g. 'https://$(host)/foo'
// @param callbackToResolve - a function that will be called to resolve
//        the value of a provided variable, e.g. callbackToResolve('host')
function resolveVariables(input,leaveUndefined,callbackToResolve) {
  if (dbg) dbglog.debug('resolveVariables: ' + input);
  var regex;
  // going to look for $(variables)... if we are matching $(request.headers)
  // the resulting replacement may be an object vs string
  if (typeof input === 'string' && input.indexOf('$(') > -1) {
    regex = /(\$\([a-zA-Z\-\.\_\:0-9\+]+\))/g;
    input = matchAndReplace(input,regex,callbackToResolve,false,leaveUndefined);
  }
  // going to look for {parameters}... before searching for params, make
  // sure `input` is still a string and not a replaced object.
  if (typeof input === 'string' && input.indexOf('{') > -1) {
    regex = /(\{[a-zA-Z\-\.\_0-9\+]+\})/g;
    input = matchAndReplace(input,regex,callbackToResolve,true,leaveUndefined);
  }
  return input;
}

function matchAndReplace(input,regex,callbackToResolve,isParam,leaveUndefined) {
  if (dbg) dbglog.debug('matchAndReplace: ' + input);
  var loopmax = 60;
  var match = regex.exec(input);
  var varname, value;
  while (match !== null && loopmax-->0) {
    if (isParam) {
      // Check for string literal. 
      if(match.index > 0 && input.charAt(match.index - 1) === '$')
      {
        continue;
      }
      
      varname = match[1].substring(1,match[1].length-1); // remove {}
      if (isNaN(varname)) {
        value = callbackToResolve('request.parameters.' + varname);
      } else {
        match = regex.exec(input);
        continue;
      }
    }
    else {
      varname = match[1].substring(2,match[1].length-1); // remove $()
      value = callbackToResolve(varname);
    }
    if (value !== undefined || !leaveUndefined) { // need to explicity check for not undefined as we don want to catch '' (empty string)
      if (value === undefined) {
        value = '';
      }
      input = replaceValues(input,match[1],value);
      regex.lastIndex -= match[1].length;
    }
    match = regex.exec(input);
  }
  return input;
}

function replaceValues(input,match,value) {
  if (input === match) { // full match, replace input variable
    input = value;
  }
  else if (input.indexOf(match) > -1)
  {
    input = input.replace(match,value);
    input = replaceValues(input,match,value);
  }
  return input;
}

// exports.resolveVariables = resolveVariables;

// ****************************************************************************
// Find and Replace context variables and parameters in the values of a
// JavaScript object or array
function resolveVariablesInObject(object,leaveUndefined,callbackToResolve) {
  if (dbg) dbglog.debug('resolveVariablesInObject: ' + typeof object + ' ' + JSON.stringify(object));
  if (typeof object === 'object') {
    var result = object;
    for (var i in object) {
      if (object.hasOwnProperty(i)) {
        result[i] = resolveVariablesInObject(object[i],leaveUndefined,callbackToResolve);
      }
    }
    return result;
  }
  else {
    return resolveVariables(object,leaveUndefined,callbackToResolve);
  }
}

exports.resolveVariablesInObject = resolveVariablesInObject;

//****************************************************************************
//Fetches a definition from the Swagger document in context.
//If this definition defines other definitions, it will traverse them
//resolving them into a JavaScript object.
//
//Logic will only traverse references within the same Swagger document.
function getSwaggerDefinition(swaggerDoc,defName,processedReferences,definitionOnly) {
  if (!defName || typeof defName !== 'string') {
   dbglog.error('getSwaggerDefinition: invalid reference: ' + defName);
  return undefined;
  }
  var defNameSplit = defName.split('/');
  if (defNameSplit[0] != '#') {
    dbglog.error('getSwaggerDefinition: invalid reference: ' + defName);
    return undefined;
  }
  defNameSplit.shift(); // remove the #
  var definition = swaggerDoc;
  for (var i=0; i<defNameSplit.length; i++) {
    definition = definition[defNameSplit[i]];
    if (!definition) {
      break;
    }
  }
  if (!definition) {
    dbglog.error('getSwaggerDefinition: definition not found: ' + defName);
    return undefined;
  }

  // definitionOnly defaults to false, so continue processing and resolve the definition references unless
  // this argument is specified as true, in which case just the unresolved definition is returned.
  if (!definitionOnly) {
    // the first call of this function will not provide processedReferences, initialize to an empty array
    if (processedReferences === undefined) {
      processedReferences = [];
    }

    // make a new copy of the processedReferences array so the recursive calls pass in just what has
    // been done previously in this hierarchy but the current reference at sibling levels will not
    // be considered a circular reference.
    var thisProcessedReferences = processedReferences.slice(0);
    // current definition name not processed yet?
    if (thisProcessedReferences.indexOf(defName) === -1) {
      // add the current definition name to the processed list
      thisProcessedReferences.push(defName);
      return traverseSwaggerDefinition(swaggerDoc,definition,thisProcessedReferences);
    } else {
      dbglog.error('getSwaggerDefinition: circular definition is ignored: ' + defName);
      return {};
    }
  } else {
    return definition;
  }
}

function traverseSwaggerDefinition(swaggerDoc,object,processedReferences) {
  for (var i in object) {
    if (object.hasOwnProperty(i)) {
      if (i === '$ref') {
        var newobj = getSwaggerDefinition(swaggerDoc,object[i],processedReferences);
        for (var j in newobj) {
          if (newobj.hasOwnProperty(j)) {
            object[j] = newobj[j];
          }
        }
        delete object[i];
      }
      else if (object[i] !== undefined && object[i] !== null && typeof object[i] === 'object') {
        if (object[i].constructor !== Array) {
          // object, not an array, traverse over the object
          object[i] = traverseSwaggerDefinition(swaggerDoc,object[i],processedReferences);
        } else {
          // an array, traverse over each array element
          for (var j=0; j<object[i].length; j++) {
            object[i][j] = traverseSwaggerDefinition(swaggerDoc,object[i][j],processedReferences);
          }
        }
      }
    }
  }
  return object;
}

exports.getSwaggerDefinition = getSwaggerDefinition;

exports.getManagedObject = getManagedObject;

function getManagedObject(options, type) {

  var id = options.id || null;
  var name = options.name || null;
  var version = options.version || null;
  var inProperty = options.property || null;
  var inType = type || null;
  var asFilename = options.asFilename || null;
  var asObject = options.asObject || null;

  var _apimgmt = session.name('_apimgmt');
  if (!_apimgmt) {
    dbglog.error('getTLSProfileObjName: _apimgmt session missing.');
    return undefined;
  }

  var managedObjectsMap = _apimgmt.getVariable('managed-objects');
  var managedObjectsMap = managedObjectsMap.item(0).getElementsByTagName("managed-objects").item(0).lastChild.textContent;

  try{
   managedObjectsMap = JSON.parse(managedObjectsMap);
  }
  catch(err){
    dbglog.err(error.stack);
  }

  var orgId = _apimgmt.getVariable('tenant-orgId');
  var managedObject = undefined;
  var property = undefined

  managedObjectsMap = managedObjectsMap[orgId];
  managedObjectsMap = managedObjectsMap[type];

  if (managedObjectsMap){
    if (name && name.indexOf(':latest') === -1) {
      if (name.indexOf(':') > -1) {
        managedObject = managedObjectsMap['by-nameAndVersion'][name];
      } else {
        // version 1.0.0 is the default version if none is specified
        managedObject = managedObjectsMap['by-nameAndVersion'][name + ':1.0.0'];
        if (managedObject) {
          console.info('managed-object: name:' + name + ' ver:' + managedObject['version'] );
        } else {
          console.error('managed-object: name:' + name + ' ver: 1.0.0 not found');
        }
      }
    }
    if (name && !managedObject && name.indexOf(':latest') > -1) {
      var realname = name.substring(0, name.indexOf(':latest'));
      managedObject = managedObjectsMap['by-name'][realname];
      //TODO Handle exception from failure to sort
      managedObject = managedObject.length > 1 ? managedObject.sort(simpleSymVer) : managedObject;
      managedObject = managedObjectsMap['by-nameAndVersion'][managedObject[managedObject.length - 1]];
      if (managedObject) {
        console.info('managed-object: name:' + name + ' ver:' + managedObject['version'] );
      }
    }
    if (name && version) managedObject = managedObjectsMap['by-nameAndVersion'][name+':'+version];
    if (id && !managedObject) managedObject = managedObjectsMap['by-nameAndVersion'][managedObjectsMap['by-id'][id]];
    if (managedObject && asObject === 'true') {
      console.info('managed-object asObject:' + name + ' (ver:' + managedObject['version'] + ')= ' + inType + '-' + managedObject['id']);
      managedObject = inType + '-' + managedObject['id'];
    }
    if (!managedObject) {
      console.error('managed-object: name:' + name + ' type:' + inType + ' not found');
    }
    if (managedObject && inProperty) {
      if (asFilename === 'true') {
         console.info('managed-object asFileName:' + name + ' (ver:' + managedObject['version'] + ')= ' + inType + '-' + managedObject['id'] + '-' + inProperty);
      }
      managedObject =  (asFilename === 'true') ? (inType + '-' + managedObject['id'] + '-' + inProperty) : managedObject['properties'][inProperty];

      const b64encPrefix = '!BASE64_ENC!_';
      var isString = false;
      if (managedObject) {
        isString = typeof managedObject == 'string';
      }
      if (isString && (managedObject.indexOf(b64encPrefix) !== -1)) {
        const crypto = require('crypto');
        var b64part = managedObject.substring(b64encPrefix.length);
  
        var buffer = new Buffer(b64part, 'base64');
        var iv = buffer.slice(0,16);
        var payload = buffer.slice(16);
  
        const decipher = crypto.createDecipheriv('aes256-cbc', 'webapi-oauth-token-ss', iv);
        decipher.update(payload);
        managedObject = String(decipher.final());
      }
    }
  }
  
  return managedObject;
}

function simpleSymVer(a, b){

  var aVer = a.substring(a.indexOf(':') + 1);
  var bVer = b.substring(b.indexOf(':') + 1);

  try {
    var aVerToks = aVer.split('.');
    var bVerToks = bVer.split('.');
  }
  catch(err){
    console.info("managed-object: version parse error");
    return 0;
  }
  if (aVerToks && bVerToks && (aVerToks.length === bVerToks.length) && (aVerToks > 1)) {
    for (var i = 0; i < aVerToks.length; i++){
      if (aVerToks[i] < bVerToks[i]) {
        console.debug("managed-object: " + a + "<" + b);
        return -1
      }
      if (aVerToks[i] > bVerToks[i]) {
        console.debug("managed-object: " + a + ">" + b);
        return 1;
      }
      continue;
    }
  } else {  //number of dots don't match, fall back to string compare
      if (a < b) {
        console.debug("managed-object: " + a + "<" + b);
        return -1
      }
      if (a > b) {
        console.debug("managed-object: " + a + ">" + b);
        return 1;
      }
  }

  return 0;
}
