// ***************************************************** {COPYRIGHT-TOP} ***
//* Licensed Materials - Property of IBM
//* 5725-L30, 5725-Z22, 5725-Z63, 5725-U33
//*
//* (C) Copyright IBM Corporation 2016, 2017
//*
//* US Government Users Restricted Rights - Use, duplication, or
//* disclosure restricted by GSA ADP Schedule Contract with IBM Corp.
// ********************************************************** {COPYRIGHT-END}**
//
// Makes requests to the API /v1/catalogs in attempt to build the
// list of all catalogs
//
// Returns gateway.xml
//
var apim = require('local:///isp/policy/apim.custom.js');
var apimutil = require('local:///isp/apim.util.js');
var headermeta = require('header-metadata');
var servicemeta = require('service-metadata');
var target = headermeta.current.get('X-Target-URL');
var catalogs = undefined;
var cloudMetadata = undefined;
var dbg = apim.verbose;
var profilesDoc = undefined;
var uniqueCatalogs = undefined;
var allFetched = undefined;

// HEAD request - cache revalidation - return 200 OK
if (servicemeta.protocolMethod === 'HEAD') {
  servicemeta.mpgw.skipBackside = true;
  headermeta.response.statusCode = 200;
  return;
}

// Copy request headers:
headermeta.current.remove('X-Target-URL');
headermeta.current.remove('Host');

// ===========================================================================
// MAIN:
// - fetch /v1/catalogs
// ===========================================================================

// set defaults defined in GatewaysImpl.createDeployXml (GatewaysImpl.java)
var v1$catalog = target;
var v1$catalog$cloud = target.split('?')[0] + '/cloud-metadata?type=edge-gateway';
var clusterId = 'id:onpremi:cluster';  // just set the default to that used in onpremi tests

// use local://gwapi/deploy.xml values if provided
var deployInfo = apimutil.loadDeployInfo();
if (deployInfo) {
    if (deployInfo.endpoints['cloud-metadata-suffix']) {
        v1$catalog$cloud = target.split('?')[0] + deployInfo.endpoints['cloud-metadata-suffix'] + '?type=edge-gateway';
    }
    if (deployInfo.gateway['cluster-id']) {
        clusterId = deployInfo.gateway['cluster-id'];
    }
}
if (dbg) apim.console.debug('gateway-xml: fetching ' + v1$catalog);

apimutil.getDocument(v1$catalog, headermeta.current.headers, function (err, json) {
  catalogs = json || [ { 'error': err } ];
  if (dbg) apim.console.debug('gateway-xml: fetching ' + v1$catalog$cloud);
  apimutil.getDocument(v1$catalog$cloud, headermeta.current.headers, function (err, json) {
    cloudMetadata = json || [ { 'error': err } ];
    apim.console.debug("TLS Before filtering->["+catalogs.length+"]");
    uniqueCatalogs = getUniqueCatalogEntries(catalogs);
    apim.console.debug("TLS After filtering->["+uniqueCatalogs.length+"]");
    allFetched = uniqueCatalogs.length;
    addTLSProfiles_batch();
  });
});

// Catalog fetch complete, create 'gateway.xml'
function done() {
  var xml;
  if (dbg) {
    apim.console.debug('gateway-xml: done fetching ' + target);
    apim.console.debug('gateway-xml: catalogs' + JSON.stringify(catalogs));
  }
  
  try {
    xml  = '<gateway version="5.0.0" name="gw1">\n';
    xml += ' <elb url="' + v1$catalog$cloud + '" />\n';
    xml += addNamingSectionAsXML(' ');
    xml += ' <tenants>\n';
    xml += addCatalogsAsXML('  ');
    xml += ' </tenants>\n';
    xml += ' <tls-profiles>\n';
    xml += profilesDoc + '\n';
    xml += ' </tls-profiles>\n';
    xml += '</gateway>\n';
    session.output.write(xml);

    if (catalogs && catalogs[0] && catalogs[0].error) {
      throw catalogs[0].error;
    }
    servicemeta.mpgw.skipBackside = true;
    headermeta.current.set('Content-Type','application/xml');
  }
  catch (error) {
    apim.console.error('gateway-xml: failed to build: ' + JSON.stringify(catalogs));
    apim.console.error('gateway-xml: error: ' + error);
    servicemeta.mpgw.skipBackside = true;
    headermeta.response.statusCode = 500;
  }
}

function findGWServiceForCluster() {
    var gwService;
    if (catalogs && catalogs[0] && catalogs[0]['gw-services']) {
        for (var j = 0; j < catalogs[0]['gw-services'].length; j++) {
            var catGWService = catalogs[0]['gw-services'][j];
            if (catGWService.id === clusterId) {
                gwService = catGWService;
            }
        }
    }
    return gwService;
}

function findClusterGWServiceForCatalog(gwServices) {
    var gwService;
    if (gwServices!==undefined) {
        for (var j = 0; j < gwServices.length; j++) {
            var catGWService = gwServices[j];
            if (catGWService.id === clusterId) {
                gwService = catGWService;
                break;
            }
        }
    }
    return gwService;
}

function addNamingSectionAsXML(indent) {
  var xml = '';
  var dynDNS='false';
  if (cloudMetadata && cloudMetadata['is-dynamic-dns']) {
    dynDNS = cloudMetadata['is-dynamic-dns'];
  }
  var dnsName = "unknown";
  var dnsNameEscaped = "unknown";
  // Currently we are taking the first catalog
  // First catalog is OK, but we should pick the matching gw-service for our cluster
  var gwService = findGWServiceForCluster();
  if (gwService && gwService['host-name']) {
    dnsName = gwService['host-name'];
    dnsNameEscaped = dnsName.replace(/\./g,'\\\.');
  }
  xml += indent + '<naming dynamicDns="' + dynDNS + '">\n';
  xml += indent + ' <dns>' + apimutil.escapeXML(dnsName) + '</dns>\n'
  xml += indent + ' <dns-escaped>' + apimutil.escapeXML(dnsNameEscaped) + '</dns-escaped>\n';
  xml += indent + '</naming>\n';
  return xml;
}

function addCatalogsAsXML(indent) {
  if (catalogs && catalogs[0] && catalogs[0].error) {
    return indent + '<error>' + catalogs[0].error + '</error>\n';
  }
  var xml = '';
  catalogs.forEach(function(catalog) {
    try {
        var testAppEnabled = catalog['test-app-enabled'] === true ? true : false;
        var testAppClientId = catalog['test-app-credentials'] ? catalog['test-app-credentials']['client-id'] : '';
        var testAppClientSecret = catalog['test-app-credentials'] !== undefined ? catalog['test-app-credentials']['client-secret'] : '';
        var isSpacesEnabled = catalog['space-enabled'] !== undefined ? catalog['space-enabled'].toString() : 'false';
        var customHostname = '';
        var customHosturl = '';
        var customHostnameSet = '';
        var gwService = findClusterGWServiceForCatalog(catalog['gw-services']);
        if (gwService) {
            if (gwService['endpoint-url']) {
                if (gwService['endpoint-url']!==undefined) {
                    // Try and handle urls that have "protocol://host:port"
                    var cgwurl = gwService['endpoint-url'].match(/^(.*?:\/\/)([^\/:]*)(:\\d+)?(.*)$/);
                    var customHostnameValue;
                    if (cgwurl && cgwurl!==undefined && cgwurl[2]!==undefined) {
                        // Log error if not http or https
                        if (cgwurl[1]!==undefined && (cgwurl[1].toLowerCase()==='http://' || cgwurl[1].toLowerCase()==='https://')) {
                            customHostnameValue = cgwurl[2];
                        } else {
                            apim.console.error('gateway-xml: failed to set custom gw url: ' + catalog['endpoint-url'] + ' as it is invalid. Must start http[s]://');
                            customHostnameValue = '';
                        }
                    } else {
                        // Try and handle urls that have "host:port"
                        cgwurl = gwService['endpoint-url'].match(/^([^\/:]*)(:\\d+)?(.*)$/);
                        if (cgwurl && cgwurl!==undefined && cgwurl[1]!==undefined) {
                            customHostnameValue = cgwurl[1];
                        } else {
                            // Otherwise just use the url which should be just "host"
                            customHostnameValue = gwService['endpoint-url'];
                        }
                    }
                    customHostname = '" customHostname="' + apimutil.escapeXML(customHostnameValue.toLowerCase());
                    customHosturl = '" customHosturl="' + apimutil.escapeXML(gwService['endpoint-url']);
                    if (gwService && gwService['host-name']!==undefined) {
                        if (customHostnameValue === gwService['host-name']) {
                            customHostnameSet = '" customHostnameSet="false';
                        } else {
                            customHostnameSet = '" customHostnameSet="true';
                        }
                    }
                }
            }
        }

        xml += indent + '<tenant org="' + apimutil.escapeXML(catalog.organization.name) +
                        '" orgTitle="' + apimutil.escapeXML(catalog.organization.title) +
                        '" env="' + apimutil.escapeXML(catalog.name) +
                        '" envTitle="' + apimutil.escapeXML(catalog.title) +
                        '" defaultEnv="' + catalog.default +
                        '" defaultOrg="' + (catalog.defaultOrg ? 'true' : 'false') +
                        '" url="' + apimutil.escapeXML(catalog.url) + 
                        customHostname + customHosturl + customHostnameSet + 
                        '" test-app-enabled="' + testAppEnabled +
                        '" test-app-client-id="' + testAppClientId +
                        '" test-app-client-secret="' + testAppClientSecret + 
                    '" spaces-enabled="' + isSpacesEnabled + '">\n';
        if (catalog['space-enabled']) {
            catalog.spaces.forEach(function(space) {
                xml += indent + ' <space id="' + space.id +
                                '" name="' + apimutil.escapeXML(space.name) + '"/>\n';
            });
        }
        xml += indent + '</tenant>\n';
    } 
    catch (error) {
        apim.console.error('gateway-xml: failed to add catalog: ' + catalog.organization.name + ' ' +catalog.name);
        apim.console.error('gateway-xml: error: ' + error);
    }
  });
  return xml;
}

//Fire At Will - Request ALL the TLS-Profiles Concurrently
//As many request as we can make all at once

function addTLSProfiles() {
  profilesDoc = {};
  var url = undefined;
  if (allFetched === 0) {
    profilesDoc = '<![CDATA[' + JSON.stringify(profilesDoc) + ']]>';
    done();
  }
  else {
    uniqueCatalogs.forEach(function (catalog, idx) {
      url = catalog.url + "/tls-profiles?type=edge-gateway";
      apimutil.getDocument(url, headermeta.current.headers, cb);
      function cb(err, profiles) {
        if (err) {
          if (dbg) {
            apim.console.debug("Unable to retrieve TLS Profiles for Catalog titled \""+catalog.title+"\"");
            apim.console.debug(err);
          }
        }
        else {
          //apim.console.debug("Processing TLS Profiles for Catalog titled \""+catalog.title+"\"");
          profiles.forEach(function (profile, idx) {
            if (!profilesDoc[catalog.organization.name]){
                profilesDoc[catalog.organization.name] = {};
            }
            if (!profile["org-id"]) {
              if (!profilesDoc["cmc"]){
                  profilesDoc["cmc"] = {};
              }
              profilesDoc["cmc"][profile.name] = "cmc" + "-" + profile.name;
              profilesDoc["cmc"][profile.id] = "cmc" + "-" + profile.name;
            } else {
              profilesDoc[catalog.organization.name][profile.name] = catalog.organization.name + "-" + profile.name;
              profilesDoc[catalog.organization.name][profile.id] = catalog.organization.name + "-" + profile.name;
            }
          });
        }
        if (--allFetched === 0) {
          profilesDoc = '<![CDATA[' + JSON.stringify(profilesDoc) + ']]>';
          done();
        }
      }
    });
  }
}

//Sequential - Request TLS-Profiles on at a time.
//Each call must complete before the next is issued

function addTLSProfiles_serial() {
  profilesDoc = {};
  var url = undefined;
  if (allFetched === 0) {
    profilesDoc = '<![CDATA[' + JSON.stringify(profilesDoc) + ']]>';
    done();
  }
  else {
    function fetchTLSProfile(index){
      var currentCatalog = uniqueCatalogs[index];
      url = currentCatatalog.url + "/tls-profiles?type=edge-gateway";
      apimutil.getDocument(url, headermeta.current.headers, cb);
      function cb(err, profiles) {
        if (err) {
          if (dbg) {
            apim.console.debug("Unable to retrieve TLS Profiles for Catalog titled \""+currentCatatalog.title+"\"");
            apim.console.debug(err);
          }
        }
        else {
          //apim.console.debug("Processing TLS Profiles for Catalog titled \""+catalog.title+"\"");
          profiles.forEach(function (profile, idx) {
            if (!profilesDoc[currentCatalog.organization.name]){
                profilesDoc[currentCatalog.organization.name] = {};
            }
            if (!profile["org-id"]) {
              if (!profilesDoc["cmc"]){
                  profilesDoc["cmc"] = {};
              }
              profilesDoc["cmc"][profile.name] = "cmc" + "-" + profile.name;
              profilesDoc["cmc"][profile.id] = "cmc" + "-" + profile.name;
            } else {
              profilesDoc[currentCatalog.organization.name][profile.name] = currentCatalog.organization.name + "-" + profile.name;
              profilesDoc[currentCatalog.organization.name][profile.id] = currentCatalog.organization.name + "-" + profile.name;
            }
          });
        }
      }
      if (uniqueCatalogs[index + 1]){
        fetchTLSProfile(index + 1);
      } else {
        profilesDoc = '<![CDATA[' + JSON.stringify(profilesDoc) + ']]>';
        done();
      }
    }
  }
}

// Batch - Request the profiles in batches.
// Batch size is dependent on MAXBATCHSIZE
// Atmost MAXBATCHSIZE concurrent connections will be 
// made for each batch.

const MAXBATCHSIZE = 50;
function addTLSProfiles_batch(){
  if (dbg) apim.console.debug("There are "+ allFetched + " unique Catalogs");
  profilesDoc = {};
  if (allFetched === 0) {
    profilesDoc = '<![CDATA[' + JSON.stringify(profilesDoc) + ']]>';
    done();
  } else {
     fetchNextBatch();
  }
}

var batchCounter = 0;
var currentBatchIndex = 0;
function fetchNextBatch(){
  for ( ; uniqueCatalogs[currentBatchIndex] && batchCounter < MAXBATCHSIZE; currentBatchIndex++, batchCounter++){

    var currentCatalog = uniqueCatalogs[currentBatchIndex];
    var url = currentCatalog.url + "/tls-profiles?type=edge-gateway";
    
    apimutil.getDocument(url, headermeta.current.headers, processProfiles.bind({currentCatalog: currentCatalog}));
  }
}

function processProfiles(err, profiles) {
  var currentCatalog = this.currentCatalog;
  if (err) {
    if (dbg) {
      apim.console.debug("Unable to retrieve TLS Profiles for Catalog titled \""+currentCatalog.title+"\"")
      apim.console.debug(err);
    }
  }
  else {
    profiles.forEach(function (profile, idx) {
      if (!profilesDoc[currentCatalog.organization.name]){
          profilesDoc[currentCatalog.organization.name] = {};
      }
      if (!profile["org-id"]) {
        if (!profilesDoc["cmc"]){
            profilesDoc["cmc"] = {};
        }
        profilesDoc["cmc"][profile.name] = "cmc" + "-" + profile.name;
        profilesDoc["cmc"][profile.id] = "cmc" + "-" + profile.name;
      } else {
        profilesDoc[currentCatalog.organization.name][profile.name] = currentCatalog.organization.name + "-" + profile.name;
        profilesDoc[currentCatalog.organization.name][profile.id] = currentCatalog.organization.name + "-" + profile.name;
      }
    });
    
  }
  waitOnBatchCompletion();
}

function waitOnBatchCompletion(){
  batchCounter -= 1;
  allFetched -= 1;
  if ((allFetched === 0)){
    if (dbg) apim.console.debug("TLS-Profile Fetch Complete.");
    profilesDoc = '<![CDATA[' + JSON.stringify(profilesDoc) + ']]>';
    done();
  } else if (batchCounter === 0) {
    fetchNextBatch();
  }
}

//Get a list of unique Catalogs that have TLS Profiles
function getUniqueCatalogEntries(array) {
  var foundentry = [];
  var searchFor = undefined;
  var newArray = array.filter(tester);
  function tester(value, index, inputArray) {
    var hasTLSProfiles = (value ? (value['tls-profile'] ? (value['tls-profile'].count > 0 ? true : false) : false) : false);
    if (value && value.organization && hasTLSProfiles) {
      searchFor = value.organization.name + value.organization.id;
      if (foundentry.indexOf(searchFor) < 0) {
        foundentry.push(searchFor);
        return true;
      }
    }
    return false;
  }
  return newArray;
}
