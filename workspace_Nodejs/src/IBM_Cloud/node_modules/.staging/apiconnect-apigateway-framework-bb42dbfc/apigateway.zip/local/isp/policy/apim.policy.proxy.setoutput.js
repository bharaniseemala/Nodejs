// ***************************************************** {COPYRIGHT-TOP} ***
//* Licensed Materials - Property of IBM
//* 5725-L30, 5725-Z22, 5725-Z63, 5725-U33
//*
//* (C) Copyright IBM Corporation 2016, 2017
//*
//* US Government Users Restricted Rights - Use, duplication, or
//* disclosure restricted by GSA ADP Schedule Contract with IBM Corp.
// ********************************************************** {COPYRIGHT-END}**
//
var apim = require('local:///isp/policy/apim.custom.js');

var hm = require('header-metadata');

var logPrefix = 'apim.policy.proxy.setoutoput: ';

var _apimgmt = session.name('_apimgmt');
var dbglog = apim.console;
var verbose = apim.verbose;

var outputVariable = _apimgmt.getVar('proxy/save-response');
var analyticsData = session.name('_apimgmt').getVar('proxy/anadebug');
apim.readInput(readDataCallback);

function readDataCallback(error, data) {
    if (error) {
        // Do nothing
    } else {
        var headers = hm.current.get();
        storeResponseInContext(data, headers);
    }
}

function storeResponseInContext(responseData, headers) {
    var outputVariable = _apimgmt.getVar('proxy/save-response');
    var statusCode = session.name('_apimgmt').getVar('last-invoke-status-code');
    var reasonPhrase = session.name('_apimgmt').getVar('last-invoke-status-phrase');
    if (outputVariable !== undefined) {
        if (statusCode!==undefined) {
            apim.setvariable(outputVariable+'.status.code', statusCode);
            apim.setvariable(outputVariable+'.status.reason',reasonPhrase);
        }
        apim.setvariable(outputVariable+'.body', responseData);
        if (headers!==undefined) {
            apim.setvariable(outputVariable+'.headers', headers);
        }
        if (verbose) {
            dbglog.debug(logPrefix+"writing responseData to variable [" + outputVariable + "]");
        }
    }
    
    var response = {};
    response.statusCode = statusCode;
    var analyticsOther = {};

    if (analyticsData !== undefined) {
        if (String(statusCode).indexOf('20') == 0) {
            analyticsOther.result = 'OK';
        } else {
            analyticsOther.result = 'Error';
        }

        analyticsData = apim.addAnalyticsOtherToData(analyticsData, analyticsOther);
        analyticsData = apim.addAnalyticsOutputToData(analyticsData, apim.generateOutputDataForAnalytics(responseData, headers, headers['Content-Type'], response, true), outputVariable);
        apim.writeAnalyticsDebug(analyticsData);
    }
}

