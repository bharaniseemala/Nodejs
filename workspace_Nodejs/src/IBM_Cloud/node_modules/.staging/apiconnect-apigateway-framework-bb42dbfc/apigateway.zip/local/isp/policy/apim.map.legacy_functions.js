//***************************************************** {COPYRIGHT-TOP} ***
//* Licensed Materials - Property of IBM
//* 5725-L30, 5725-Z22, 5725-Z63, 5725-U33
//*
//* (C) Copyright IBM Corporation 2016, 2017
//*
//* US Government Users Restricted Rights - Use, duplication, or
//* disclosure restricted by GSA ADP Schedule Contract with IBM Corp.
//********************************************************** {COPYRIGHT-END}**

"use strict";

var util = require('util');
var transform = require('transform');

var lib = {};

if (!util.safeTypeOf)  {
  util.safeTypeOf = function(v) {
    return Object.prototype.toString.call(v).slice(8, -1).toLowerCase();
  };
}

var flatten1level = function(value) {
  if (!isArray(value)) return [value];
  return [].concat.apply([], value);
}


var isString = function(v) {
  return util.safeTypeOf(v) == 'string';
};

var isNumber = function(v) {
  return util.safeTypeOf(v) == 'number';
};

var isBoolean = function(v) {
  return util.safeTypeOf(v) == 'boolean'
};

var isDate = function(v) {
  return util.safeTypeOf(v) == 'date';
}

var isObject = function(v) {
  return util.safeTypeOf(v) == 'object';
}

var isArray = function(v) {
  return util.safeTypeOf(v) == 'array';
};


var toString = function(v) {
  if (v === null || v == undefined) return v;
  if (isBoolean(v) && v) return "true";
  if (isBoolean(v) && !v) return "false";
  if (isString(v)) return v;
  if (isArray(v) && v.length > 0) return toString(v[0]);
  if (isObject(v) && Object.keys(v).length > 0) return toString(v[Object.keys(v)[0]]);
  if (v && v.toString) return v.toString();

  return "";
};
Object.defineProperty(lib, 'toString', {value: toString });

var toArray = lib.toArray = function(v) {
  if (isArray(v)) return v;
  return [v];
};

var toNumber = lib.toNumber = function(v) {
  if (v == null || v == undefined) return v;

  if (isNumber(v)) return v;
  if (isString(v))  return parseFloat(v, 10);
  if (isArray(v) || isObject(v)) return toNumber(toString(v));
  if (isBoolean(v) && v) return 1;
  if (isBoolean(v) && !v) return 0;

  return NaN;
};

var toInteger = lib.toInteger = function(v) {
  return Math.floor(toNumber(v));
}

var toBoolean = lib.toBoolean = function(v) {
  if (isBoolean(v)) return v;
  if (isNumber(v)) return !(v === +0 || v == -0 || isNaN(v));
  if (isArray(v)) return v.length > 0;
  if (isObject(v)) return Object.keys(v).length > 0;
  if (isString(v)) return v.length > 0;

  return !!v;
};

var toObject = lib.toObject = function(v) {
  if (isObject(v)) return v;
  return {value: v};
};

lib.concat = function(values, delim, prefix, suffix) {
  values = values || [];
  values = toArray(values);

  delim = toString(delim) || '';
  prefix = toString(prefix);
  suffix = toString(suffix);

  var result = values.join(delim);

  if (prefix) result = prefix + result;
  if (suffix) result = result + suffix;

  return result;
};

lib.uppercase = function(value) {
  if (value === null || value === undefined) return value;
  value = value || ''
  value = toString(value);

  return value.toUpperCase();
};

lib.lowercase = function(value) {
  if (value === null || value === undefined) return value;
  value = value || '';
  value = toString(value);

  return value.toLowerCase();
};

lib.length = function(value) {
  if (value === null || value === undefined) return value;
  value = value || '';
  value = toString(value);

  return value.length;
};

lib.replace = function(value, oldString, newString) {
  if (value === null || value === undefined ||
      oldString === null || oldString === undefined ||
      newString === null || newString === undefined) return value;
  value = value || '';
  value = toString(value);

  var regEx = new RegExp(oldString,'g');

  return value.replace(regEx, newString);
};

var startsWith = lib.startsWith = function(value, startingString) {
  if (value === null || value === undefined) return false;
  value = value || '';
  value = toString(value);

  return value.indexOf(startingString) == 0;
};


var substring = lib.substring = function(value, startingIndex, length) {
  if (value === null || value === undefined) return value;
  if (isNaN(startingIndex) || !isFinite(startingIndex) || (typeof length !== 'undefined' && isNaN(length))) return "";

  value = toString(value);

  // if length is infinite we need to adjust
  if (!isFinite(length)) {
    length = value.length;

    if (startingIndex < 0) startingIndex = 1;
  }

  var start = Math.round(startingIndex) - 1;
  var end = Math.round(length);

  var substr = '';

  var counter = 1;
  while(counter++ <= end) {
    var c = value.charAt(start++);
    if (!c)continue;
    substr += c;
  }

  return substr;
};

lib.abs = lib.absolute = function(value) {
  if (value === null || value === undefined) return value;
  value = toNumber(value);
  return Math.abs(value);
};

lib.sum = function(value1, value2, value3, etc) {
  var values = Array.prototype.slice.call(arguments);
  var sum = 0;
  for (var i = 0; i < values.length; i++) {
    if (values[i] !== null && values[i] !== undefined) {
      var flattened = flatten1level(values[i]);
      for (var j = 0; j < flattened.length; j++) {
        sum += toNumber(flattened[j]);
      }
    }
  }

  return sum;
};

lib.count = function(value1, value2, value3, etc) {
  var values = Array.prototype.slice.call(arguments);
  var count = 0;
  for (var i = 0; i < values.length; i++) {
    var flattened = flatten1level(values[i]);
    for (var j = 0; j < flattened.length; j++) {
      count++;
    }
  }

  return count;
};


lib.mean = lib.avg = function(value1, value2, value3, etc) {
  var count = lib.count.apply(lib, arguments);
  var sum = lib.sum.apply(lib, arguments);
  return sum / count;
};

lib.trim = function(value) {
  if (value === null || value === undefined) return value;
  value = toString(value);

  return value.replace(/\s+/g, ' ').trim();
}

lib.boolean = function(value) {
  if (value === null || value === undefined) return false;
  value = lib.trim(lib.lowercase(value));

  return value == "true" || value == "1";
}

lib.not = function(value) {
  return !lib.boolean(value);
}

lib.ceil = lib.ceiling = function(value) {
  if (value === null || value === undefined) return value;
  return Math.ceil(toNumber(value));
};


lib.floor = function(value) {
  if (value === null || value === undefined) return value;
  return Math.floor(toNumber(value));
};

lib.div = lib.divide = function(value1, value2) {
  if ((value1 === undefined || value1 === null) &&
      (value2 === undefined || value2 === null)) return undefined;

  return toNumber(value1) / toNumber(value2);
}

lib.formatNumber = function(value, format) {
  if (value === null || value === undefined) return value;
  value = toNumber(value);
  format = toString(format);

  //FIXME: Needs implementation


  return value;
};

lib.max = lib.maximum = function(value1, value2, value3, etc) {
  var values = Array.prototype.slice.call(arguments);
  var max = Number.NEGATIVE_INFINITY;
  for (var i = 0; i < values.length; i++) {
    var flattened = flatten1level(values[i]);
    for (var j = 0; j < flattened.length; j++) {
      max = Math.max(toNumber(flattened[j]), max);
    }
  }

  return max;
};

lib.min = lib.minimum = function(value1, value2, value3, etc) {
  var values = Array.prototype.slice.call(arguments);
  var min = Number.POSITIVE_INFINITY;
  for (var i = 0; i < values.length; i++) {
    var flattened = flatten1level(values[i]);
    for (var j = 0; j < flattened.length; j++) {
      min = Math.min(toNumber(flattened[j]), min);
    }
  }

  return min;
};

lib.mod = lib.modulo = function(value1, value2) {
  return toNumber(value1) % toNumber(value2);
};


lib.multiply = lib.times = function(value1, value2) {
  if ((value1 === undefined || value1 === null) &&
      (value2 === undefined || value2 === null)) return undefined;

  if (value1 === undefined || value1 === null) return 0;
  if (value2 === undefined || value2 === null) return 0;
  return toNumber(value1) * toNumber(value2);
};


lib.subtract = lib.minus = function(value1, value2) {
  if ((value1 === undefined || value1 === null) &&
      (value2 === undefined || value2 === null)) return undefined;

  if (value1 === undefined || value1 === null) value1 = 0;
  if (value2 === undefined || value2 === null) value2 = 0;
  return toNumber(value1) - toNumber(value2);
};

lib.add = lib.plus = function(value1, value2) {
  if ((value1 === undefined || value1 === null) &&
      (value2 === undefined || value2 === null)) return undefined;

  if (value1 === undefined || value1 === null) value1 = 0;
  if (value2 === undefined || value2 === null) value2 = 0;
  return toNumber(value1) + toNumber(value2);
}

lib.number = toNumber;

lib.string = toString;

lib.round = function(value) {
  return Math.round(toNumber(value));
}

lib.dateTimeParse = function(value, pattern) {
  if (value === null || value === undefined ||
      pattern === null || pattern === undefined) return value;

  value = toString(value);

  var apos = '\'';
  pattern = lib.replace(pattern, apos, '');

  var pieces = pattern.split('');

  var contents = orderingOfDateAndTime(pieces);
  var expression = generateExpression(pieces);

  var regex = new RegExp(expression.join(''), 'g');
  var matches = regex.exec(value);

  if (!matches) return null;

  matches.shift();

  var dateTimeMap = {};
  for (var i = 0; i < matches.length; i++ ) {
    var key = contents[i];
    var value = matches[i];

    dateTimeMap[key] = value;
  }

  // format date
  var year = getYear(dateTimeMap);
  var month = getMonth(dateTimeMap);
  var day = getDay(dateTimeMap);

  var xdate = year + '-' + month + '-' + day;

  var hour = getHour(dateTimeMap);
  var min = getMinute(dateTimeMap);
  var seconds = getSeconds(dateTimeMap);
  var timeZone = getTimeZone(dateTimeMap);
  var milliseconds = getMilliSeconds(dateTimeMap);

  var xtime = formatTime(hour, min, seconds, milliseconds);
  var dateTime = xdate + 'T' + xtime + timeZone;

  var finalForm = new Date(dateTime).toISOString();
  finalForm = finalForm.replace('Z', '+00:00');
  finalForm = finalForm.replace('.000', '');
  return finalForm;
};

var getYear = function(dateTimeMap) {
  var defaultYear = '1970';

  if (!dateTimeMap || !dateTimeMap['year'] ) return defaultYear;

  if (dateTimeMap['year'].length === 2) return '20' + dateTimeMap['year'];

  return dateTimeMap['year'];
};

var getMonth = function(dateTimeMap) {
  var defaultMonth = '01';

  if (!dateTimeMap) return defaultMonth;

  if (!isNaN(parseInt)) return dateTimeMap['month'];

  // month is probably a string
  var name = dateTimeMap['month'];

  if (getMonthNumberFromFullName(name)) return getMonthNumberFromFullName(name);

  if (getMonthNumberFromAbbreviatedName(name)) return getMonthNumberFromAbbreviatedName(name);

  return defaultMonth;
};

var getDay = function(dateTimeMap) {
  var defaultDay = '01';

  if (!dateTimeMap || !dateTimeMap['day-in-month']) return defaultDay;

  return dateTimeMap['day-in-month'];
};

var getAmPmMarker = function(dateTimeMap) {
  if (!dateTimeMap || ! dateTimeMap['am-pm-marker']) return;

  return dateTimeMap['am-pm-marker'];
};

var getHour = function(dateTimeMap) {
  var defaultHour = '00';

  if (!dateTimeMap) return defaultHour;

  var hour = getTimeIn24HrFormat(dateTimeMap);

  if (hour) return formatHour(hour);

  return defaultHour;
}

var getTimeIn24HrFormat = function(dateTimeMap) {
  if (!dateTimeMap) return;

  // check if hour is already in 24hrs
  if (dateTimeMap['hour-in-day-0-23']) return
  dateTimeMap['hour-in-day-0-23'];

  if (!dateTimeMap['hour-in-am-pm']) return;

  // else process
  var amOrPm = getAmPmMarker(dateTimeMap);
  var hour = parseInt(dateTimeMap['hour-in-am-pm']);

  if (amOrPm !== 'pm') return hour;

  hour =+ 12;

  if (hour == 24) return '00';

  return hour;
};

var formatHour = function(hour) {
  if (!hour || isNaN(parseInt(hour))) return '00';

  if (parseInt(hour) < 10) {
    return '0' + hour.toString();
  }

  return hour;
};

var getMinute = function(dateTimeMap) {
  var defaultMinute = '00';

  if (!dateTimeMap || !dateTimeMap['minute']) return defaultMinute;

  return dateTimeMap['minute'];
};

var getSeconds = function (dateTimeMap) {
  var defaultSeconds = '00';

  if (!dateTimeMap || !dateTimeMap['second']) return defaultSeconds;

  return dateTimeMap['second'];
}

var getMilliSeconds = function (dateTimeMap) {
  if (!dateTimeMap || !dateTimeMap['millisecond']) return;

  return dateTimeMap['millisecond'];
}

var getTimeZone = function(dateTimeMap) {
  var defaultTimeZone = '+00:00';

  if (!dateTimeMap || !dateTimeMap['timezone']) return defaultTimeZone;

  // TODO: timezone
  var timezone = dateTimeMap['timezone'];

  if (timezone.length === 6 && substring(timezone, 4, 3) === ':') return timezone;
  if (timezone.length === 5) return substring(timezone, 1, 3) + ':' + substring(timezone, 3,5);
  if (timezone.length === 3) return timezone += ':00';

  return defaultTimeZone;
}

var formatTime = function(h, m, s, ms) {
  var t = '';

  if (h) t += h;
  if (m) t += ':' + m;
  if (s) t += ':' + s;
  if (ms) t += '.' + ms;

  return t;
};

var getMonthNumberFromFullName = function(name) {
  if (!name) return;

  name = name.toLowerCase();

  var monthMap = {
    january: '01',
    february: '02',
    march: '03',
    april: '04',
    may: '05',
    june: '06',
    july: '07',
    august: '08',
    september: '09',
    october: '10',
    november: '11',
    december: '12'
  }

  if (!monthMap[name]) return;

  return monthMap[name];
};

var getMonthNumberFromAbbreviatedName = function(name) {
  if (!name) return;

  name = name.toLowerCase();

  var monthMap = {
    jan: '01',
    feb: '02',
    mar: '03',
    apr: '04',
    may: '05',
    jun: '06',
    jul: '07',
    aug: '08',
    sep: '09',
    oct: '10',
    nov: '11',
    dec: '12'
  }

  if (!monthMap[name]) return;

  return monthMap[name];
};

var orderingOfDateAndTime = function(pieces) {
  if (!pieces) return [];

  var order = [];
  var letter = '';

  // get the ordering
  for (var i = 0, max = pieces.length; i < max; i++) {
    var previousLetter = letter;
    var currentLetter = pieces[i];

    if (currentLetter === previousLetter) break;

    // time
    switch (currentLetter) {
      case 'M': order.push('month');
        break;
      case 'd': order.push('day-in-month');
        break;
      case 'y': order.push('year');
        break;
      case 'Y': order.push('year');
        break;
      case 'H': order.push('hour-in-day-0-23');
        break;
      case 'm': order.push('minute');
        break;
      case 's': order.push('second');
        break;
      case 'S': order.push('millisecond');
        break;
      case 'X': order.push('timezone');
        break;
      case 'Z': order.push('timezone');
        break;
      case 'a': order.push('am-pm-marker');
        break;
      case 'h': order.push('hour-in-am-pm');
        break;
    }

    letter = currentLetter;
  }

  return order;
};

var generateExpression = function(pieces) {
  if (!pieces) return [];

  var expression = [];
  var letter = '';

  expression.push('^');

  // get the ordering
  for (var i = 0, max = pieces.length; i < max; i++) {
    var previousLetter = letter;
    var currentLetter = pieces[i];

    if (currentLetter === previousLetter) break;

    // time
    switch (currentLetter) {
      case 'M': expression.push('(.+)');
        break;
      case 'd': expression.push('([12][0-9]|3[01]|[1-9]|0[1-9])');
        break;
      case 'y': expression.push('([0-9][0-9][0-9][0-9]|[0-9][0-9])');
        break;
      case 'Y': expression.push('([0-9][0-9][0-9][0-9]|[0-9][0-9])');
        break;
      case 'H': expression.push('([1-9]|0[0-9]|[1][0-9]|2[0-3])');
        break;
      case 'm': expression.push('([0-9]|[0-5][0-9])');
        break;
      case 's': expression.push('([0-9]|[0-5][0-9])');
        break;
      case 'S': expression.push('([0-9]|[0-9][0-9]|[0-9][0-9][0-9])');
        break;
      case '/': expression.push('\/');
        break;
      case '.': expression.push('\.');
        break;
      case '-': expression.push('\-');
        break;
      case 'X': expression.push('([\+|\-][0-9]{2}(?:[\:]?[0-9]{2})?)');
        break;
      case 'Z': expression.push('([\+|\-][0-9]{2}(?:[\:]?[0-9]{2})?)');
        break;
      case 'a': expression.push('([a|A][m|M]|[p|P][m|M])');
        break;
      case 'h': expression.push('(1[0-2]|0[1-9]|[1-9])');
        break;
      default: expression.push(currentLetter);
        break;
    }

    letter = currentLetter;
  }

  expression.push('$');

  return expression;
};

lib.dateToString = function(dateTime, pattern) {
  if (dateTime === null || dateTime === undefined ||
      pattern === null || pattern === undefined) return dateTime;

  dateTime = toString(dateTime);

  var dateFormat = getDateFormat(dateTime);
  var date = {
    year: '1970',
    month: '01',
    day: '01',
    hour: '00',
    minute: '00',
    second: '00',
    timezone: ''
  };

  switch (dateFormat) {
    case 'gDay':
      return process(dateTime, ['day'], '---([12][0-9]|3[01]|[1-9]|0[1-9])', pattern, date);
    case 'gMonthDay':
      return process(dateTime, ['month', 'day'], '--(0[1-9]|1[0-2])-([12][0-9]|3[01]|[1-9]|0[1-9])', pattern, date);
    case 'gMonth':
      return process(dateTime, ['month'], '--(0[1-9]|1[0-2])--', pattern, date);
    case 'gYear':
      return process(dateTime, ['year'], '([0-9][0-9][0-9][0-9])', pattern, date);
    case 'gYearMonth':
      return process(dateTime, ['year', 'month'], '([0-9][0-9][0-9][0-9]|[0-9][0-9])-(0[1-9]|1[0-2])', pattern, date);
    case 'time':
      return process(dateTime, ['hour', 'minute', 'second'], '([1-9]|0[0-9]|[1][0-9]|2[0-3]):([0-9]|[0-5][0-9]):([0-9]|[0-5][0-9])', pattern, date);
    case 'date':
      return process(dateTime, ['year', 'month', 'day'], '([0-9][0-9][0-9][0-9]|[0-9][0-9])-(0[1-9]|1[0-2])-([12][0-9]|3[01]|[1-9]|0[1-9])', pattern, date);
    case 'dateTime':
      return process(dateTime, ['year', 'month', 'day', 'hour', 'minute', 'second'], '([0-9][0-9][0-9][0-9]|[0-9][0-9])-(0[1-9]|1[0-2])-([12][0-9]|3[01]|[1-9]|0[1-9])T([1-9]|0[0-9]|[1][0-9]|2[0-3]):([0-9]|[0-5][0-9]):([0-9]|[0-5][0-9])', pattern, date);

  }
};

var process = function (dateTime, keys, expression, pattern, date) {
  var matches = parse(dateTime, new RegExp('^' + expression + '$','g'));

  if (!matches || matches.length === 0) return '';

  addDateValues(matches, keys, date);
  var format = formatDateByPattern(date, pattern);
  //console.log('[debug] final format: ' + format);
  return format;
}

var addDateValues = function (matches, keys, date) {
  if (!matches || !keys) return date;

  matches.shift();

  for (var i = 0; i < keys.length; i++) {
    var key = keys[i];
    var value = matches[i];

    date[key] = value;
  }
}

var getDateFormat = function(dateTime){
  if (!dateTime) return;

  if (startsWith(dateTime, '---')) return 'gDay';
  if (startsWith(dateTime, '--')) {
    if (dateTime.length === 7) return 'gMonthDay';
    if (dateTime.length === 6) return 'gMonth'
    return;
  }

  // it's probably gYear, gYearMonth, date, time, or dateTime
  if (dateTime.length === 4) return 'gYear';
  if (dateTime.length === 7 && substring(dateTime, 5, 1) === '-') return 'gYearMonth';
  if (dateTime.length === 8 && substring(dateTime, 3, 1) === ':' && substring(dateTime, 6, 1) === ':') return 'time';
  if (dateTime.length === 10 && substring(dateTime, 5, 1) === '-' && substring(dateTime, 8, 1) === '-') return 'date'
  if (dateTime.length >= 19 && substring(dateTime, 5, 1) === '-' && substring(dateTime, 8, 1) === '-' && substring(dateTime, 11, 1) === 'T') return 'dateTime';
};

var parse = function(value, regExp) {
  if (!value || !regExp) return [];

  return regExp.exec(value);
}

var formatDateByPattern = function(date, pattern) {
  if (!date || typeof date === 'object' && Object.keys(date) === 0 || !pattern) return '';

  switch (pattern) {
    case 'yyyy': return date.year;
    case 'yyyy-MM': return date.year + '-' + date.month;
    case 'yyyy-MM-dd': return date.year + '-' + date.month + '-' + date.day;
    case 'yyyy-MM-dd\'T\'HH:mmZ': return date.year + '-' + date.month + '-' + date.day + 'T' + date.hour + ':' + date.minute + 'Z';
    case 'yyyy-MM-dd\'T\'HH:mm:ssZ': return date.year + '-' + date.month + '-' + date.day + 'T' + date.hour + ':' + date.minute + ':' + date.second + 'Z';
    default: return '';
  }

};

/*
 Possible dateTime Formats
 Year:
  YYYY (eg 1997)
 Year and month:
  YYYY-MM (eg 1997-07)
 Complete date:
  YYYY-MM-DD (eg 1997-07-16)
 Complete date plus hours and minutes:
  YYYY-MM-DDThh:mmTZD (eg 1997-07-16T19:20+01:00)
 Complete date plus hours, minutes and seconds:
  YYYY-MM-DDThh:mm:ssTZD (eg 1997-07-16T19:20:30+01:00)
 Complete date plus hours, minutes, seconds and a decimal fraction of a second
  YYYY-MM-DDThh:mm:ss.sTZD (eg 1997-07-16T19:20:30.45+01:00)
 */
lib.adjustDateTimeToTZ = function(dateTime, inputTimezone) {

  value = toString(dateTime);
  return value; //FIXME: This function is not fully implemented, so just pass through un-adjusted date

  var timezone = getTimezone(inputTimezone);
  console.log('[debug] timezone: ' + timezone);

  var match = parse(timezone, new RegExp(/^([\-\+])?PT([\d+]{1,2})H([\d+]{1,2})M$/g));
  if (!match) return '';
  /*
   match:
   [0]: -
   [1]: 10
   [2]: 32
   */
  match.shift();
  console.log('[debug] matches: ' + match);

  var sign = (match[0] > 0) ? match[0] : '+';
  console.log('[debug] sign: ' + sign);

  var hour = (match[1] === 1) ? '0' + match[1].toString() : match[1].toString();
  var minutes = (match[2] === 1) ? '0' + match[2].toString() : match[2].toString();

  var TZ = hour + ':' + minutes;
  console.log('[debug] TZ: ' + TZ);

  var dtMatch = parse(dateTime, new RegExp(/^([\d+]{4,4}-[\d+]{2,2}-[\d+]{2,2}T[\d+]{2,2}:[\d+]{2,2}:[\d+]{2,2})(\.(?=[\d]{1,})[\d]{1,})?([\-\+][\d+]{2,2}:[\d+]{2,2})?$/g));
  if (!dtMatch) return dateTime;
  /*
   dtMatch:
   [0]: 2013-12-12T22:20:00
   [1]: .333
   [2]: -01:00
   */
  dtMatch.shift();
  console.log('[debug] dateTime: ' + dtMatch);

  // TODO: implement dateAdd
  var tempAdjustedDateTime = lib.dateAdd(dtMatch[0] + dtMatch[2], 'PT00H00M');
  var adjustedDateTime = getAdjustedDateTime(tempAdjustedDateTime, dtMatch);

  return adjustedDateTime;
};

var getTimezone = function (inputTimezone) {
  if (!inputTimezone) return '';

  if (startsWith(inputTimezone, '+')) return 'PT' + substring(inputTimezone, 2);
  if (startsWith(inputTimezone, '-')) return '-PT' + substring(inputTimezone, 2);

  return 'PT' + inputTimezone;
};

var getAdjustedDateTime = function (tempAdjustedDateTime, dtMatch) {
  if (!dtMatch || !Array.isArray(dtMatch) || dtMatch.length === 0 || !tempAdjustedDateTime) return '';

  if ((substring(dateAdd(tempAdjustedDateTime, timezone), 'Z')).length == 0)
    return tempAdjustedDateTime + dtMatch[1] + sign + TZ;

  return substringBefore( dateAdd(tempAdjustedDateTime, timezone) + 'Z') + dtMatch[1] + sign + TZ;
};

/*
  Permitted format for dateTime
   - xs:dateTime (CCYY-MM-DDThh:mm:ss)
   - xs:date (CCYY-MM-DD)
   - xs:gYearMonth (CCYY-MM)
   - xs:gYear (CCYY)
 */
var dateAdd = lib.dateAdd = function(dateTime, duration) {
  // TODO: implement
};

var substringBefore = lib.substringBefore = function (s1, s2) {
  return s1.substr(0, s1.indexOf(s2));
};

var translate = lib.translate = function (s1, s2, s3) {
  if (s1 === null || s1 === undefined ||
      s2 === null || s2 === undefined ||
      s3 === null || s3 === undefined) return s1;

  var map = {};
  var arr = s1.split('');

  // create the lookup map for
  // translating characters
  for (var i = 0; i < s2.length; i++) {
    var c = s2.charAt(i);
    if (map[c]) continue;
    map[c] = s3.charAt(i);
  }

  // if s2 > s3 we have to remove
  // characters from s2 not found in s3
  var keys = Object.keys(map);
  for (var i = 0; i < keys.length; i++ ) {
    var key = keys[i];
    if (map[key]) continue;
    map[key] = 'remove';
  }

  // replace all characters from s1
  var newArr = [];
  for (var i = 0; i < arr.length; i++)   {
    var c = arr[i];

    if (map[c]) {
       arr[i] = map[c];
    }
  }

  // for any characters flagged
  // remove it!
  var finalForm = [];
  for (var i = 0; i < arr.length; i++) {
    if (arr[i] === 'remove') continue;
    finalForm.push(arr[i]);
  }

  return finalForm.join('');
};

module.exports = lib;
