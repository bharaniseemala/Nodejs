// ***************************************************** {COPYRIGHT-TOP} ***
// Licensed Materials - Property of IBM
// 5725-L30, 5725-Z22, 5725-Z63, 5725-U33
//
// (C) Copyright IBM Corporation 2016, 2017
//
// US Government Users Restricted Rights - Use, duplication, or
// disclosure restricted by GSA ADP Schedule Contract with IBM Corp.
// ********************************************************** {COPYRIGHT-END}**
var urlopen = require('urlopen');
var verbose = false; 
if (session.name('_apimgmt') !== undefined)
{
  var verbose_level = session.name('_apimgmt').getVar('policy/verbose_level');
  if (verbose_level !== undefined)
  {
    if (verbose_level > 0)
    {
      verbose = true;
    }
  }
}

// instead of importing apim.custom.js, lets set up our own logging.
// and avoid the circular include
var dbglog = console.options({'category':'apiconnect'});

// "Constants"
var useCircuitBreaker = session.name('_apimgmt').getVar('policy/use-circuit-breaker') === '1';
dbglog.debug("apim-util.js useCircuitBreaker ["+useCircuitBreaker+"]");
var REVAL_CATALOG_MAXAGE =  useCircuitBreaker ? -1 : 899;    // Max-Age for proactive revalidation requests (20secs)
dbglog.debug("apim-util.js REVAL_CATALOG_MAXAGE ["+REVAL_CATALOG_MAXAGE+"]");
var REVAL_ODCINFO_MAXAGE = 59;     // Max-Age for LoadBalancerGroup members revalidation
var TESTING = false;               // Set to true if you want shorter times for testing

if (TESTING) {
  REVAL_CATALOG_MAXAGE = 89;      // Testing only, 90 seconds
}

//@@ =========================================================
//@@ Fetch a document using urlopen
//@@ Invokes callback(error,buffer) when JS object is ready.
exports.getDocumentAsBuffer = function(url, headers, callback) {
  fetchDocument(url,headers,function(error,response) {
    if (!error) {
      response.readAsBuffer(function (error, buffer) {
        callback(error, buffer);
      });
    }
    else {
      callback(error);
    }
  });
}

//@@ Fetch a JSON document using urlopen
//@@ Invokes callback(error,json) when JS object is ready.
exports.getDocument = function(url, headers, callback) {
  fetchDocument(url,headers,function(error,response) {
    if (!error) {
      response.readAsJSON(function (error, json) {
        callback(error, json);
      });
    }
    else {
      callback(error);
    }
  });
}

//@@ =========================================================
//@@ Helper function for fetching a document from management server
//@@
function fetchDocument(url, headers, callback) {
  var start = Date.now();
  if (!url) {
    callback({'error':'getDocument url undefined'});
    return;
  }
  var direction = require('header-metadata').current.get('X-Rule-Direction');
  var logprefix = 'apim.util: getDocument[' + direction + '] ';

  //@@ Requests to fetch information from Management Server require proper
  //@@ Identification of the caller via X-IBM-Client-ID header
  if (url.indexOf('type=edge-gateway') > -1) {
    try {
      var deployInfo = exports.loadDeployInfo();
      if (deployInfo) {
        headers['X-IBM-Client-ID'] = deployInfo.gateway['cluster-id'];
      }
      else {
        dbglog.error(logprefix + 'cannot get cluster id');
      }
      //@@ use the Cache-Control settings, as such:
      //@@ - for requests made via the scheduled task, set max-stale to 20 seconds
      //@@ - for requests to revalidate loadbalancer group members, set max-age to 1 minute
      //@@ - for requests not made via schedule task, i.e. API requests made by appliances,
      //@@   instruct DP document cache to provide a stale copy always, allowing DP to continue
      //@@   to operate on API requests when the Management Servers are down.
      if (direction && direction === 'scheduled') {
        if (useCircuitBreaker){
          headers['Cache-Control'] = 'max-stale=' + REVAL_CATALOG_MAXAGE + ', x-dp-ignore-resp-error';
        } else {
          headers['Cache-Control'] = 'max-age=' + REVAL_CATALOG_MAXAGE + ', x-dp-ignore-resp-error';
        }
      }
      else if (direction && direction == 'odcinfo') {
        headers['Cache-Control'] = 'max-age=' + REVAL_ODCINFO_MAXAGE;
      }
      else {
        headers['Cache-Control'] = 'max-stale, x-dp-no-stale-refresh';
      }
    }
    catch (error) {
      dbglog.error(logprefix + 'unexpected error: ' + url);
      dbglog.error(error.stack);
    }
  }
  var options = { method: 'get', headers: headers, target: url, sslClientProfile: 'webapi-sslcli-mgmt', timeout: 120 };
  urlopen.open(options, function (error, response) {
    if (response && response.statusCode === 200) {
      if (verbose) {
        var message = 'done    ';
        message += url.split('?')[0] + ' ';
        message += Date.now() - start + 'ms.';
        message += ' Age: ' + (response.headers['Age'] ? response.headers['Age'] : 'fresh');
        dbglog.debug(logprefix + message);
      }
      if (response.headers['Age'] === undefined) {  // We got a fresh piece of metadata, so log info about it
        var message = 'new mgmt-lb response for ';
        message += url.split('?')[0] + ' ';
        message += Date.now() - start + 'ms.';
        message += ' ETag: ' + (response.headers['ETag'] ? response.headers['ETag'] : 'no ETag provided');
        if (response.headers['X-APIM'] !== undefined) {
          message += ' X-APIM: ' + response.headers['X-APIM'];
        }
        dbglog.info(logprefix + message);
      }
      callback(error, response);
    }
    else if (response) {
      dbglog.error(logprefix + 'failed ' + url + ': ' + response.statusCode);
      response.disconnect();
      callback(response.statusCode);
    }
    else {
      dbglog.error(logprefix + 'failed ' + url + ': ' + JSON.stringify(error));
      callback(error);
    }
  }); // end of urlopen.open()
}

//@@ =========================================================
//@@ POST an the request to url using urlopen
//@@
//@@ WARNING!!!!! This was added under issue 1594, but was found
//@@ to exhibit problems under DP firmware version 7.5.1.1, but
//@@ version 7.5.1.4 worked, which implies that any firmware
//@@ version prior to 7.5.1.1 (and the other coinciding firmware
//@@ levels) will exhibit the same problem. Versions that concide
//@@ with 7.5.1.2 or 7.5.1.3 MAY ALSO exhibit the problem (this
//@@ code was not tested on that level) - Be sure you are clear
//@@ of these levels before using this code
//@@
function postDocument(url, request) {
  var start = Date.now();
  var logprefix = 'apim.util: postDocument ';
  //dbglog.error(logprefix + 'posting to ' + url);

  var options = { data: request, method: 'post', target: url, sslClientProfile: 'webapi-sslcli-mgmt', timeout: 60 };
  urlopen.open(options, function (error, response) {
    if (response && response.statusCode === 200) {
      if (verbose) {
        var message = 'done    ';
        message += url.split('?')[0] + ' ';
        message += Date.now() - start + 'ms.';
        message += ' Age: ' + (response.headers['Age'] ? response.headers['Age'] : 'fresh');
        dbglog.debug(logprefix + message);
      }
      response.discard(function(error) { });
    }
    else if (response) {
      dbglog.error(logprefix + 'failed ' + url + ': ' + response.statusCode);
      response.disconnect();
    }
    else {
      dbglog.error(logprefix + 'failed ' + url + ': ' + JSON.stringify(error));
    }
  }); // end of urlopen.open()
}

//@@ =========================================================
//@@ POST an internal document using urlopen
//@@
//@@ WARNING!!!!! This was added under issue 1594, but was found
//@@ to exhibit problems under DP firmware version 7.5.1.1, but
//@@ version 7.5.1.4 worked, which implies that any firmware
//@@ version prior to 7.5.1.1 (and the other coinciding firmware
//@@ levels) will exhibit the same problem. Versions that concide
//@@ with 7.5.1.2 or 7.5.1.3 MAY ALSO exhibit the problem (this
//@@ code was not tested on that level) - Be sure you are clear
//@@ of these levels before using this code
//@@
exports.postInternalDocument = function(uri, request) {
  var deployInfo = exports.loadDeployInfo();
  var mpgw_ip = deployInfo.endpoints['loopback-ip'];
  var mpgw_port = parseInt(deployInfo.endpoints['base-port']) + 1;
  var mpgw_internal = "http://" + mpgw_ip + ":" + mpgw_port + "/";
  postDocument(mpgw_internal+uri+"?type=edge-gateway", request);
}

//@@ =========================================================
//@@ Reads 'var://context/_apimgmt/deploy-infoJSON', which must be set prior to using this function
//@@ Returns the contents of 'local://gwapi/deploy.xml'
exports.loadDeployInfo = function() {
  var _apimgmt = session.name('_apimgmt');
  var json = _apimgmt.getVar('deploy-infoJSON');
  return JSON.parse(json);
}

//@@ =========================================================
//@@ JS to XML
//@@ Writes a JS object in XML, using the following rules:
//@@
//@@ 1. Primitives and Strings properties become a single XML element
//@@    <prefix type="string" name="foo">bar</prefix>
//@@ 2. Objects (and Array) properties are added recursively.
//@@
function js2xml(indent,prefix,name,value) {
  var xml = '';
  if (value && typeof value === 'object') {
    // arrays and objects
    var type = value.constructor === Array ? 'array' : 'object';
    // start element
    xml += indent + '<' + prefix + 'type="' + type + '" name="' + escapeXML(name) + '">\n';

    for (var childName in value)
    {
      if (value.hasOwnProperty(childName)) {
        xml+= js2xml(indent + ' ',prefix, childName, value[childName]);
      }
    }
    // end element
    xml += indent + '</' + prefix + '>\n';


  }
  else {
    // primitive types, null, string, boolean, number
    xml = indent + '<' + prefix + '  type="' + typeof value +
           '" name="' + escapeXML(name) + '>' + escapeXML(value) + '</' + prefix + '>\n';
  }
  return xml;
}

//TODO: Check upstream to ensure apiProps are always passed as objects
function swaggerApiProperties2xmlApiProperties(indent,prefix,name,value) {
  var xml = '';
  if (value && typeof value === 'object') {
    // arrays and objects
    var type = value.constructor === Array ? 'array' : 'object';
    // start element
    xml += indent + '<' + prefix + ' type="' + type + '" name="' + escapeXML(name) + '" password="'+ value['encoded'] + '">';
    xml += escapeXML(value['value']);
    xml += '</' + prefix + '>\n';


  }
  else {
    // primitive types, null, string, boolean, number
    xml = indent + '<' + prefix + ' type="' + typeof value +
           '" name="' + escapeXML(name) + '">' + '<![CDATA[' + value +']]>'+ '</' + prefix + '>\n';
  }
  return xml;
}

function escapeXML( string ){

  var entityMap = {
    "\"":"&quot;",
    "\'":"&apos;",
    "<":"&lt;",
    ">":"&gt;",
    "&":"&amp;"
  };

  function mapper(match, offset, string){
    return entityMap[match];
  }

  if (string && typeof string === 'string') {
    string = string.replace(/\"|\'|<|>|&/g, mapper);
  }
  return string;
}

exports.swaggerApiProperties2xmlApiProperties = swaggerApiProperties2xmlApiProperties;
exports.js2xmlprop = js2xml;
exports.escapeXML = escapeXML;
