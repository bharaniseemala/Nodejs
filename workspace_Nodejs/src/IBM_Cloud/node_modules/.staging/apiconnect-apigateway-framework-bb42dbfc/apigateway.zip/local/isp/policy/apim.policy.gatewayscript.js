// * Licensed Materials - Property of IBM
// * 5725-L30, 5725-Z22, 5725-Z63, 5725-U33
// *
// * (C) Copyright IBM Corporation 2016, 2017
// *
// * US Government Users Restricted Rights - Use, duplication, or
// * disclosure restricted by GSA ADP Schedule Contract with IBM Corp.

var apim = require('local:///isp/policy/apim.custom.js'),
    policy = apim.getPolicyProperty();
var dbglog = apim.console;
var logPrefix = 'apim.policy.gatewayscript';

try {
  evalSafe(policy.source);
}
catch (exception) {
  apim.console.error('apim.gatewayscript: ' + exception);
  var errs = require('local:///isp/policy/apim.exception.js');
  apim.error(errs.Errors.JavaScriptError,'500','Internal Server Error',exception);
}

/*
 * Wrapper to eval(). This will disable sensitive modules before invoking the actual eval().
 * Note: This wrapper is duplicated in three files apim.policy.gatewayscript.js,
 * apim.conditional.js and apim.map.js as it not exportable.
 *
 * */

function evalSafe(expr)
{
    var _require = require;
    // If expr contains String "require('urlopen')", then deep clone 'urlopen' object
    if(expr.search(/require\(("|')+urlopen("|')+\)/g) >= 0){
      dbglog.debug(logPrefix + ' : require("urlopen") is found in gatewayscript');
      var urlopen_modified = Object.assign({}, require('urlopen'));
    }
    return (function(){
        var require = function(mod) {
            if (mod === 'mgmt')
                throw new Error("Error: Cannot find module 'mgmt'");
            if (mod === 'multistep')
                throw new Error("Error: Cannod find module 'multistep'");
            if (mod === 'fs')
                throw new Error("Error: Cannot find module 'fs'");
            if (mod === 'service-metadata')
                throw new Error("Error: Cannot find module 'service-metadata'");
            return _require(mod);
        };
        // Overriding urlopen.open
        if(urlopen_modified !== undefined){
          dbglog.debug(logPrefix + ' : Overriding urlopen.open');
          urlopen_modified.open = function(options, callback){
            var sslClientProfile = options['sslClientProfile'];
            var tlsProfileObjName = '';

            // if sslClientProfile is defined, then resolve APIM sslClientProfile to DP sslClientProfile name
            if(options && sslClientProfile && sslClientProfile.length > 0){
              tlsProfileObjName = apim.getTLSProfileObjName(sslClientProfile);
            }

            // if tlsProfileObjName is defined, then take '<tls-profile-name>' from 'client:<tls-profile-name>'
            if(tlsProfileObjName && tlsProfileObjName.length > 0 && tlsProfileObjName.indexOf('client:') == 0){
              dbglog.debug(logPrefix + ' : options["sslClientProfile"] is resolved from ' +
                  String(options['sslClientProfile']) + " to " + tlsProfileObjName.substr(7));
              options['sslClientProfile'] = tlsProfileObjName.substr(7);
            }else{
              options['sslClientProfile'] = sslClientProfile;
            }

            dbglog.debug(logPrefix + ' : urlopen.open options are ' + JSON.stringify(options));
            return require('urlopen').open(options, callback);
          };
          // Replace any variants of "require('urlopen')" with "urlopen"
          expr = expr.replace(/require\(("|')+urlopen("|')+\)/g, 'urlopen_modified');
        }

        return eval(expr);
    })();
}
