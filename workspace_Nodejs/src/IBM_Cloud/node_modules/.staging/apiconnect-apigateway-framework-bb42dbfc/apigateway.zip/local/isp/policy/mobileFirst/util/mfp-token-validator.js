// ***************************************************** {COPYRIGHT-TOP} ***
//* Licensed Materials - Property of IBM
//* 5725-L30
//*
//* (C) Copyright IBM Corporation 2016
//*
//* US Government Users Restricted Rights - Use, duplication, or
//* disclosure restricted by GSA ADP Schedule Contract with IBM Corp.
// ********************************************************** {COPYRIGHT-END}**



var util = require('util'),
RejectionMessage = require('local:///isp/policy/mobileFirst/util/responses'),
SecurityLogger = require('local:///isp/policy/mobileFirst/util/security-logger'),
Constant = require("local:///isp/policy/mobileFirst/util/constant"),
apicUtils = require('local:///isp/policy/mobileFirst/util/mfp-apic-utils'),
urlopen = require('urlopen');

var crypto = require('crypto');

var internalWebApiIp = apicUtils.getInternalWebApiIp();
var internalWebApiPort = apicUtils.getInternalWebApiPort();
var mfpCacheUrl = 'http://' + internalWebApiIp + ':'+ internalWebApiPort  + '/mfpCache'; 

var tokenValidator = {}; 

tokenValidator.validate = function(options,done) {
    var strategy = this;
    var validator = new ValidatorExecuter(strategy,options,done);
    
    if ( (options.authorization !== undefined) && (options.authorization.startsWith(Constant.AUTHORIZATION_BEARER)) ) {
        
        // The Authorization's value is:"Bearer" 1*SP b64token
        options.token = options.authorization.substr(Constant.AUTHORIZATION_BEARER.length).trim();
        validateToken();
    } else {
        var validationCode;
        if (options.authorization === undefined) {
            SecurityLogger.debug('The client sent a request without an Authorization header.');
            validationCode = 'AUTHORIZATION_FAILED_MISSING_AUTH_HEADER';
        } else {
            SecurityLogger.debug('The token does not start with Bearer');
            validationCode = 'AUTHORIZATION_FAILED_MISSING_TOKEN';
        }
        done(null,null,{code:Constant.AUTHORIZATION_FAILED_MISSING_AUTHORIZATION, status:401, validationCode:validationCode});
    }
    
    function validateToken() {
        return validator.obtainConfClientToken().then(function(confClientToken) {
            return validator.introspect(confClientToken, options.token).then(function(body) {  
                validator.validateIntrospectionData(body);
            }).catch(function(error) {
                if (error.reason == Constant.UNAUTHORIZED_TO_INTROSPECT) {
                    if (++validator.attempts < validator.maxAttemps) {
                        return validateToken();
                    } else {
                        done(null, null, error);
                    }
                } else {
                    done(null, null, error);
                }
            });
        }).catch(function(error) {
            done(null, null, error);
        });
    }
}

function ValidatorExecuter(strategy,options,done) {
    this.authServerUrl;
    this.userid;
    this.pass;
    this.maxAttemps = 4;
    this.attempts = 0;
        
    if (apicUtils.isObject(options)) {
        if (apicUtils.isString(options.authServerUrl)) 
            this.authServerUrl = options.authServerUrl;
        if (apicUtils.isString(options.confClientID)) 
            this.userid = options.confClientID;
        if (apicUtils.isString(options.confClientPass)) 
            this.pass = options.confClientPass;
    }
    if (!this.authServerUrl.endsWith('/')) {
        // Support both cases for the user's insertion. For example:
        // http://localhost:9080/mfp/api  or  http://localhost:9080/mfp/api/
        this.authServerUrl = this.authServerUrl + '/';
    }
    
    this.scope = options.scope;
    this.mfpProviderName = options.mfpProviderName;
        
    function createOptionsForUrlOpen(cacheType, cacheKey, url, form, authHeader, certificate) {      
        /// MobileFirst cache uses webapi MPG cahce policy of http://**  'protocol-based'
        let options = {
            target: mfpCacheUrl,
            method: 'get',
            headers: {
            "x-Authorization": authHeader,
            "x-dp-cache-key" : cacheKey,
            "x-mfp-url" : url,
            "x-mfp-cache-type": cacheType,
            "x-mfp-tls-profile": certificate,
            "x-mfp-data": form
            },
            contentType: 'application/x-www-form-urlencoded',
            data: form,
        };
        
        return options;
    }
    
    function sendRequest(requestData, callbackFunc){
      urlopen.open(requestData, function (error, response) {
          if (error) {
              error.mfpFlow = "MfpCacheServcieConnectionError"; //TODO check if can differeniate from SSL error ?
              callbackFunc(error, response, null);
          } else {
              var mfpStatusCode = response.statusCode;
              if(mfpStatusCode !== 500){
                response.readAsJSON(function (error, jsonResponse) {
                    if (error) {
                        error.mfpFlow = "ParseJsonResponseError";
                        callbackFunc(error, response, undefined);
                    } else{
                        callbackFunc(error, response, jsonResponse);
                    } 
                });
              }
              else{ // MFP Cache service has fatal error or MFP server has fatal internal error
                    var mfpCacheServiceError = response.headers['MFP-Cache-Service-Error'];
                    if(!mfpCacheServiceError){
                        mfpCacheServiceError = "Unknown Reason";
                    }
                    error = {};
                    error.mfpFlow = mfpCacheServiceError;
                    callbackFunc(error, response, undefined);
              }
              
          }
      });
    }

    function doError(reject, error, url, validationCode) {
        var errorReason = getErrorReason(error);
        reject(new RejectionMessage(errorReason + url, error, Constant.AUTHORIZATION_FAILED_INTERNAL_SERVER_ERROR, 500, validationCode));
    }

    function getErrorReason(error){
        // Node filter error mapping (find match to DataPower)
        // error.code == 'ECONNREFUSED' > Constant.CONNECTION_REFUSED
        // error.code == 'ETIMEDOUT'    > Constant.CONNECTION_TIMED_OUT
        // error.code == 'DEPTH_ZERO_SELF_SIGNED_CERT' > Constant.CONNECTION_CERT
        // default > Constant.CONNECTION_ERROR
        var reason = "default reason TOOD";
        if (error.mfpFlow == 'MfpCacheServcieConnectionError'){
            reason = "MfpCacheServcieConnectionError" ;
        } 
        else if (error.mfpFlow == 'ParseJsonResponseError'){
            reason = "ParseJsonResponseError" ;
        }
        else if (error.mfpFlow == 'ConnectionError'){
            reason = "ConnectionError" ;
        }
        else if (error.mfpFlow == 'SSLConnectionError'){
            reason = "SSLConnectionError" ;
        }       
        else if (error.mfpFlow == 'MISSING_INFORMATION'){
            reason = "MISSING_INFORMATION" ;
        }           
         else if (error.mfpFlow == 'REQUEST_SENT_FAILED'){
            reason = "SSLConnectionError" ;
        }   
        else if (error.mfpFlow == 'JSON_READ_FAILED'){
            reason = "SSLConnectionError" ;
        }          
        else{
            reason = "Unkwon reason"; // TODO ???
        }
        
        return reason;
    }
    
    // Obtains a token for the node filter itself (by mfp).
    this.obtainConfClientToken = function() {
        var tokenUrl = this.authServerUrl + Constant.TOKEN_URL_SUFFIX
        
        if ( (this.userid !== undefined) && (this.pass !== undefined) ) {
            var auth = "Basic " + new Buffer(this.userid + Constant.COLON + this.pass).toString("base64");            
        } else {
            var msg = 'No confClientID or confClientPass, if you are working in embedded-AZ mode, token validation will fail.';
            SecurityLogger.debug(msg);            
        }
        
        let askedForScope = 'authorization.introspect';
        let mfpProviderName = this.mfpProviderName;
        return new Promise(function (fulfill, reject){
            let form = 'grant_type=client_credentials&scope=' + askedForScope;
            let cacheType = 'token';
            let cacheKey = 'mfp-key-' + mfpProviderName;
            var requestData = createOptionsForUrlOpen(cacheType, cacheKey, tokenUrl, form, auth, strategy.certificate);
            
            sendRequest(requestData, function(error, response, body) {
                if (error) {
                    doError(reject, error, tokenUrl, 'TOKEN_FAILED_INTERNAL_SERVER_ERROR');
                } else if (200 == response.statusCode && body) {
                    SecurityLogger.debug('Received confidential client token by ' + tokenUrl);
                    fulfill(body.access_token);
                } else if (400 == response.statusCode) {
                    // Sending 500 to application because it should not expose servers issues.
                    
                    if (body.error == Constant.AUTHORIZATION_FAILED_INVALID_CLIENT) {
                        // The filter is not defined as a confidential client in MFP.
                        reject(new RejectionMessage(Constant.CONF_CLIENT_NOT_DEFINED, null, Constant.AUTHORIZATION_FAILED_INTERNAL_SERVER_ERROR, 500, 'TOKEN_FAILED_UNKNOWN_CLIENT'));
                    } else if (body.error == Constant.AUTHORIZATION_FAILED_INVALID_SCOPE) {
                        // The defined confidential client's scope in MFP server is invalid i.e. askedForScope's value is not contained in the allowed scope.
                        reject(new RejectionMessage(Constant.CONF_CLIENT_INVALID_SCOPE, null, Constant.AUTHORIZATION_FAILED_INTERNAL_SERVER_ERROR, 500, 'TOKEN_FAILED_INVALID_GRANT'));
                    } else {
                        // Other reasons, related to bad request.
                        reject(new RejectionMessage(Constant.BAD_REQUEST, null, Constant.AUTHORIZATION_FAILED_INTERNAL_SERVER_ERROR, 500, 'TOKEN_FAILED_INTERNAL_SERVER_ERROR'));
                    }
                    
                } else {
                    // Other reasons.
                    reject(new RejectionMessage(Constant.FAILED_TO_OBTAIN_CONF_CLIENT_TOKEN, null, Constant.AUTHORIZATION_FAILED_INTERNAL_SERVER_ERROR, 500, 'TOKEN_FAILED_INTERNAL_SERVER_ERROR'));
                }
            });
        }); 
    }
    
    this.introspect = function (confClientToken, appToken) {
        // confClientToken is the access token that was received by obtainConfClientToken.
        // appToken is the application token - the token of the mobile application, should be in the request's body.
        if (confClientToken) {
            var auth = Constant.AUTHORIZATION_BEARER + ' ' + confClientToken;
        }
        var autoServerUrl = this.authServerUrl;
        var introspectionUrl = autoServerUrl + Constant.INTROSPECTION_URL_SUFFIX;
                
        return new Promise(function (fulfill, reject){
          let form = 'token=' + appToken + '&token_type_hint=access_token';
          let cacheType = 'introspect';
          var hash = crypto.createHash('sha256');
          var cacheKey = 'mfpkey-' + hash.update(appToken).digest('base64');
          
          var requestData = createOptionsForUrlOpen(cacheType, cacheKey, introspectionUrl, form, auth, strategy.certificate);
          
          sendRequest(requestData, function(error, response, body){
              if (error) {
                  doError(reject, error, introspectionUrl, 'AUTHORIZATION_FAILED_INTERNAL_SERVER_ERROR');
              } else {
                  if (200 == response.statusCode) {
                      SecurityLogger.debug('Received 200 OK for introspection by ' + introspectionUrl);
                      fulfill(body); // The body contains the security context.
                  } else if ( (401 == response.statusCode) || (403 == response.statusCode) ) {
                      // Unauthorized to introspect, perhaps the confidential client token has become invalid - get a new one.
                      reject(new RejectionMessage(Constant.UNAUTHORIZED_TO_INTROSPECT,Constant.UNAUTHORIZED_TO_INTROSPECT_REASON, 
                          Constant.AUTHORIZATION_FAILED_INTERNAL_SERVER_ERROR, 500, 'AUTHORIZATION_FAILED_INVALID_CREDENTIALS'));
                      
                  } else if (409 == response.statusCode) {
                      // The application resent the original request.
                      reject(new RejectionMessage(Constant.AUTHORIZATION_FAILED_MFP_SERVER_CONFLICT_RESPONSE_REASON, null, 
                          Constant.AUTHORIZATION_FAILED_MFP_SERVER_CONFLICT_RESPONSE, response.statusCode,'AUTHORIZATION_PENDING'));
                  } else {
                      reject(new RejectionMessage(Constant.BAD_REQUEST, null, Constant.AUTHORIZATION_FAILED_INTERNAL_SERVER_ERROR, 500,'AUTHORIZATION_FAILED_INTERNAL_SERVER_ERROR'));
                  }
              }
          });
        });
    }
    
    this.validateIntrospectionData = function(data) {
        // if (apicUtils.isNull(data) || apicUtils.isUndefined(data) || apicUtils.isEmpty(data)){
        if (!data){
            // We have no introspection data from validationManager, should
            // not happen if we didn't have an error.
            SecurityLogger.warn('The introspection data does not exist, sends 400 to client');
            return done(null,null,{code:Constant.AUTHORIZATION_FAILED_INVALID_REQUEST, status:400, validationCode:'AUTHORIZATION_FAILED'});
        }
        if (data[Constant.ACTIVE] == false) {
            SecurityLogger.warn('The client token is invalid, sends 401 to client');
            return done(null,null,{code:Constant.AUTHORIZATION_FAILED_INVALID_TOKEN, status:401, validationCode:'AUTHORIZATION_FAILED_INVALID_ACCESS_TOKEN'});
        }
        
        if (!validateScope(data[Constant.SCOPE], this.scope)) {
            SecurityLogger.warn('The required scope(s) are not contained in the granted scope(s), sends 403 to client');
            return done(null,null,{code:Constant.AUTHORIZATION_FAILED_INSUFFICIENT_SCOPE, status:403, validationCode:'AUTHORIZATION_FAILED_INSUFFICIENT_SCOPE', scope:this.scope});
        }
        SecurityLogger.debug('The required scope(s) are contained in the granted scope(s), authorization succeeds');

        // securityContext === data
        return done(null,data,null);
    }
    
    function validateScope(grantedScope, requiredScope) {
        var grantedScopesArray = getArrayFromString(grantedScope, ' ');
        var requiredScopesArray = getArrayFromString(requiredScope, ' ');
        for (let i = 0; i < requiredScopesArray.length; i++) {
            let requiredInGranted = false;
            for (let j = 0; j < grantedScopesArray.length; j++) {
                if (requiredScopesArray[i] === grantedScopesArray[j]) {
                    requiredInGranted = true;
                    break;
                }
            }
            if (!requiredInGranted) {
              return false;
            }
        }

        return true;
    }

    function getArrayFromString (value,delim) {
        var array = [];
        if (value) {
            var a = value.split(delim);
            if (a && a.length>0) {
                a.forEach(function(item){
                    array.push(item.trim());
                });
            }
        }
        return array;
    }
    
}

exports = module.exports = tokenValidator;
