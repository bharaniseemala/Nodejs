// ***************************************************** {COPYRIGHT-TOP} ***
//* Licensed Materials - Property of IBM
//* 5725-L30, 5725-Z22, 5725-Z63, 5725-U33, 5725-Z63
//*
//* (C) Copyright IBM Corporation 2016, 2017
//*
//* US Government Users Restricted Rights - Use, duplication, or
//* disclosure restricted by GSA ADP Schedule Contract with IBM Corp.
// ********************************************************** {COPYRIGHT-END}**
//
var apim, errs, dbglog, verbose, debug, isV5;
// The apim module is globally available in version 6.  If it is not defined, we're on version 5
// and must initialize library variables as was done before, but for v6, some of these variables
// are not currently set or are to be set differently
if (apim === undefined) {
  isV5 = true;
  apim = require('local:///isp/policy/apim.custom.js');
  errs = require('local:///isp/policy/apim.exception.js');
  dbglog = apim.console;
  verbose = apim.verbose;
  debug = apim.debug;
} else {
  isV5 = false;
  // TODO: should dbglog be in the apim library??
  dbglog = console.options({'category':'apiconnect'});
  // TODO: v5 this is based on a system variable to provide a logging level, how in v6? for now, default to true.
  verbose = true;
  // TODO: this is based on the presence of the HTTP Header APIm-Debug = true, should this be in the apim library??
  // For now, only set to true if the write analytics function exists and this header is set to true
  debug = apim.writeAnalyticsDebug !== undefined && require('header-metadata').original.get('APIm-Debug') === 'true';
  // The Errors object in v5 apim.exeception.js has been moved in v6 into the compatibility apim library
  errs = apim;
}
//var Fiber = require('fibers');
var util = require('util');
var converter = require('json-xml-converter');

var analyticsData;

// only v5 uses this exported callback
if (isV5) {
  exports.callbackOnExit = function(callback) {
    callback();  // local function is synchronous to caller's require()
  }
}

function startsWith(aString, str) {
  return aString.slice(0, str.length) == str;
}
function endsWith(aString, str) {
  return aString.slice(-str.length) == str;
}
function substringAfter(aString, str) {
  var i = aString.indexOf(str);
  if (i != -1) {
    return aString.slice(i + str.length);
  }
}
function customSplit(string) {
  if (string === undefined) return;
  var result = string.split('.');
  for (var i=0; i<result.length; i++) {
    // trailing slash means next array item need to be combined with the current one
    if (endsWith(result[i], '\\')) {
      // remove the trailing slash from the current item
      result[i] = result[i].slice(0, result[i].length -1);
      // combine this and the next array element and get rid of the next array element (assuming there is one)
      if (i != result.length - 1) {
        result[i] += '.' + result[i+1];
        result.splice(i+1, 1);
        --i; // check same token again, in case there are multiple escaped '.' in one token
      }
    }
  }
  return result;
}

// input and output data structures.
var inputJSONContent = undefined;
var outputJSONContent = undefined;

// object for handling multiple inputs
var inputContentVector = {};

// policyProperties is declared globally so while debugging it can be seen from anywhere
var mapResolveAPICVariables = (apim.getContext('api.properties.x-ibm-gateway-map-resolve-apic-variables') !== 'false');
var policyProperties = apim.getPolicyProperty(undefined, undefined, mapResolveAPICVariables);
var logPrefix = "Map: API=" + apim.getContext('api.name') + ", policy=" + policyProperties.title + " : ";
if (debug) {
  dbglog.info(logPrefix + 'version ' + (isV5? '5':'6') + ' map policy' );
}
var xsiNamespaceURL = "http://www.w3.org/2001/XMLSchema-instance";
var xsiPrefix = "xsi";
var subTypeTable = undefined;
// v5072 change in behavior.  Looking inside an array will now return an array.  Prior behavior was to return the first element's matching
// value inside of the array.  This toggle will allow prior behavior.  The default value is to return the entire array.
var mapArrayFirstElementToggle = (apim.getContext('api.properties.x-ibm-gateway-map-array-first-element-value') === 'true');

// New toggle for customers that do not want JSON empty arrays output, three potential values:
// 1. all - default behavior, all empty arrays are output, including empty children arrays
// 2. parent - only the parent empty array is output, children actions are not attempted
// 3. none - no empty output array will be produced
var rawMapEmptyJSONArraysToggle = apim.getContext('api.properties.x-ibm-gateway-map-create-empty-array');
// if the rawMapEmptyJSONArraysToggle wasn't defined or has an invalid value, set it to the default value (all)
if (rawMapEmptyJSONArraysToggle === undefined ||
    (rawMapEmptyJSONArraysToggle != 'none' &&
     rawMapEmptyJSONArraysToggle != 'parent')) {
  rawMapEmptyJSONArraysToggle = 'all';
}
// start processing
doProcessing(policyProperties);
//var fiber = Fiber(doProcessing);
//fiber.run(policyProperties);
/////////////

function convertXMLtoJSON(outputDocument, inputDocument) {
  for (var property in inputDocument) {
    if (inputDocument.hasOwnProperty(property) && (property != '@xmlns')) {
      var propertyObj = inputDocument[property];
      if (property.indexOf(':') >= 0) {
        if (startsWith(property, '@')) {
          property = '@' + substringAfter(property, ':');
        } else {
          property = substringAfter(property, ':');
        }
      }
      var propertySplit = property.split();
      var type = util.safeTypeOf(propertyObj);
      switch (type) {
      case 'object':
          var newObj = {};
          convertXMLtoJSON(newObj, propertyObj);
          // empty object a result of a namespace which is removed and no value, so set the
          // property to an empty string
          if (Object.keys(newObj).length === 0) {
            newObj = '';
          }
          setOutput(propertySplit, newObj, outputDocument, false, false);
        break;
      case 'array':
          setOutput(propertySplit, [], outputDocument, false, false);
          convertXMLtoJSON(outputDocument[property], propertyObj);
          break;
      default:
          setOutput(propertySplit, propertyObj, outputDocument, false, false);
          break;
      }
    }
  }
}

function doProcessing (policyProperties) {
  outputJSONContent = {};
  var outputNames = Object.keys(policyProperties.outputs);
  // don't do anything unless you have named outputs provided
  if (outputNames) {
    // for every output configured, attempt to create any required output properties
    for (var i=0; i<outputNames.length; i++) {
      var outputName = outputNames[i];
      // get the schema object for this output
      var outputSchemaDefinition;
      var outputSchema = policyProperties.outputs[outputName].schema;
      // can't do anything without a schema
      if (outputSchema && outputSchema != {}) {
        outputSchemaDefinition = outputSchema['$ref'];
        // if the schema consists of a reference, resolve that reference.
        if (outputSchemaDefinition) {
          outputSchema = getSwaggerDefinition(outputSchemaDefinition);
        }

        // you must have an output variable to do anything
        var outputVariable = policyProperties.outputs[outputName].variable;
        if (outputVariable) {
          // use the schema to create an initial output from any schema required properties
          try {
            createInitialOutputFromSchema(outputSchema, outputVariable);
          } catch (err) {
            dbglog.error(logPrefix + "createInitialOutputFromSchema failed creating initial output: " + err.errorMessage);
          }
        }
      }
    }

    // pull the named input data into a common object keyed by the input name
    if (policyProperties.inputs) {
      createInputVector(policyProperties, inputContentVector);
    } else {
      dbglog.warn(logPrefix + "map contains no inputs");
    }

    // processing the mapping rules
    var actions = policyProperties.actions;
    try {
      ProcessMappingRules(actions, inputContentVector, outputJSONContent, true, false);
    } catch (err) {
      dbglog.error(logPrefix + "ProcessMappingRules failed: " + err.errorMessage);
    }

    // output processing of all named outputs
    var policyOutputType = undefined;
    var setPolicyOutputType = false;
    var processedContexts = [];
    for (var i=0; i<outputNames.length; i++) {
      var outputName = outputNames[i];
      // get the output variable (context root) associated with this output, ie, <context>.<body|headers|status> or <varname>
      // any additional object keying for a body, ie, message.body.x.y.z for example, is ignored.  The x.y.z has been used during
      // mapping rules to properly provide the output objects within the map a prefix of x.y.z for every set or create action.
      var outputVariable = policyProperties.outputs[outputName].variable;
      var outputSplit = [];
      if (outputVariable) {
        var outputSplit = customSplit(outputVariable);
        var outputSplitPathOnly;
        outputVariable = outputSplit[0];
        if (outputSplit[1]) {
          outputVariable += '.' + outputSplit[1];
          if ((outputSplit[1] == 'status' || (outputSplit[1] == 'headers' )) && outputSplit[2]) {
            outputVariable += '.' + outputSplit[2];
          }
        }
      }

      // get the content type from the policy output definition, if not provided, json assumed
      var ctype = policyProperties.outputs[outputName].content;
      if (!ctype) {
          ctype = 'application/json';
      }

      // only process this named output if the root context hasn't been processed before
      if (outputVariable && processedContexts.indexOf(outputVariable) == -1) {
        // add the root context to the array so we won't process other outputs with the same context
        processedContexts.push(outputVariable);

        // throw away anything following <context>.<body> that may have been used to further key the output
        if (outputSplit[1] != 'status' && outputSplit[1] != 'headers') {
          outputSplitPathOnly = outputSplit.slice(2);
          outputSplit = outputSplit.slice(0,2);
        }

        // get the outputContent
        var outputContent = getOutputContent(outputName, outputSplit, outputSplitPathOnly, ctype, outputJSONContent, outputVariable);
        if (debug) {
            analyticsData = apim.addAnalyticsOutputToData(analyticsData, apim.generateOutputDataForAnalytics(outputContent, undefined, ctype, undefined, false), outputName);
        }

        // we should have content to output unless the XML conversion didn't have a schema
        if (outputContent != undefined) {
          // output the content to the output variable
          try {
            // TODO: TEMPORARY code ... v6 required the XML output be output as a DOM
            // remove when https://github.ibm.com/apimesh/reboot-defects/issues/426 is fixed
            if (!isV5) {
              if (apim.isXML(ctype)) {
                outputContent = XML.parse(outputContent);
              }
            }
            // end of TEMPORARY CODE
            apim.setvariable(outputVariable, outputContent, 'set');
          } catch (err) {
            var errorMessage = logPrefix + 'Output ' + outputName + ': setvariable failed: ' + err.errorMessage;
            dbglog.error(errorMessage);
            apim.error(errs.Errors.MapError,'500','Internal Error',errorMessage);
          }

          // if outputting a context body, then set the content type in the context headers
          if (outputSplit[1] == 'body') {
            var outputVariableHeaders = outputSplit[0] + '.headers.content-type';
            try {
              apim.setvariable(outputVariableHeaders, ctype, 'set');
            } catch (err) {
              var errorMessage = logPrefix + 'Output ' + outputName + ': setvariable failed for header content-type: ' + err.errorMessage;
              dbglog.error(errorMessage);
              apim.error(errs.Errors.MapError,'500','Internal Error',errorMessage);
            }
          }

          // if the output was for message.body, then set the policy output content type
          if (outputVariable == 'message.body') {
            policyOutputType = ctype;
            setPolicyOutputType = true;
          }

          // if the output was for message.headers, if there is a content type header, set the
          // media type to this headers value
          if (outputSplit[0] == 'message' && outputSplit[1] == 'headers') {
            outputSplit.splice(2, outputSplit.length-2);
            var headers = getProperty(outputSplit, outputJSONContent, false, false);
            var regex = /,(content-type),/i;
            var headerkeys = ',' + Object.keys(headers).toString() + ',';
            var headername = headerkeys.match(regex);
            // match will have the starting and ending commas, so lookup having sliced off the first/last character
            if (headername && headername[1]) {
              // this output is just message.headers, so save the content type in case we need to change the output policy
              policyOutputType = headers[headername[1]];
            }
          }
        } else {
          dbglog.error(logPrefix + 'Output ' + outputName + ': no output content');
        }
      }
    }

    // if message.body was updated and we have a content-type, set the policy output type
    if (policyOutputType && setPolicyOutputType) {
      try {
        apim.output(policyOutputType);
      } catch(err) {
        var errorMessage = logPrefix + 'Failed setting output media type of ' + policyOutputType + ': ' + err.errorMessage;
        dbglog.error(errorMessage);
        apim.error(errs.Errors.MapError,'500','Internal Error',errorMessage);
      }
    }
    if (debug) {
        var analyticsOther = {};
        analyticsOther.result = 'OK';
        analyticsData = apim.addAnalyticsOtherToData(analyticsData, analyticsOther);
        analyticsData = apim.addPolicyPropertiesToData(analyticsData, analyticsOther);
        apim.writeAnalyticsDebug(analyticsData);
    }
  } else {
    dbglog.error(logPrefix + 'No outputs configured');
  }
}

// local function meant to handle differences between the v5 and v6 versions of getSwaggerDefinition
function getSwaggerDefinition(typeReferencePath, definitionOnly) {
    var result = undefined;
    if (isV5) {
        // in v5, use the apim.custom.js synchronous function
        result = apim.getSwaggerDefinition(typeReferencePath, definitionOnly);
    } else {
        // in v6, getSwaggerDefinition is asynchronous, use the fiber to make it into a synchronous like operation
        /*
        var fiber = Fiber.current;
        apim.getSwaggerDefinition(typeReferencePath, definitionOnly, function(error, def) {
          if (error) {
            fiber.run(undefined);
          } else {
            fiber.run(def);
          }
        });
        result = Fiber.yield();
        */
    }
    return result;
}

function getOutputContent(outputName, outputSplit, outputSplitPathOnly, ctype, outputJSONContent, rootContext) {
    // get the output for this context from the overall output document
    var thisOutputJSONContent = getProperty(outputSplit, outputJSONContent, false, false);

    var outputContent = undefined;

    // XML Content requires the output schema to produce the XML output equivalent of the mapped JSON output
    if (apim.isXML(ctype)) {
      // get the schema object for this output
      var outputSchema = policyProperties.outputs[outputName].schema;
      // can't do anything for XML output without a schema
      if (outputSchema && outputSchema != {}) {
        var outputSchemaDefinition = outputSchema['$ref'];
        // if the schema consists of a reference, resolve that reference.
        var outputDefinitionRootPath = undefined;
        if (outputSchemaDefinition) {
          // get the root path to all definitions where this output definition resides
          // this can be used later should a polymorphic xml element be encountered during
          // xml generation that would require a dynamic schema lookup
          var outputDefinitionSplit = outputSchemaDefinition.split('/');
          outputDefinitionSplit.pop();
          outputDefinitionRootPath = outputDefinitionSplit.join('/');

          // get the schema definition for this output
          outputSchema = getSwaggerDefinition(outputSchemaDefinition);
        }
        if (outputSchema !== undefined) {
          outputSchema = getWrappedSchemaDefinition(outputSchema, outputSplitPathOnly);

          findAdditionalXMLOutputs(outputSchema, outputName, rootContext);

          // setup inline namespace object information
          var inlineNamespacesObj = {};
          inlineNamespacesObj.namespaceList = {};
          inlineNamespacesObj.dupNamespaceArray = [];
          inlineNamespacesObj.inlineNamespaces = true;
          if (policyProperties.options && policyProperties.options.inlineNamespaces === false) {
            inlineNamespacesObj.inlineNamespaces = false;
          }

          // get all of the named namespaces in the document to put into the root XML element
          if (!inlineNamespacesObj.inlineNamespaces) {
            getAllNamespaces(outputSchema, thisOutputJSONContent, true, outputDefinitionRootPath, inlineNamespacesObj.namespaceList, inlineNamespacesObj.dupNamespaceArray);
          }

          // if for the same prefix there are different namespace uris, remove them from the list
          for (var i=0; i<inlineNamespacesObj.dupNamespaceArray.length; i++) {
            delete inlineNamespacesObj.namespaceList[inlineNamespacesObj.dupNamespaceArray[i]];
          }

          // take the output from the map and create the XML output using this output's schema
          outputContent = createOutputContent(outputName, outputSchema, thisOutputJSONContent, true, undefined, false, inlineNamespacesObj, outputDefinitionRootPath);
        } else {
          var errorMessage = logPrefix + "Output '" + outputName + "' schema definition '" + outputSchemaDefinition + "' not found in swagger, schema required for XML output.";
          dbglog.error(errorMessage);
          apim.error(errs.Errors.MapError,'500','Internal Error',errorMessage);
        }
      } else {
        var errorMessage = logPrefix + "Output '" + outputName + "' schema not found in map output definition, schema required for XML output.";
        dbglog.error(errorMessage);
        apim.error(errs.Errors.MapError,'500','Internal Error',errorMessage);
      }
    } else {
      // not XML, so just use the JSON content for JSON output
      outputContent = thisOutputJSONContent;
    }

    return outputContent;
}

// This function will search thru the policy outputs that follow the one identified by the base output name,
// looking for another output that shares the same base context that is of an XML type.  If found, the schema
// is retrieved for this additional context which is merged into the base output schema that describes the first
// output found for this base context.
function findAdditionalXMLOutputs(baseOutputSchema, baseOutputName, baseRootContext) {
  var outputNames = Object.keys(policyProperties.outputs);
  // start with the output following the base output name provided
  for (var i=outputNames.indexOf(baseOutputName)+1; i<outputNames.length; i++) {
    var output = policyProperties.outputs[outputNames[i]];
    var outputVariable = output.variable;

    // current output root context is the same as the base context
    if (startsWith(outputVariable, baseRootContext)) {
      var ctype = output.content;
      // make sure this content type is XML
      if (apim.isXML(ctype)) {
        // get the schema object for this output
        var schemaToMerge = output.schema;
        // can't do anything for XML output without a schema
        if (schemaToMerge && schemaToMerge !== {}) {
          var outputSchemaDefinition = schemaToMerge['$ref'];
          // if the schema consists of a reference, resolve that reference.
          if (outputSchemaDefinition) {
            // get the schema defintion for this output
            schemaToMerge = getSwaggerDefinition(outputSchemaDefinition);
          }
          if (schemaToMerge !== undefined) {
            schemaToMerge = getWrappedSchemaDefinition(schemaToMerge, customSplit(substringAfter(outputVariable, baseRootContext)));
            // merge the new schema into the base schema
            mergeXMLSchema(baseOutputSchema, schemaToMerge, outputNames[i], true);
          } else {
            var errorMessage = logPrefix + "Schema Merge Error: Output '" + outputNames[i] +
                               "' schema definition '" + outputSchemaDefinition + "' not found in swagger, schema required for XML output.";
            dbglog.error(errorMessage);
            apim.error(errs.Errors.MapError,'500','Internal Error',errorMessage);
          }
        } else {
          var errorMessage = logPrefix + "Schema Merge Error: Output '" + outputNames[i] +
                             "' schema not found in map output definition, schema required for XML output.";
          dbglog.error(errorMessage);
          apim.error(errs.Errors.MapError,'500','Internal Error',errorMessage);
        }
      } else {
        var errorMessage = logPrefix + "Schema Merge Error: Output '" + outputNames[i] +
                           "' has the same base context as output '" + baseOutputName +
                           "' but is configured for a non-XML content type of '" + ctype + "'.";
        dbglog.error(errorMessage);
        apim.error(errs.Errors.MapError,'500','Internal Error',errorMessage);
      }
    }
  }
}

// This function will wrap a schema in schema elements that describe the parent elements
// represented by the additional pathing beyond the root context of the output, for
// example, request.body.Envelope.Header, the schema must describe Envelope and Header
// where this additional schema is a property of Header.  If no additional pathing, then
// the same outputSchema provided as input will be returned
function getWrappedSchemaDefinition(outputSchema, outputSplit) {
  if (outputSchema !== undefined) {
    var wrapOutputSchema = {"type":"object"};
    var obj = wrapOutputSchema;
    for (var j=0; j<outputSplit.length; j++) {
      if (outputSplit[j] !== '') {
        obj.properties = {};
        obj.properties[outputSplit[j]] = {};
        obj.properties[outputSplit[j]].type = "object";
        obj = obj.properties[outputSplit[j]];
      }
    }

    // the last property of the wrapped object should carry the type of the schema being
    // wrapped.  If that schema does not have a type property, fill it in based on the schema
    // having a properties or items property and default to string when all else fails.
    if (outputSchema.type !== undefined && outputSchema.type !== '') {
      obj.type = outputSchema.type;
    } else {
      if (outputSchema.properties !== undefined) {
        obj.type = 'object';
      } else if (outputSchema.items !== undefined) {
        obj.type = 'array';
      } else {
        obj.type = 'string';
      }
    }
    // schemas of type object can be wrapped and must have properties
    if (obj.type === 'object' && outputSchema.properties !== undefined) {
      obj.properties = outputSchema.properties;
    } else {
      // schemas of type array can be wrapped and must have items
      if (obj.type === 'array' && outputSchema.items !== undefined) {
        obj.items = outputSchema.items;
      }
    }
    return wrapOutputSchema;
  }
}

//This recursive function will merge an additional schema into the base schema defined for an XML output.
function mergeXMLSchema(baseSchema, schemaToMerge, outputName, isRootLevel) {
  var type;
  var xml;

  // get the child properties of the schemaToMerge
  var properties = schemaToMerge.properties;

  for (var property in properties) {
    if ({}.hasOwnProperty.call(properties, property)) {
      // get the property object for this property and resolve any allOfs that are found
      // to fully populate the schema
      var propertyObj = properties[property];
      if (propertyObj.allOf) {
        resolveAllOf(propertyObj, propertyObj.allOf);
      }
      xml = propertyObj.xml;
      type = propertyObj.type;

      // current propery NOT in the base schema, so we're done with the recursion
      var basePropertyObj = baseSchema.properties[property];
      if (basePropertyObj === undefined) {
        // you can't merge at the root level as this will create malformed XML with two root elements
        if (!isRootLevel) {
          baseSchema.properties[property] = propertyObj;
        } else {
          var errorMessage = logPrefix + "Schema Merge Error: Output '" + outputName +
                             "' root property '" + property +
                             "' does not exist in the base schema.  A merge would create a malformed XML document.";
          dbglog.error(errorMessage);
          apim.error(errs.Errors.MapError,500,'Internal Error',errorMessage);
        }
      } else {
        if (basePropertyObj.allOf) {
          resolveAllOf(basePropertyObj, basePropertyObj.allOf);
        }
        // current property in the base schema
        // ensure the current property is the same type as the base property
        if (basePropertyObj.type === type) {
          // current property has xml properties
          if (xml) {
            // base schema does not have xml properties, merge the xml into the base schema
            if (!basePropertyObj.xml) {
              baseSchema.properties[property].xml = xml;
            } else {
              // both this property and base property have xml, log an error if the xmls don't match
              var baseSchemaXML = baseSchema.properties[property].xml;
              var xmlkeys = Object.keys(xml);
              for (var i=0; i<xmlkeys.length; i++) {
                // base schema does not have this specific xml property, merge the xml into the base schema
                if (baseSchemaXML[xmlkeys[i]] === undefined) {
                  baseSchemaXML[xmlkeys[i]] = xml[xmlkeys[i]];
                } else {
                  // base schema does have this specific xml property, log an error if the values don't match
                  // the base schema value will remain
                  if (baseSchemaXML[xmlkeys[i]] !== xml[xmlkeys[i]]) {
                    var errorMessage = logPrefix + "Schema Merge Error: Output '" + outputName +
                                       "' property '" + property + "', xml key '" + xmlkeys[i] +
                                       "' has a value of '" + xml[xmlkeys[i]] +
                                       "' that does not match the existing schema value of '" + baseSchemaXML[xmlkeys[i]] + "'.";
                    dbglog.error(errorMessage);
                    apim.error(errs.Errors.MapError,500,'Internal Error',errorMessage);
                  }
                }
              }
            }
          }

          // objects and arrays need recursion
          switch (type) {
          case 'object':
            // objects should have child properties, so navigate into the child input document and recurse
            if (propertyObj.properties) {
              mergeXMLSchema(basePropertyObj, propertyObj, outputName, false);
            }
            break;

          case 'array':
            // the array items will be what we need to recurse, so make sure we have something in the schema to recurse
            if (propertyObj.items) {
              // get the array schema and resolve any allOfs that are found
              // to fully populate the schema
              var item = propertyObj.items;
              if (item.allOf) {
                resolveAllOf(item, item.allOf);
              }
              mergeXMLSchema(basePropertyObj.items, item, outputName, false);
            }
            break;

          default:
            // if the scalar object has properties, this should be for a leaf element that has attributes
            if (propertyObj.properties) {
              // if the base object also has properties, recurse
              if (basePropertyObj.properties) {
                mergeXMLSchema(basePropertyObj.properties, propertyObj.properties, outputName, false);
              } else {
                basePropertyObj.properties = propertyObj.properties;
              }
            }
            break;
          }
        } else {
          var errorMessage = logPrefix + "Schema Merge Error: Output '" + outputName +
                             "' property '" + property + "' has a type of '" + type +
                             "' that does not match the existing schema type of '" + basePropertyObj.type + "'.";
          dbglog.error(errorMessage);
          apim.error(errs.Errors.MapError,500,'Internal Error',errorMessage);
        }
      }
    }
  }
}

// This function is a recursive function which will generate the XML output string based on the schema provided and the output
// JSON document for this output that will contain all of the leaf element values.
function createOutputContent(outputName, schema, outputJSONDocument, isRootLevel, inheritedXML, attributesOnly, inlineNamespacesObj, outputDefinitionRootPath) {
  // ensure that the schema's root document only has one root property
  if (isRootLevel) {
    var propertyKeys = [];
    if (schema.properties) {
      propertyKeys = Object.keys(schema.properties);
    } else {
      dbglog.error(logPrefix + 'Output ' + outputName + ': createOutputContent: root schema object has no properties.');
    }

    if(propertyKeys.length !== 1) {
      var errorMessage = logPrefix + 'Output ' + outputName + ': Invalid XML schema encountered, multiple elements or no elements: ' + propertyKeys.join(', ') + '; cannot be specified at the root document level.';
      dbglog.error(errorMessage);
      apim.error(errs.Errors.MapError,'500','Internal Error',errorMessage);
      return undefined;
    }
  }

  var outputContent = '';
  var type;
  var xml;
  if (util.safeTypeOf(schema.type) == 'array') {
    type = schema.type[0];
  } else {
    type = schema.type;
  }

  // get the child properties (either objects or leaf elements)
  var properties = schema.properties;
  var requiredProperties = schema.required;

  // we first need to search for child properties that have xml indicating the property is an attribute,
  // then add those attributes and values to the element output which is currently still open, ie, "<element"
  var attrnsList = [];
  for (var property in properties) {
    if ({}.hasOwnProperty.call(properties, property)) {
      var propertyObj = properties[property];
      xml = propertyObj.xml;
      if (xml && xml.attribute) {
        // so this property is an attribute
        var attr='';
        // remove the badgerfish attribute prefix if any
        if (startsWith(property, '@')) {
          attr = substringAfter(property, '@');
        } else {
          attr = property;
          property = '@' + property;
        }
        // an xml name will change the attribute name that is output
        if (xml.name) {
          attr = xml.name;
        }
        var attrns = undefined;
        if (xml.prefix && xml.namespace) {
          attr = xml.prefix + ":" + attr;
          // setup the namespace declaration if we're doing inline namespaces, the prefix is not the special xml prefix and
          // we've not encountered this prefix before in other sibling attributes, and this namespace is also not the same one
          // as was used by the parent element.
          if (inlineNamespacesObj.inlineNamespaces && xml.prefix !== 'xml' && attrnsList.indexOf(xml.prefix) === -1 &&
              (inheritedXML === undefined || (xml.prefix !== inheritedXML.prefix && xml.namespace !== inheritedXML.namespace))) {
            attrns = " xmlns:" + xml.prefix + "=\"" + xml.namespace + "\"";
            // push the prefix to the list of attribute prefixes encountered so we don't create duplicate namespace declarations
            attrnsList.push(xml.prefix);
          }
        }
        var attrStr = ' ' + attr + '=\"';
        var attrValue = getProperty(property.split(), outputJSONDocument, false, false);

        // attribute value must be a scalar, so if we have a non scalar data type at this point, ignore it
        if (util.safeTypeOf(attrValue) === 'object' || util.safeTypeOf(attrValue) === 'array') {
          attrValue = undefined;
        }

        // no attribute value, see if there is a default defined in the schema
        if (attrValue == undefined) {
          attrValue = propertyObj.default;
        }

        // add the attribute to the element string if present
        if (attrValue !== undefined) {
          outputContent += attrStr + escapeXML(attrValue.toString()) + '\"';
          if (attrns) {
            outputContent += attrns;
          }
        }
      }
    }
  }

  // all done with attributes, so for non root parents, write out the end '>' which is omitted
  // until the attributes are processed.
  if (!isRootLevel) {
    outputContent += '>';
  }

  // only process non attribute properties if requested
  if (!attributesOnly) {
    // now process the non attribute properties
    for (var property in properties) {
      if ({}.hasOwnProperty.call(properties, property)) {
        // get the mapped value for this property
        var propertyValue = getProperty(property.split(), outputJSONDocument, false, false);
        // policy option includeEmptyXMLElements default is to include, so if not provided or if provided and true is specified
        // any empty element is included.  If provided and false, then only elements with a value or empty elements that are required
        // are processed.
        var includeEmptyXMLElementsOption;
        if (policyProperties.options) {
          includeEmptyXMLElementsOption = policyProperties.options.includeEmptyXMLElements;
        }
        var isRequired = requiredProperties && requiredProperties.indexOf(property) !== -1;
        var propertyObj = properties[property];
        // if this property has a discriminator, we need to get the schema associated with this property and add the subtype
        // properties to this schema dynamically
        var subTypeObject = {};
        if (propertyObj['x-ibm-discriminator'] === true) {
          // We're going to be modifying property object in this case, so create a deep copy of this object so changes are isolated to this object
          // and not other referenced objects
          propertyObj = JSON.parse(JSON.stringify(propertyObj));
          // the x-ibm-discriminator property should have been mapped to determine the subtype to use
          subTypeObject.name = getProperty(['x-ibm-discriminator', '$'], propertyValue, false, false);
          // getSubTypeSchema will modify the property object to include the subtype schema
          if (subTypeObject.name === undefined || !getSubTypeSchema(propertyObj, outputDefinitionRootPath, subTypeObject)) {
            var errorMessage;
            if (subTypeObject.name) {
              errorMessage = logPrefix + 'x-ibm-discriminator schema definition not found: ' + outputDefinitionRootPath + '/' + subTypeObject.name;
            } else {
              errorMessage = logPrefix + 'x-ibm-discriminator not provided for element: ' + property;
            }
            dbglog.error(errorMessage);
            // if the current property has a base xsi-type configured, it will be used for the xsi:type attribute
            if (propertyObj['x-xsi-type']) {
              subTypeObject.name = propertyObj['x-xsi-type'];
            }
          }
          if (propertyObj['x-xsi-type-xml']) {
            subTypeObject.prefix = propertyObj['x-xsi-type-xml'].prefix;
            subTypeObject.namespace = propertyObj['x-xsi-type-xml'].namespace;
          }
        }
        if (propertyValue !== undefined || isRootLevel || includeEmptyXMLElementsOption === undefined || includeEmptyXMLElementsOption === true ||
            isRequired) {
          var thisInheritedXML = inheritedXML;
          var nullable = propertyObj['x-nullable'] && propertyValue === undefined;
          if (propertyObj.allOf) {
            resolveAllOf(propertyObj, propertyObj.allOf);
          }
          xml = propertyObj.xml;
          if (xml === undefined) {
            // arrays could have their xml namespaces defined in their items property, only pull the namespace and
            // prefix in this case from the items.xml as items.xml.name for example has a different meaning inside vs
            // outside of the items property
            if (propertyObj.type === 'array' && propertyObj.items &&
                propertyObj.items.xml && propertyObj.items.xml.namespace !== undefined) {
              var itemsxml = propertyObj.items.xml;
              xml = {};
              xml.namespace = itemsxml.namespace;
              if (itemsxml.prefix !== undefined) {
                xml.prefix = itemsxml.prefix;
              }
            }
          }
          type = propertyObj.type;
          if (type === undefined) {
            if (propertyObj.properties) {
              type = 'object';
            } else if (propertyObj.items) {
              type = 'array';
            }
          }
          var namespace = '';
          var element = property;
          // ignore attributes, we handled them earlier
          var isAttribute = xml && xml.attribute;
          if (!isAttribute) {
            // start of an xml element
            outputContent += '<';
            // not an attribute, check for this property having a namespace, either directly specified in this schema
            // entry, or inherited from a parent entry
            var prefix;
            if (xml || thisInheritedXML) {
              if (xml) {
                prefix = xml.prefix;
              }
              // if a name specified and the property is not an array or is an array with wrapped,
              // use that name instead of the property name
              if (xml && xml.name && (type != 'array' || xml.wrapped)) {
                element = xml.name;
              }
              // determine namespace, either with a prefix, or using the default namespace with no prefix
              // Note on inherited namespaces
              // 1. a xml.namespace == null or '' means NO inheritance
              // 2. if this property has a namespace, set the inherited xml object so it can passed to its children
              // 3. if this property doesn't have a namespace, look in the inherited xml to see if it is there
              var xmlHasNamespace = false;
              var xmlNoNamespaceInheritance = false;
              if (xml) {
                xmlHasNamespace = Object.keys(xml).indexOf('namespace') != -1;
                if (xml.namespace === null || xml.namespace === '') {
                  xmlNoNamespaceInheritance = true;
                }
              }

              if (xml && xmlHasNamespace && !xmlNoNamespaceInheritance) {
                var namespaceInheritanceOption;
                if (policyProperties.options) {
                  namespaceInheritanceOption = policyProperties.options.namespaceInheritance;
                }
                // default option is to enable namespace inheritance.  Only if the option disables inheritance
                // will no inheritance information be provided for child properties.
                if (namespaceInheritanceOption === undefined || namespaceInheritanceOption === true) {
                  // save this namespace info so it can be passed to the children elements
                  thisInheritedXML = {};
                  thisInheritedXML.prefix = xml.prefix;
                  thisInheritedXML.namespace = xml.namespace;
                }

                // save the namespace name and if a prefix is present, change the element name to include the prefix
                namespace = xml.namespace;
                if (prefix && prefix != '') {
                  element = prefix + ':' + element;
                } else {
                  prefix = '';
                }
              } else {
                // check for a namespace in the parent element.  Use the prefix if one is provided, but don't use
                // the namespace so we don't output redundant xmlns:prefix="blah" in the element tag
                if (thisInheritedXML && !xmlNoNamespaceInheritance) {
                  if (thisInheritedXML.useNamespace) {
                    namespace = thisInheritedXML.namespace;
                  }
                  prefix = thisInheritedXML.prefix;
                  if (prefix && prefix != '') {
                    element = prefix + ':' + element;
                  } else {
                    prefix = '';
                  }
                } else {
                  // if you have inherited namespace information and the current namespace says to stop inheritance,
                  // clear the inherited XML information so we don't pick it up on a child.
                  if (thisInheritedXML && xmlNoNamespaceInheritance) {
                    thisInheritedXML = undefined;
                  }
                }
              }
            }

            // objects and arrays need recursion
            switch (type) {
            case 'object':
              // property can be nullable but there was some data in the current element??
              if (propertyObj['x-nullable'] && !nullable) {
                // look at they keys of the object looking for non XML attribute properties
                // if all attributes, this object is nullable afterall
                var objectNullable = isValueAttributesOnly(propertyValue);
                if (objectNullable) {
                  nullable = true;
                }
              }

              // output the element and namespace if present, note the < was output earlier
              outputContent += createOutputElement(element, namespace, prefix, isRootLevel, inlineNamespacesObj, nullable, subTypeObject);

              // objects should have child properties, so navigate into the child input document and recurse
              if (propertyObj.properties) {
                // nullable being true will set the attributeOnly flag on the recursive call.  This means that any attributes to this
                // element will be processed to potentially claim any attributes with default values, but no non-attributes will be
                // processed since there is not data for them.
                outputContent += createOutputContent(outputName, propertyObj, propertyValue, false, thisInheritedXML, nullable, inlineNamespacesObj, outputDefinitionRootPath);
              } else {
                // an object with no properties or nullable, close out the element start tag
                outputContent += '>';
              }

              // add the end tag when done with the object.
              outputContent += '</' + element + '>';
              break;
            case 'array':
              // arrays can be wrapped <items><item>...</item><item>...</item></items> or
              //               unwrapped <item>...</item><item>...</item>
              // initially assume not wrapped
              var isWrapped = false;
              // if array has xml.wrapped of true, the output the current element name as the wrapping element.  Note the wrapping element will not
              // contain the xsi:nil attribute
              if (xml && xml.wrapped) {
                isWrapped = true;
                outputContent += createOutputElement(element, namespace, prefix, isRootLevel, inlineNamespacesObj, false, subTypeObject);
                outputContent += '>';
              }

              // the array items will be what we need to recurse, so make sure we have something in the schema to
              // recurse
              if (propertyObj.items) {
                // get the array schema and resolve allOfs that are found
                // to fully populate the schema
                var item = propertyObj.items;
                if (item.allOf) {
                  resolveAllOf(item, item.allOf);
                }
                type = item.type;
                if (type === undefined) {
                  if (item.properties) {
                    type = 'object';
                  } else if (item.items) {
                    type = 'array';
                  }
                }
                xml = item.xml;
                var childElement = element;

                // if the child with an xml.name, we need to use that name.  Otherwise, inherit the name
                // from the parent array.  This could create for wrapped that the child element would have the same name
                // as the parent if the child doesn't specify a unique name (ie, items for parent, item for child if specified.)
                if (xml && xml.name) {
                  childElement = xml.name;
                  xmlHasNamespace = false;
                  xmlNoNamespaceInheritance = false;
                  if (xml) {
                    xmlHasNamespace = Object.keys(xml).indexOf('namespace') != -1;
                    if (xml.namespace === null || xml.namespace === '') {
                      xmlNoNamespaceInheritance = true;
                    }
                  }

                  if (xml && xmlHasNamespace && !xmlNoNamespaceInheritance) {
                    // default option is to enable namespace inheritance.  Only if the option disables inheritance
                    // will no inheritance information be provided for child properties.
                    var namespaceInheritanceOption;
                    if (policyProperties.options) {
                      namespaceInheritanceOption = policyProperties.options.namespaceInheritance;
                    }
                    if (namespaceInheritanceOption === undefined || namespaceInheritanceOption === true) {
                      // save this namespace info so it can be passed to the children elements
                      thisInheritedXML = {};
                      thisInheritedXML.prefix = xml.prefix;
                      thisInheritedXML.namespace = xml.namespace;
                    }

                    namespace = xml.namespace;
                    if (xml.prefix && xml.prefix != '') {
                      prefix = xml.prefix;
                    } else {
                      prefix = '';
                    }
                  } else {
                    // check for a namespace in the parent element.
                    if (thisInheritedXML && !xmlNoNamespaceInheritance) {
                      namespace = thisInheritedXML.namespace;
                      prefix = thisInheritedXML.prefix;
                      if (!prefix) {
                        prefix = '';
                      }
                    } else {
                      // if you have inherited namespace information and the current namespace says to stop inheritance,
                      // clear the inherited XML information so we don't pick it up on a child.
                      if (thisInheritedXML && xmlNoNamespaceInheritance) {
                        thisInheritedXML = undefined;
                      }
                    }
                  }

                  if (namespace && namespace != '') {
                    if (prefix != '') {
                      childElement = prefix + ':' + childElement;
                    } else {
                      prefix = '';
                    }
                  }
                }

                // xml on the items property?
                if (xml !== undefined) {
                  if (xml.namespace !== undefined) {
                    // if the item namespace/prefix differs from the current inherited namespace/prefix,
                    // update the inheritedXML information and add a boolean to ensure that the xmlns:prefix
                    // is created for child elements that would inherit this namespace.
                    if (!thisInheritedXML || xml.namespace !== thisInheritedXML.namespace || xml.prefix !== thisInheritedXML.prefix) {
                      if (!thisInheritedXML) {
                        thisInheritedXML = {};
                      }
                      thisInheritedXML.namespace = xml.namespace;
                      thisInheritedXML.prefix = xml.prefix;
                      thisInheritedXML.useNamespace = true;
                    }
                  }
                }

                // only process if you have data to process
                if (propertyValue && util.safeTypeOf(propertyValue) == 'array' && propertyValue.length > 0) {
                  // iterate over the json source array to generate each XML element
                  // use cases ... most typical, one item which will be either an object or perhaps another array??
                  for (var i=0; propertyValue && i<propertyValue.length; i++) {
                    var arrayElementNullable = nullable;
                    if (propertyObj['x-nullable'] && !nullable && util.safeTypeOf(propertyValue[i] === 'object')) {
                      // look at they keys of the object looking for non XML attribute properties
                      // if all attributes, this object is nullable afterall
                      var objectNullable = isValueAttributesOnly(propertyValue[i]);
                      if (objectNullable) {
                        arrayElementNullable = true;
                      }
                    }
                    // if wrapped, we need to start the element with <, but if not wrapped, the first time
                    // through, the < has already been output above, so don't output another < in that case
                    if (i != 0 || isWrapped) {
                      outputContent += '<';
                    }

                    // output the child element, no end tag in case the object has child attributes
                    outputContent += createOutputElement(childElement, namespace, prefix, isRootLevel, inlineNamespacesObj, arrayElementNullable, subTypeObject);

                    if (item.type == 'array' || item.type == 'object') {
                      // recurse using the item schema, the ith instance of the input array
                      outputContent += createOutputContent(outputName, item, propertyValue[i], false, thisInheritedXML, arrayElementNullable, inlineNamespacesObj, outputDefinitionRootPath);
                    } else {
                      outputContent += processScalarValue(outputName, item, property.split(), propertyValue[i], propertyValue[i], thisInheritedXML, inlineNamespacesObj, outputDefinitionRootPath);
                    }

                    // close the child element
                    outputContent += '</' + childElement + '>';
                  }
                } else {
                  if (!isWrapped) {
                    // no array data present, but we've already output the <, so create the output start tag and then close it.
                    outputContent += createOutputElement(childElement, namespace, prefix, isRootLevel, inlineNamespacesObj, propertyObj['x-nullable'], subTypeObject);
                    outputContent += '></' + childElement + '>';
                  }
                }
              }

              // if the parent wrapped the child elements, close that element too
              if (isWrapped) {
                outputContent += '</' + element + '>';
              }
              break;

            default:
              // types of strings, numbers, etc, are just leaf values, so create the element, stuff the value in, and close
              // the element
              if (propertyObj['x-nullable'] && !nullable && util.safeTypeOf(propertyValue) === 'object') {
                // look at they keys of the object looking for non XML attribute properties
                // if all attributes, this object is nullable afterall
                var objectNullable = isValueAttributesOnly(propertyValue);
                if (objectNullable) {
                  nullable = true;
                }
              }
              outputContent += createOutputElement(element, namespace, prefix, isRootLevel, inlineNamespacesObj, nullable, subTypeObject);
              var propertySplit = property.split();
              outputContent += processScalarValue(outputName, propertyObj, propertySplit, propertyValue, outputJSONDocument, thisInheritedXML, inlineNamespacesObj, outputDefinitionRootPath);
              outputContent += '</' + element + '>';
              break;
            }
          }
        }
      }
    }
  }
  return outputContent;
}

function isValueAttributesOnly(value) {
  // look at they keys of the object looking for non XML attribute properties
  // if all attributes, this object is nullable afterall
  var isAttributesOnly = true;
  if (util.safeTypeOf(value) === 'object') {
    var objKeys = Object.keys(value);
    for (var i=0; i<objKeys.length; i++) {
      if (!startsWith(objKeys[i], '@')) {
        isAttributesOnly = false;
        break;
      }
    }
  } else {
    isAttributesOnly = false;
  }
  return isAttributesOnly;
}

function getSubTypeSchema(propertyObj, subTypeReferencePath, subTypeObject) {
  var result = false;
  // if the subTypeTable has not been created yet, get all of the swagger definitions on the provided path
  // and build the table of all of the definition names associated with the subtypes
  if (subTypeTable === undefined) {
    subTypeTable = {};
    // the true second argument here will provide just the swagger all of the schema definitions without resolving the
    // $references.  Any schema definition with the x-xsi-type property will be added to the table.  The type will be the
    // key to this table and the value will be the definition reference name
    var definitions = getSwaggerDefinition(subTypeReferencePath, true);
    if (definitions) {
      for (var definition in definitions) {
        if (definitions.hasOwnProperty(definition)) {
          var xsiType = definitions[definition]['x-xsi-type'];
          if (xsiType) {
            subTypeTable[xsiType] = definition;
          }
          xsiType = definitions[definition]['x-xsi-type-uniquename'];
          if (xsiType) {
            subTypeTable[xsiType] = definition;
          }
        }
      }
    }
  }

  // Determine the subtype reference
  var subTypeReference;
  if (subTypeObject.name) {
    // subtype name is actually a direct definiton reference
    if (startsWith(subTypeObject.name, '#/')) {
      subTypeReference = subTypeObject.name;
    } else {
      // if the subtype name is in the table, build the reference definition
      if (subTypeTable[subTypeObject.name]) {
        subTypeReference = subTypeReferencePath + '/' + subTypeTable[subTypeObject.name];
      }
    }
    // if we have a reference definition, then add the swagger definition used by that subType to the current property's schema
    if (subTypeReference) {
      var subTypeSchema = getSwaggerDefinition(subTypeReference);
      if (subTypeSchema) {
        // update the subType name from the swagger definition.  What was provided could be different if a definition
        // or a unique name was provided.
        subTypeObject.name = subTypeSchema['x-xsi-type'];
        result = true;
        var subTypeKeys = Object.keys(subTypeSchema);
        for (var i=0;i<subTypeKeys.length;i++) {
          // copy from the subType schema to the current property object except for xml properties
          if (subTypeKeys[i] !== 'xml') {
            propertyObj[subTypeKeys[i]] = subTypeSchema[subTypeKeys[i]];
          }
        }
      } else {
        if (startsWith(subTypeObject.name, '#/')) {
          delete subTypeObject.name;
        }
      }
    }
  }
  return result;
}

function processScalarValue(outputName, propertyObj, propertySplit, output, outputJSONDocument, thisInheritedXML, inlineNamespacesObj, outputDefinitionRootPath) {
  var outputContent = '';
  // if the scalar has child properties, so navigate into the child input document and recurse,
  // but ONLY for attributes
  if (propertyObj.properties) {
    outputContent += createOutputContent(outputName, propertyObj, output, false, thisInheritedXML, true, inlineNamespacesObj, outputDefinitionRootPath);
  } else {
    outputContent += '>';
  }

  if (output == undefined) {
      output = propertyObj.default;
  }

  if (output != undefined) {
    if (util.safeTypeOf(output) == 'object') {
      // output is an object, perhaps the set rule specified the property in badgerfish form, iea x.y.z.$,
      // so attempt to get that value instead.  This way, specification of both x.y.z and x.y.z.$ is supported
      propertySplit.push('$');
      output = getProperty(propertySplit, outputJSONDocument, false, false);
      if (output != undefined) {
         outputContent += escapeXML(output.toString());
      } else {
        // to support scalar arrays, drop the first property and try again
        output = getProperty(['$'], outputJSONDocument, false, false);
        if (output != undefined) {
           outputContent += escapeXML(output.toString());
        }
      }
    } else {
      outputContent += escapeXML(output.toString());
    }
  }
  return outputContent;
}

function createOutputElement (element, namespace, prefix, isRootLevel, inlineNamespacesObj, nullable, subTypeObject) {

  var outputContent = element;
  // current element has a namespace?
  if (namespace && namespace !== '') {
    // no prefix is a default namespace, so output it regardless of inlineNamespaces
    if (prefix === '') {
      outputContent += ' xmlns=\"' + namespace + '\"';
      // add output for all found named namespaces only if at the root element and not inlining namespaces
      if (isRootLevel && !inlineNamespacesObj.inlineNamespaces) {
        outputContent += outputAllNamespaces(inlineNamespacesObj.namespaceList);
      }
    } else {
      // named namespace, output it if namespaces are output inline as needed
      if (inlineNamespacesObj.inlineNamespaces) {
        outputContent += ' xmlns:' + prefix + '=\"' + namespace + '\"';
      } else {
        // no inlined namespaces, output all found namespaces only at the root element
        if (isRootLevel) {
          outputContent += outputAllNamespaces(inlineNamespacesObj.namespaceList);
        }
        // even if not inlining namespaces, if this namespace was in the duplicate array, it must be inlined.
        if (inlineNamespacesObj.dupNamespaceArray.indexOf(prefix) != -1) {
          outputContent += ' xmlns:' + prefix + '=\"' + namespace + '\"';
        }
      }
    }
  } else {
    // current element doesn't have a namespace, output all found namespaces only
    // if at the root element and not inlining namespaces
    if (isRootLevel && !inlineNamespacesObj.inlineNamespaces) {
      outputContent += outputAllNamespaces(inlineNamespacesObj.namespaceList);
    }
  }

  if (nullable) {
    outputContent += ' ' + xsiPrefix + ':nil="true"';
    if (inlineNamespacesObj.inlineNamespaces) {
      outputContent += ' xmlns:' + xsiPrefix + '="' + xsiNamespaceURL + '"';
    }
  }

  // Handle the xsi:type if one is specified.
  if (subTypeObject.name && !nullable) {
    outputContent += ' ' + xsiPrefix + ':type="';
    // if a type prefix is defined for this element, use it, otherwise, default to the element's prefix
    if (subTypeObject.prefix) {
      outputContent += subTypeObject.prefix + ":";
    } else if (prefix) {
      outputContent += prefix + ":";
    }
    outputContent += subTypeObject.name + '"';

    // output the xsi namespace if inlining namespaces
    if (inlineNamespacesObj.inlineNamespaces) {
      outputContent += ' xmlns:' + xsiPrefix + '="' + xsiNamespaceURL + '"';
    }

    // if the subtype has a namespace
    if (subTypeObject.namespace && subTypeObject.namespace !== '') {
      // output the namespace information if inlining namespaces.  Also, no prefix is a default namespace, so output the namespace information
      // regardless of if we're inlining or not.
      if (inlineNamespacesObj.inlineNamespaces || subTypeObject.prefix === '') {
        // make sure this isn't the same namespace as the element so we don't output the same prefix twice
        if (subTypeObject.prefix !== prefix) {
          outputContent += ' xmlns';
          if (subTypeObject.prefix && subTypeObject.prefix !== '') {
            outputContent += ':' + subTypeObject.prefix;
          }
          outputContent += '="' + subTypeObject.namespace + '"';
        }
      }
    }
  }
  return outputContent;
}

// function will add any allOf property encountered to the current property's object schema.
// If embedded allOfs are found, they will be handled with a recursive call.  The end result
// will be a schema that can be processed as if provided explicitly instead of via allOf.
function resolveAllOf(propertyObj, allOf) {
  for (var i=0; i<allOf.length; i++) {
    if (allOf[i].allOf) {
      resolveAllOf(propertyObj, allOf[i].allOf)
    } else {
      if (allOf[i].xml && propertyObj.xml === undefined) {
        propertyObj.xml = allOf[i].xml;
      }
      if (allOf[i].type && propertyObj.type === undefined) {
        propertyObj.type = allOf[i].type;
      }
      if (allOf[i].properties) {
        if (propertyObj.properties === undefined) {
          propertyObj.properties = {};
        }
        var propertyKeys = Object.keys(allOf[i].properties);
        for (var j=0; j<propertyKeys.length; j++) {
          propertyObj.properties[propertyKeys[j]] = allOf[i].properties[propertyKeys[j]];
        }
      }
      if (allOf[i].required) {
        if (propertyObj.required === undefined) {
          propertyObj.required = [];
        }
        for (var j=0; j<allOf[i].required.length; j++) {
          if (propertyObj.required.indexOf(allOf[i].required[j]) === -1) {
            propertyObj.required.push(allOf[i].required[j]);
          }
        }
      }
    }
  }
}

function getAllNamespaces(schema, outputDocument, isRootLevel, outputDefinitionRootPath, namespaceList, dupNamespaceArray) {
  var type;
  var xml;
  if (util.safeTypeOf(schema.type) == 'array') {
    type = schema.type[0];
  } else {
    type = schema.type;
  }

  // get the child properties (either objects or leaf elements)
  var properties = schema.properties;
  var requiredProperties = schema.required;

  for (var property in properties) {
    if ({}.hasOwnProperty.call(properties, property)) {
      var propertyObj = properties[property];

      // get the current property value which is needed to potentially find the x-ibm-discriminator mapped value.  If
      // this value is found, the schema associated with that value must be added to the current schema so that new schema
      // can be searched for additional namespaces.
      var propertyValue = getProperty(property.split(), outputDocument, false, false);

      // policy option includeEmptyXMLElements default is to include, so if not provided or if provided and true is specified
      // any empty element is included.  If provided and false, then only elements with a value or empty elements that are required
      // are processed.
      var includeEmptyXMLElementsOption;
      if (policyProperties.options) {
        includeEmptyXMLElementsOption = policyProperties.options.includeEmptyXMLElements;
      }
      var isRequired = requiredProperties && requiredProperties.indexOf(property) !== -1;

      // if this property has a discriminator, we need to get the schema associated with this property and add the subtype
      // properties to this schema dynamically
      var subTypeObject = {};
      if (propertyObj['x-ibm-discriminator'] === true) {
        // We're going to be modifying property object in this case, so create a deep copy of this object so changes are isolated to this object
        // and not other referenced objects
        propertyObj = JSON.parse(JSON.stringify(propertyObj));
        // the x-ibm-discriminator property should have been mapped to determine the subtype to use
        subTypeObject.name = getProperty(['x-ibm-discriminator', '$'], propertyValue, false, false);
        // getSubTypeSchema will modify the property object to include the subtype schema
        if (subTypeObject.name === undefined || !getSubTypeSchema(propertyObj, outputDefinitionRootPath, subTypeObject)) {
          var errorMessage;
          if (subTypeObject.name) {
            errorMessage = logPrefix + 'x-ibm-discriminator schema definition not found: ' + outputDefinitionRootPath + '/' + subTypeObject.name;
          } else {
            errorMessage = logPrefix + 'x-ibm-discriminator not provided for element: ' + property;
          }
          dbglog.error(errorMessage);
        }
      }

      // only traverse the schema if we plan to output an element, which will be done if the element has a value,
      // this is the root element, empty xml elements will be output, or if not to be output yet the element is required.
      if (propertyValue !== undefined || isRootLevel || includeEmptyXMLElementsOption === undefined || includeEmptyXMLElementsOption === true ||
          isRequired) {

        if (propertyObj.allOf) {
          resolveAllOf(propertyObj, propertyObj.allOf);
        }

        xml = propertyObj.xml;
        type = propertyObj.type;

        // add the current element's xml information to the namespace list
        if (xml && xml.prefix !== 'xml') {
          updateNamespaceObject(xml, namespaceList, dupNamespaceArray);
        }

        // if the element is nullable or has an xsi-type, add the xsi prefix/namespace to the namespace list
        if (propertyObj['x-nullable'] || propertyObj['x-xsi-type']) {
          updateNamespaceObject({"prefix": xsiPrefix, "namespace": xsiNamespaceURL}, namespaceList, dupNamespaceArray);
        }

        // if there is xsi-type xml information for this element, add it to the namespace list
        if (propertyObj['x-xsi-type-xml']) {
          updateNamespaceObject(propertyObj['x-xsi-type-xml'], namespaceList, dupNamespaceArray);
        }

        // objects and arrays need recursion
        switch (type) {
        case 'array':
          // the array items will be what we need to recurse, so make sure we have something in the schema to recurse
          if (propertyObj.items) {
            // get the array schema and resolve any allOfs that are found
            // to fully populate the schema
            var item = propertyObj.items;
            if (item.allOf) {
              resolveAllOf(item, item.allOf);
            }

            // add any array specific xml information to the namespace list
            xml = item.xml;
            updateNamespaceObject(xml, namespaceList, dupNamespaceArray);

            // just recurse once passing the first input array value or if that doesn't exist an empty object,
            // but we do need to recurse in case an array element has a subtype as we could be outputting empty
            // elements so we need to search the entire schema regardless.
            var arrayValue;
            if (propertyValue && util.safeTypeOf(propertyValue) == 'array' && propertyValue.length > 0) {
              arrayValue = propertyValue[0];
            } else {
              arrayValue = {};
            }
            getAllNamespaces(item, arrayValue, false, outputDefinitionRootPath, namespaceList, dupNamespaceArray);
          }
          break;
        default:
          // objects should have child properties, as will scalar element with attributes,
          // so navigate into the child input document and recurse
          if (propertyObj.properties) {
            getAllNamespaces(propertyObj, propertyValue, false, outputDefinitionRootPath, namespaceList, dupNamespaceArray);
          }
          break;

        }
      }
    }
  }
}

function updateNamespaceObject(xml, namespaceList, dupNamespaceArray) {
  // for adding to the namespace list, you must have a namespace and a prefix.  Default namespaces
  // that have no prefix are only defined where they are first used and are not included in this list.
  if (xml && xml.namespace && xml.prefix) {
    // not in the namespace array, then add it
    if (Object.keys(namespaceList).indexOf(xml.prefix) === -1) {
      namespaceList[xml.prefix] = xml.namespace;
    } else {
      // if in the namespace array already but with a different prefix, add the prefix to a list that
      // indicates not to use it on the root element but on the element where defined.
      if (namespaceList[xml.prefix] != xml.namespace) {
        dupNamespaceArray.push(xml.prefix);
        dbglog.warn(logPrefix + "inlineNamespaces is disabled, but prefix \"" + xml.prefix +
                    "\" was encountered with multiple namespace uris.  Namespaces with this prefix will be output inline.");
      }
    }
  }
}

function outputAllNamespaces(namespaceList) {
  var outputContent = '';
  for (var prefix in namespaceList) {
    if (namespaceList.hasOwnProperty(prefix)) {
      outputContent += ' xmlns:' + prefix + '=\"' + namespaceList[prefix] + '\"';
    }
  }
  return outputContent;
}

function createInputVector(policyProperties, inputContentVector) {
  // for supporting multiple inputs ...
  // This adds an object with a name based on the input name and the input object (could be a full or subset of the input)
  var inputNames = Object.keys(policyProperties.inputs);
  for (var i=0; i<inputNames.length; i++) {
    var inputName = inputNames[i];
    var variable = policyProperties.inputs[inputName].variable;
    if (variable) {
      // if we have a request.parameters variable with a : in the varname then change to __3A__
      // as this is how it has been stored in the context due to issues with XML treating the
      // varname as having a namespace and failing to store the variable
      if (variable.indexOf("request.parameters.")==0 && variable.indexOf(":")>=0) {
          variable = variable.replace(/:/g, "__3A__");
      }
      var data = undefined;
      var variableSplit = [];

      // default content type will be the content of the input definition or json if that isn't present
      var contenttype = policyProperties.inputs[inputName].content;
      if (!contenttype) {
        contenttype = "application/json";
      }

      if (util.safeTypeOf(variable) == 'string') {
        variableSplit = customSplit(variable);
        var variableName = variableSplit[0];
        if (variableSplit[1]) {
          variableName += '.' + variableSplit[1];
        }

        var headername = undefined;
        var headers = undefined;
        var inputContentType = undefined;
        // get the content type header name if the input is a body
        if (variableSplit[1] == 'body') {
          headers = apim.getvariable(variableSplit[0] + ".headers");
          if (headers) {
            // get the case sensitive name of the content-type header to use in the lookup
            // looking for a comma on either side will elimating matching on X-Content-Type or Content-Type-blah
            // non global regexp matches will return an array where item[0] being the entire string matched, and
            // item[1] would have the matched string within the parenthesis, null if no match.
            var regex = /,(content-type),/i;
            var headerkeys = ',' + Object.keys(headers).toString() + ',';
            var headername = headerkeys.match(regex);
            if (headername && headername[1]) {
              // match will have the starting and ending commas, so lookup having sliced off the first/last character
              inputContentType = headers[headername[1]];
            }
          }
        }

        try {
          data = apim.getvariable(variableName);
          // the default content type is application/json, but if this is a context body,
          // update it with the content type header if in the context headers
          if (variableSplit[1] == "body" && inputContentType) {
            contenttype = inputContentType;
          }

          // if a nodelist was returned and the type is 13 (BLOB/Binary Node), do our best to determine
          // the type of data and parse it into either JSON / XML
          if (data.item && data.length > 0 && data.item(0).nodeType == 13) {
            data = data.item(0).toBuffer().toString();
            var char = data.slice(0, 1);
            switch (char) {
            // first char JSON related, then attempt to parse as JSON
            case '{':
            case '[':
              data = JSON.parse(data);
              contenttype = 'application/json';
              break;

            // first char XML related, then attempt to parse as XML
            case '<':
              data = XML.parse(data);
              contenttype = 'application/xml';
              break;
            // don't know what to do, just going to have to skip this input.
            default:
              data = undefined;
              contenttype = undefined;
              break;
            }
            dbglog.warn(logPrefix + "input: \"" + inputName + "\" input has an unknown content type \"" +
                        (inputContentType ? inputContentType: "Not Provided") + "\", data converted to \"" + contenttype + "\".");

            // if this was a context body, update the content type to help future policies that could be using this context
            if (variableSplit[1] == 'body' && contenttype) {
              if (!(headername && headername[1])) {
                headername = ['', 'content-type'];
              }
              apim.setvariable(variableSplit[0] + '.headers.' + headername[1], contenttype, 'set');
            }
          }
        } catch (err) {
          // we tried but the parse had to fail
          data = undefined;
          dbglog.error(logPrefix + "input: \"" + inputName + "\" input has an unknown content type " + (inputContentType ? inputContentType: "Not Provided") + " and could not be converted to XML or JSON.");
        }
      }
      if (data !== undefined) {
        // TODO: TEMPORARY v6 code to parse Buffers that should be returned as either a JSON or XML object
        // remove when https://github.ibm.com/apimesh/reboot-defects/issues/426 is fixed
        if (!isV5 && contenttype !== undefined && util.safeTypeOf(data) === 'uint') {
          // empty posts provide a empty buffer, so make sure there is data to parse.
          if (data.length > 0) {
            data = data.toString();
            try {
              if (apim.isXML(contenttype)) {
                data = XML.parse(data);
              } else {
                data = JSON.parse(data);
              }
            } catch (error) {
              // parse errors means the content type didn't match the actual data.  The data is not
              // usable.
              data = undefined;
            }
          }
        }
        // end of TEMPORARY CODE

        var xmldata;
        // Check the input content type to determine if the schema is xml, and if so
        // need to call the xml to json conversion and place that result in variable data.
        var isXML = apim.isXML(contenttype);
        if (isXML) {
          xmldata = data;
          var bfJson;
          var outputJSON = {};
          // XML Content Type, the data returned from getvariable better be a nodelist or document
          switch (util.safeTypeOf(data)) {
          case 'nodelist':
            bfJson = converter.toJSON('badgerfish', data.item(0));
            convertXMLtoJSON(outputJSON, bfJson);
            data = outputJSON;
            break;
          case 'document':
            bfJson = converter.toJSON('badgerfish', data);
            convertXMLtoJSON(outputJSON, bfJson);
            data = outputJSON;
            break;
          default:
            data = {};
            dbglog.error(logPrefix + "Input data: \"" + inputName + "\" is XML Content Type but read data is type \"" + util.safeTypeOf(data) + "\".");
            break;
          }
        }

        // note we handled request.body above, so need to remove those from the split array.
        variableSplit.shift();
        variableSplit.shift();

        // If we have request.parameters then decode all of the parameters.  request.parameters should be an object
        // but in the case where there are no parameters provided, an empty string is what is returned by apim.getvariable.
        // In this case you have no parameters.
        if (variable.indexOf("request.parameters")===0) {
          // TODO: for v6, add TEMPORARY code to provide this in the object schema that is expected
          // remove when https://github.ibm.com/apimesh/reboot-defects/issues/430 is fixed
          if (!isV5) {
            /*  V6 request.parameters schema
                {
                  "parameter": {
                      "locations": [
                          "query"
                      ],
                      "values": [
                          "test123"
                      ]
                  },
                  "Host": {
                      "locations": [
                          "header"
                      ],
                      "values": [
                          "192.168.0.106:4001"
                      ]
                  }
                }

                We need to transform this to a v5 request.parameters schema
                {
                  "parameter" : "test123"
                }
             */
            var v6ParameterKeys = Object.keys(data);
            var v5Parameters = {};
            for (var j=0; j<v6ParameterKeys.length; j++) {
              var parameter = v6ParameterKeys[j];
              var valueIndex = data[parameter].locations.indexOf("query");
              if (valueIndex === -1) {
                valueIndex = data[parameter].locations.indexOf("formData");
                if (valueIndex === -1) {
                  valueIndex = data[parameter].locations.indexOf("path");
                }
              }
              if (valueIndex !== -1) {
                v5Parameters[parameter] = data[parameter].values[valueIndex];
              }
            }
            data = v5Parameters;
          }
          // end of TEMPORARY CODE

          if (util.safeTypeOf(data) === 'object') {
            data = decodeRequestParameters(data);
          } else if (data === '') {
            data = undefined;
          }
        }

        // get the "subset" of the data, ie, if request.body.customer, then pull just the customer data from the data
        var property = getProperty(variableSplit, data, false, true);
        if (property !== undefined) {
          // set the named input data into the vector
          inputContentVector[inputName] = property;
          if (debug) {
              analyticsData = apim.addAnalyticsInputToData(analyticsData, apim.generateInputDataForAnalytics(isXML ? xmldata: property, undefined, contenttype, false), inputName);
          }
        } else {
            if (debug) {
                analyticsData = apim.addAnalyticsInputToData(analyticsData, apim.generateInputDataForAnalytics('undefined', undefined, contenttype, false), inputName);
            }
        }
      } else {
        dbglog.error(logPrefix + "Missing input data: \"" + inputName + "\".");
        if (debug) {
            analyticsData = apim.addAnalyticsInputToData(analyticsData, apim.generateInputDataForAnalytics('undefined', undefined, contenttype, false), inputName);
        }
      }
    } else {
      dbglog.error(logPrefix + "input: \"" + inputName + "\". Has no variable definition...");
      if (debug) {
          analyticsData = apim.addAnalyticsInputToData(analyticsData, apim.generateInputDataForAnalytics('undefined', undefined, contenttype, false), inputName);
      }
    }

  }
}

function createInitialOutputFromSchema(schema, outputVariable) {
  var type;
  if (util.safeTypeOf(schema.type) == 'array') {
    type = schema.type[0];
  } else {
    type = schema.type;
  }

  var obj;
  switch (type) {
  case 'array':
    obj = [];
    break;
  case 'object':
    obj = {};
    break;
  case 'string':
    var outputSplit = outputVariable.split('.');
    if (outputSplit[1] === 'body') {
      obj = {};
    } else {
      obj = '';
    }
    break;
  }

  if (obj !== undefined) {
    // put a placeholder for the root context (message.body for example) into the output object
    setOutput(outputVariable, obj, outputJSONContent, false, false);

    // only attempt to create initial output from required fields of an object or an array (which can contain an object)
    if (type == 'array' || type == 'object') {
      var outputSplit = customSplit(outputVariable);
      var thisOutputJSONContent = getProperty(outputSplit, outputJSONContent, false, false);
      traverseSchema(schema, thisOutputJSONContent);
    }
  }
}

function traverseSchema(schema, outputDoc) {
  var type;
  if (util.safeTypeOf(schema.type) == 'array') {
    type = schema.type[0];
  } else {
    type = schema.type;
  }

  switch (type) {
  case 'object':
  case 'array':
    createRequiredProperties(schema, outputDoc);
    break;

  default:
    if( schema.required !== undefined) {
      createRequiredProperties(schema, outputDoc);
    }
    break;
  }
}

function createRequiredProperties(schema, outputDoc) {
  var required = schema.required;
  for (var i=0; required && i<required.length; i++) {
    var propName = required[i];
    var type;
    if (util.safeTypeOf(schema.type) == 'array') {
      type = schema.type[0];
    } else {
      type = schema.type;
    }

    var propSchema;
    switch(type) {
    case 'object':
      propSchema = schema.properties[propName];
      break;
    case 'array':
      propSchema = schema.items[propName];
      break;
    default:
      // primitives can have attributes
      if( schema.properties[propName] !== undefined) {
          propSchema = schema.properties[propName];
      }
    }

    // ensure the schema is found for the require item before you try to do anything with it.
    if (propSchema) {
      // get his property's XML metadata (if present) has the attribute property enabled.  If so, the
      // property name will have an @ prefix.
      var schemaProperties = schema.properties[propName];
      if (schemaProperties && schemaProperties.xml && schemaProperties.xml.attribute) {
        propName = '@' + propName;
      }

      var propType;
      if (util.safeTypeOf(propSchema.type) == 'array') {
        propType = propSchema.type[0];
      } else {
        propType = propSchema.type;
      }

      var isPrimitive = true;
      var defaultVal;

        // set the standard default value for each type

      switch (propType) {

      case 'object':
        defaultVal = {};
        isPrimitive = false;
        break;

      case 'array':
        defaultVal = [];
        isPrimitive = false;
        break;

      case 'string':
        defaultVal = '';
        break;

      case 'number':
      case 'integer':
        defaultVal = 0;
        break;

      case 'boolean':
        defaultVal = false;
        break;

      case 'null':
        defaultVal = null;
        break;
      }

        // use the schema default if present

      if (defaultVal !== undefined && propSchema.default) {
        defaultVal = propSchema.default;
      }

        // set output[propName] to defaultVal

      var traverse = !isPrimitive;
      if( isPrimitive && propSchema.required !== undefined) {
            // a primitive with required attributes
          outputDoc[propName] = {};
          outputDoc[propName]["$"] = defaultVal;
          traverse = true;
      } else if( defaultVal !== undefined) {

            // put default value in output property
            // (if it was set)
        outputDoc[propName] = defaultVal;
      }

        // traverse if non-primitive OR has required attributes

      if( traverse) {
        traverseSchema(propSchema, outputDoc[propName]);
      }
    }
  }
}

/*
////////////////////////////////////////////////////////////////////////////////////

*/
function ProcessMappingRules(rules, inputDocument, outputDocument, isRootLevel, isOutputXML) {
  var returnedResult = undefined;
  for (var k in rules) {
    if ({}.hasOwnProperty.call(rules, k)) {
      // so send the rule line to a function that parses the action in question
      returnedResult = ParseRule(rules[k], inputDocument, outputDocument, isRootLevel, isOutputXML);
    }
  }
  return returnedResult;
}

////////////////////////////////////////////////////////////////////////////////////

function ParseRule(aRule, inputDocument, outputDocument, isRootLevel, isOutputXML) {

  var returnedResult = undefined;
  // if the first key is a set or create, then that will be the action, otherwise, look for a
  // set or create being at any position of the object, with set having precedence over create
  // if in an erroneous situation that both occur in the same action.
  var ruleKey = Object.keys(aRule)[0];
  if (ruleKey !== 'set' && ruleKey !== 'create') {
    if(aRule.hasOwnProperty('set')) {
      ruleKey = 'set';
    } else if(aRule.hasOwnProperty('create')) {
      ruleKey = 'create';
    }
  }
  var ruleValue;
  try {
    switch (ruleKey) {
    case 'set':
      ruleValue = aRule.set;
      if (ruleValue != null) {
        if (verbose) dbglog.debug(logPrefix + "Parsing set action " + ruleValue);
          returnedResult = ParseSetAction(aRule, inputDocument, outputDocument, isRootLevel, isOutputXML);
      } else {
        dbglog.error(logPrefix + "null action value for 'set'");
      }
      break;
    case 'create':
      ruleValue = aRule.create;
      if (ruleValue != null) {
        if (verbose) dbglog.debug(logPrefix + "Parsing create action" + ruleValue);
          returnedResult = ParseCreateAction(aRule, inputDocument, outputDocument, isRootLevel, isOutputXML);
      } else {
        dbglog.error(logPrefix + "null action value for 'create'");
      }
      break;
    default:
        dbglog.error(logPrefix + "no 'set' or 'create' action found in rule " + aRule);
        break;
    }
  } catch (err) {
    dbglog.error(logPrefix + 'rule error: ' + err.errorMessage + ', rule=' + JSON.stringify(aRule));
  }
  return returnedResult;
}

////////////////////////////////////////////////////////////////////////////////////
/*
we parse the set actions here only
*/

function ParseSetAction(aSetRule, inputDocument, outputDocument, isRootLevel, isOutputXML) {

  var returnedResult = undefined;
  var valueParam = aSetRule.value;
  var outputSplit = customSplit(aSetRule.set);
  if (isRootLevel) {
    var outputContentType = policyProperties.outputs[outputSplit[0]].content;
    if (outputContentType) {
      isOutputXML = apim.isXML(outputContentType);
    }
  }

  // get the 'from' -- e.g. from can be 'customer.firstname' or an array of these types of strings.
  var rlfrom = aSetRule.from;
  var rlforeach = aSetRule.foreach;
  var actionDefault = aSetRule.default;
  var foreachDocument;
  var searchDocument = [];
  var isforeachDocument = [];
  var fromArray = [];
  var foreachsplit = [];
  if (rlforeach) {
    foreachsplit = customSplit(rlforeach.toString());
    // foreachDocument is by nature an array
    foreachDocument = getProperty(foreachsplit, inputDocument, isRootLevel, true);
    if (!foreachDocument) {
      foreachDocument = {};
    }
  }

  // normalize the from parameter to be an array of zero length if no from is provided,
  // or an array of one if only a single from is provided via a string instead of an array.
  if (!rlfrom) {
    rlfrom = [];
  } else if (util.safeTypeOf(rlfrom) == 'string') {
    rlfrom = new Array(rlfrom);
  }

  // normalize the value string to take any parameter not specified as positional,
  // ie, $(input.someproperty) and make it positional $(n) where n is an integer
  // position within the from array.  If the non-integer parameter is already in
  // already in the from array, just the parameter substitution will be done, but
  // if not, the parameter will be added to the from array which will then dictate
  // the position used.
  if (valueParam) {
    valueParam = normalizeValueParam(aSetRule, valueParam, rlfrom, true);
  }

  // if there is a from array, then get the values in the input document and store them into an array,
  // first thing, we need to determine for each from parameter, which document is to be searched for
  if (rlfrom.length > 0) {
    var outputValue = null;
    var attrArray= [];
    // from has been normalized to be an array, ie ["input.x.y.z", "input.a.b.c"]
    for (var i=0; i<rlfrom.length; i++) {
      // if the from document is in the for each array specification, the for each document will contain the data
      // the for-each variable portion of the from will be removed so only the remaining portion of the from will be
      // used to find the actual data.
      if (rlforeach && startsWith(rlfrom[i], rlforeach)) {
        var attr = substringAfter(rlfrom[i], rlforeach + '.');
        if (attr) {
          attrArray[i] = customSplit(attr);
        } else {
          attrArray[i] = [];
        }
        searchDocument[i] = foreachDocument;
        isforeachDocument[i] = true;
      } else {
        // not a for each document, so use the entire from string in the search.  The document to search,
        // inputDocument is really a collection of documents keyed by the first portion of the from string,
        // for example, input1.customer.address, the input document will have an object named input1 which will
        // contain the object of input1, hopefully customer.address is in that document.
        attrArray[i] = customSplit(rlfrom[i].toString());
        searchDocument[i] = [];
        // if a foreachDocument, then the number of rows of that document determine the number of search
        // documents we need to reference.
        if (foreachDocument) {
          for (var j=0; j < foreachDocument.length; j++) {
            searchDocument[i][j] = inputDocument;
          }
        } else {
          // no for each document, so only one row for the search document
          searchDocument[i][0] = inputDocument;
        }
        isforeachDocument[i] = false;
      }
    }

    // Populate a 2 dimensional array that contains the values of the from property foreach row.
    // No foreach means only 1 row in the 2 dimensional array
    // The from may contain values outside of the foreach which means their value is based on the inputDocument and is the
    // same for each row.

    var fromRows = 1;
    if (foreachDocument) {
      fromRows = foreachDocument.length;
    }
    // no for each, so just base fromArray off of any from that is provided
    for (var i=0; i<fromRows; i++) {  // for each row
      fromArray[i] = [];       // initial the row data as an empty array
      for (var j=0; j<attrArray.length; j++) { // for each from attribute
        fromArray[i][j] = getProperty(attrArray[j], searchDocument[j][i], isRootLevel && !isforeachDocument[j], true);
        // if the result is an object, perhaps the UI didn't provide a $ to get an xml value, so try one level deeper
        // if this input is truly json, then the from didn't provide enough information and an undefined should be returned
        // anyway.
        if (util.safeTypeOf(fromArray[i][j]) == 'object') {
          var xmlValue = getProperty(['$'], fromArray[i][j], false, true);
          if (xmlValue) {
            fromArray[i][j] = xmlValue;
          } else if (!isOutputXML && isValueAttributesOnly(fromArray[i][j])) {
            // the property has an object value, but the output is NOT XML and yet every property
            // in that object starts with an @. In this case, the assumption is this is an XML input
            // that has badgerfish attribute notation, so ignore this object.  Note that this test
            // only holds true for leaf to leaf mappings where the object would contain a "$" property
            // for the value, handled above, or 1..n attribute properties. If a higher level object mapping
            // were done, the child objects would fail the isValueAttribueOnly test and the entire
            // badgerfish structure would be used as input.  Handling that use case is the subject of a future
            // enhancement request.
            fromArray[i][j] = undefined;
          }
        } else if (fromArray[i][j] == undefined) {
          var xmlValue = getProperty(['$'], searchDocument[j][i], false, true);
          if (xmlValue) {
            fromArray[i][j] = xmlValue;
          }
        }
      }
    }
  } else {
    // no from, so no fromArray that parseValueString will need to iterate over.
    fromArray[0] = [];
  }

  // we have a 'value' to work with ..IF we had a fromArray,
  // then we need to apply the value rule to the fromArray
  var reteval = undefined;
  if (valueParam) {
    // parseValueString will provide return an updated value, with any $(position) being replaced with the
    // proper evaluated value.
    reteval = parseValueString(aSetRule, valueParam, fromArray, rlfrom);

    // parsedValueString evaluation was undefined, use the default (if any provided)
    if (reteval == undefined) {
      reteval = actionDefault;
      if (reteval == undefined) {
        dbglog.error(console.ID.DPUSR_MSG10, logPrefix + 'set action ' + aSetRule.set + ': invalid value expression and no default configured. ' + JSON.stringify(aSetRule));
      }
    }

    // add to the output if we have a value
    if (reteval != undefined) {
      returnedResult = setOutput(aSetRule.set, reteval, outputDocument, isRootLevel, isOutputXML);
    }
  } else {
    // value param handled above, otherwise, see if we return the from or have an embedded set of actions
    if (aSetRule.actions) {
      // we're going to recurse with actions, first need to make sure the current set is created with an empty object,
      var newObject = {};
      // then process the embedded actions
      // original set: output.customer for example
      var attr = customSplit(rlfrom[0]);
      var retfromeval = getProperty(attr, inputDocument, isRootLevel, true);
      // root level will have the first outputSplit array item as the name of the output.
      // this will be removed and the associated variable added to the beginning of the array
      if (isRootLevel) {
        updateOutputSplit(outputSplit);
      }
      if (verbose) dbglog.debug(logPrefix + "parsing set action, retfromeval: ", retfromeval);
      returnedResult = ProcessMappingRules(aSetRule.actions, retfromeval, newObject, false, isOutputXML); // recursing, not root level
      if (returnedResult) {
        newObject = returnedResult;
      }
      returnedResult = setOutput(aSetRule.set, newObject, outputDocument, isRootLevel, isOutputXML);
    } else {
      // no embedded actions, no value string, so set based on the first from element
      // TODO: perhaps return a fromArray[0], resulting in a comma separated string if more than one from, but it will
      // change the datatype if fromArray[0][0] is a number to a string, would that be an issue?
      // fromValue was undefined, use the default (if any provided)
      if (fromArray[0][0] == undefined) {
        fromArray[0][0] = actionDefault;
        if (fromArray[0][0] == undefined) {
          dbglog.error( console.ID.DPUSR_MSG10, logPrefix + 'set action ' + aSetRule.set + ': ' + rlfrom[0] + ' is undefined and has no default configured.');
        }
      }

      // add to the output if we have a value
      if (fromArray[0][0] != undefined) {
        returnedResult = setOutput(aSetRule.set, fromArray[0][0], outputDocument, isRootLevel, isOutputXML);
      }
    }
  }
  return returnedResult;
}

function normalizeValueParam(aSetRule, valueParam, fromArray, toPositional) {
  if (util.safeTypeOf(valueParam) == 'string') {
    // For toPositional = true,
    // Handle the following use case ... value has from items instead of a from array
    //{
    //   "set": "out.orderTotal",
    //   "foreach": "input2.items",
    //   "value": "$(.) + ($(input2.items.price) * $(input2.items.quantity))"
    // },
    // For toPositional = false, make the valueString transformation go the other way from $(n) to $(some x.y.z string)
    var regex = /(\$\([a-zA-Z\-\.\_0-9\+]+\))/g;
    valueParam = valueParam.replace(regex, function(strMatch) {
      var varname = strMatch.substring(2,strMatch.length-1); // remove $()
      var matchResult;
      var index = varname.match(/^\d+$/g);
      // a period is the same as the $(0) accumulator
      if (varname == '.') {
        if (toPositional) {
          matchResult = '$(0)';
        } else {
          matchResult = strMatch;
        }
      } else if (index) {
        if (index <= fromArray.length) {
          if (toPositional) {
            // changing to positional, whole number should not be replaced
            matchResult = strMatch;
          } else {
            // not positional, index 0 is the dot notation, otherwise get the name from the array
            if (index == 0) {
              matchResult = '$(.)';
            } else {
              matchResult = fromArray[index - 1];
            }
          }
        } else {
            matchResult = strMatch;
            dbglog.error(logPrefix + 'set action ' + aSetRule.set + ': parameter index ' + index + ' is out of range');
        }
      } else {
        // match has to be using alpha chars
        if (toPositional) {
          // changing to positional, look for it in the existing from array
          var i=0;
          for (i=0; i< fromArray.length; i++) {
            if (fromArray[i] == varname) {
              break;
            }
          }
          var position = i + 1;
          matchResult = '$(' + position + ')';
          // if the variable wasn't found in the from array, tack it on to the end.
          if (i == fromArray.length) {
            fromArray[i] = varname;
          }
        } else {
          // not changing to positional, and yet had a non index, so set the return to what was received.
          matchResult = strMatch;
        }
      }
      return matchResult;
    });
  }
  return valueParam;
}

////////////////////////////////////////////////////////////////////////////////////

function parseValueString(aSetRule, value, fromArray, fromArrayNames) {

  var result;
  if (util.safeTypeOf(value) == 'string') {
    result = 0;
    for (var i=0; i<fromArray.length; i++) {
      var valueStr = value;
      //valueStr = "$(0) + ($(1) * $(2).toUpperCase()) + $(3)";
      valueStr = valueStr.replace(/\$\(\d+\)/g, function(strMatch) {
      // each string matching the pcre will be replaced by what this anonymous function returns.
      // so $(n) will be replaced by the appropriate variable that contains that parameter.
      // the result of all of the matches will be a regular expression that will be evaluated.
        var index = strMatch.match(/\d+/g);
        var matchResult;
        // from array is two dimensional
        // first dimension: number of rows to iterate
        // second dimension: number of from properties
        // index of zero is for the subtotal
        if (index == 0) {
          matchResult = '__result__';
        } else if (index <= fromArray[0].length) {
          try {
            // if the value in the from Array is undefined, return undefined so any failure of
            // the overall expression would show undefined, not fromArray[x][y]
            var testStr = '__fromArray__[' + i.toString() + '][' + (index-1).toString() + ']';
            var test = fromArray[i][index-1];
            if (util.safeTypeOf(test) != 'undefined') {
              matchResult = testStr;
            } else {
              matchResult = undefined;
              dbglog.error(logPrefix + 'set action ' + aSetRule.set + ': valueString expression: ' + normalizeValueParam(aSetRule, value, fromArrayNames, false) + ': ' + fromArrayNames[index-1] + ' is undefined');
            }
          } catch (err) {
            matchResult = undefined;
            dbglog.error(logPrefix + 'set action ' + aSetRule.set + ': valueString expression: ' + normalizeValueParam(aSetRule, value, fromArrayNames, false) + ': ' + fromArrayNames[index-1] + ' error:' + err.errorMessage);
          }
        } else {
          dbglog.error(logPrefix + 'set action ' + aSetRule.set + ': valueString expression: ' + normalizeValueParam(aSetRule, value, fromArrayNames, false) + ': ' + 'parameter index ' + index + ' is out of range');
        }
        return matchResult;
      });
      try {
        // evaluate the overall value string
        result = evalSafe(valueStr, fromArray, result);
        if (util.safeTypeOf(result) == 'number' &&
            !isFinite(result)) {
          dbglog.error(logPrefix + 'set action ' + aSetRule.set + ': valueString expression: ' + normalizeValueParam(aSetRule, value, fromArrayNames, false) + ' results in ' + result);
          result = undefined;
        }
      } catch (err) {
        result = undefined;
        dbglog.error(logPrefix + 'set action ' + aSetRule.set + ': invalid valueString expression: ' + normalizeValueParam(aSetRule, value, fromArrayNames, false));
        break;
      }
    }
  } else {
    result = value;
  }
  if (verbose) dbglog.debug(logPrefix + 'set action ' + aSetRule.set + ": valueString expression: " + normalizeValueParam(aSetRule, value, fromArrayNames, false) + " parseValueString result: " , result);
  return result;
}

////////////////////////////////////////////////////////////////////////////////////

function ParseCreateAction(aCreateRule, inputDocument, outputDocument, isRootLevel, isOutputXML) {

  var returnedResult = undefined;
  var outputSplit = customSplit(aCreateRule.create);

  // if this is a root level action, determine if the content type of this output document is XML.
  if (isRootLevel) {
    var outputContentType = policyProperties.outputs[outputSplit[0]].content;
    if (outputContentType) {
      isOutputXML = apim.isXML(outputContentType);
    }
  }

  // from the specification:
  // foreach determines how many times to iterate, no or invalid foreach, one time
  // from will determine where you get your data
  var rlforeach = aCreateRule.foreach;
  var rlfrom = aCreateRule.from;
  var rlactions = aCreateRule.actions;

  if (rlactions) {   // we have embedded actions to parse
    var attr = undefined;
    var fromObject = undefined;
    // the from property is optional.  If specified, get it from the input document
    if (rlfrom) {
      attr = customSplit(rlfrom.toString());
      fromObject = getProperty(attr, inputDocument, isRootLevel, true);
      if (fromObject === undefined) {
        dbglog.warn(logPrefix + 'array ' + rlfrom + ' not found in input document.');
      }
    } else {
      // no from specified on the non root call, your input is the input document.
      if (!isRootLevel) {
        fromObject = inputDocument;
      }
    }

    // if the foreach property is not specified, only one new output object will be created.  If specified
    // get the foreach property's data from the input document and if found the number of new objects created
    // will be based on the size of the for each array.  If the foreach object isn't found or is not an array,
    // then it will be ignored.
    var forEachObject = undefined;
    var numberOfNewElements = 1;
    if (rlforeach) {
      attr = customSplit(rlforeach.toString());
      var forEachObject = getProperty(attr, inputDocument, isRootLevel, true);
      // get the number of new array elements to process based on the for each object requested.  If the foreach
      // specification is undefined or not an array, throw an error.
      if (forEachObject && util.safeTypeOf(forEachObject) == 'array') {
        numberOfNewElements = forEachObject.length;
      } else {
        dbglog.error(logPrefix + 'create action ' + aCreateRule.create + ': foreach array ' + rlforeach + ' will be ignored.  It is not found in input or is not an array');
        rlforeach = undefined;
      }
    }

    // Make an array of the from object if not already an array as the itertion is over array elements.
    if (util.safeTypeOf(fromObject) != 'array') {
      if (util.safeTypeOf(fromObject) == 'object') {
        fromObject = new Array(fromObject);
      } else {
        var temp = fromObject;
        fromObject = new Array();
        fromObject[0] = temp;
      }
    } else if (!rlforeach) {
      // from is an array without a foreach
      // TODO: Since no foreach means only one new output element, should the entire array be placed in a one element array?
      //       otherwise, only the first input array element will be used.
      // fromObject = new Array(fromObject);
    }

    // replace the output document name with the associated output variable
    // ie, if outputname.property where outputname is message.body, update the array to be message.body.property
    if (isRootLevel) {
      updateOutputSplit(outputSplit);
    }

    // attempt to get the desired output property from the output document
    var obj = getProperty(outputSplit, outputDocument, isRootLevel, false);
    var objExisted = true;

    // desired output property doesn't exist OR it does but is not an array, then create this output
    // property as an initial empty array (potentially overwriting a perviously mapped non array)
    if (obj === undefined || util.safeTypeOf(obj) !== 'array') {
      objExisted = false;
      obj = [];
    }

    // iterate thru the input data array if we have one or if the toggle indicates we should step into the child actions
    // even though we have no input data
    if (fromObject[0] !== undefined || rawMapEmptyJSONArraysToggle === 'all') {
      // for every object in the from document, process each from array element and its associated output array element
      for (var j=0; j < numberOfNewElements; j++) {
        if (verbose) dbglog.debug(logPrefix + "create action - input sub-object to process: ", fromObject[j]);
        var newArrayElement = {};
        var returnedResultSubAction = ProcessMappingRules(rlactions, fromObject[j], newArrayElement, false, isOutputXML); // recursing, not root level
        if (returnedResultSubAction) {
          newArrayElement = returnedResultSubAction;
        }
        // normally push the result into our output array.
        // Don't push empty result objects when this is the only element of a one iteration mapping to an empty array.
        if(obj.length !== 0 ||
           numberOfNewElements > 1 ||
           util.safeTypeOf(newArrayElement) !== 'object' ||
           Object.keys(newArrayElement).length > 0) {
          obj.push(newArrayElement);
        }
      }
    }

    // if the array didn't exist before we need to add it to the output document, but don't put empty arrays for XML output
    // even for JSON output, the empty array toggle will determine if the emtpy JSON array is output.
    if (!objExisted && (obj.length > 0 || (!isOutputXML && rawMapEmptyJSONArraysToggle !== 'none'))) {
      returnedResult = setOutput(aCreateRule.create, obj, outputDocument, isRootLevel, isOutputXML);
    }
  } else {
    dbglog.error(logPrefix + 'create action ' + aCreateRule.create + ': missing subactions, action ignored.');
  }
  if (returnedResult) {
    return returnedResult;
  }
}
////////////////////////////////////////////////////////////////////////////////////
function decodeRequestParameters(data) {
    for (var param in data) {
      if (data.hasOwnProperty(param)) {
        if (data[param] !== undefined && data[param] !== null) {
            data[param] =  decodeURIComponent(data[param]);
        }
      }
    }
    return data;
}

function getProperty(targetSplit, document, isRootLevel, isInputSearch) {
  // undefined input provides an undefined property search unless we're getting an absolute reference
  if (document === undefined && !(targetSplit[0] && startsWith(targetSplit[0], '#/'))) return;

  // if this is the root level, then the first element of the targetSplit is the property within the input vector object.
  var obj, tempObj;
  var caseInsensitivity = false;

  // Although this may not be a root level action, a #/ at the beginning of the from or foreach property name indicates
  // absolute pathing which must be treated like a root level action.  Set the search document to the overall input document,
  // indicate that it is a root level request and drop the #/ from the first part of the from variable.  The first split of
  // a root level request must be an input document name.
  if (targetSplit[0] && startsWith(targetSplit[0], '#/')) {
    document = inputContentVector;
    isRootLevel = true;
    targetSplit[0] = targetSplit[0].slice(2);
  }

  if (isRootLevel) {
    obj = document[targetSplit[0]];
    // for input searches only, see if the desired input is a headers context that would require a case insensitive lookup
    if (isInputSearch) {
      // make sure it is this a get of an input property
      var input = policyProperties.inputs[targetSplit[0]];
      if (input) {
        // only for an input for <context>.headers would we need a case insensitive lookup
        var variableSplit = customSplit(input.variable);
        if (variableSplit && variableSplit[1] && variableSplit[1] === 'headers') {
          caseInsensitivity = true;
        }
      }
    }
  } else {
    obj = document;
    if (targetSplit[0] == "$item") {
      targetSplit.shift();
    }
  }

  if (obj !== undefined) {
    // Now search the proper document for the path specified
    for (var i=(isRootLevel ? 1 : 0); i < targetSplit.length; i++) {
      if (util.safeTypeOf(obj) === 'array') {
        // if the array has objects, find all array element objects that match the current property we're evaluating
        if (util.safeTypeOf(obj[0]) === 'object') {
          if (mapArrayFirstElementToggle) {
            // if the API array toggle is enabled, only return the first element of the array, not the entire array
            // this will mimic prior behavior.  This toggle will default to false, so only those APIs that want the
            // old behavior will be required to add this toggle.
            tempObj = obj[0][targetSplit[i]];
          } else { // no toggle
            tempObj = [];
            for (var j=0; j<obj.length; j++) {
              var arrayElement = obj[j][targetSplit[i]];
              if (arrayElement !== undefined) {
                tempObj = tempObj.concat(arrayElement);
              }
            }
            if( tempObj.length === 0) {
              // #1616: return undefined, rather than an empty array, if no matching properties found
              tempObj = undefined;
            }
          }
        } else { // not an object
          // array of scalar or child arrays, just get the particular element.  This will support the .0 type
          // of syntax.
          tempObj = obj[targetSplit[i]];
        }
      } else {
        // non-array, just get the particular element
        tempObj = obj[targetSplit[i]];
      }

      // case sensitive lookup if it failed and we should do a case insensitive loopup??
      if (tempObj === undefined && caseInsensitivity && util.safeTypeOf(obj) !== 'array') {
        // get the keys of the current object comma separated and see if we can find the desired key
        var regex = new RegExp('(' + targetSplit[i] + ')','i');
        var objectKeys = ',' + Object.keys(obj).toString() + ',';
        var objMatch = objectKeys.match(regex);
        // match[0] will have the match string, match[1] the key (from the regexp parenthized subexpression) we want
        if (objMatch && objMatch[1]) {
          // lookup the actual object name to get the value
          obj = obj[objMatch[1]];
        } else {
          // no match, then object is not found
          obj = tempObj;
        }
      } else {
        // object is either found or not found but no futher case insensitive search
        obj = tempObj;
      }
      if (obj === undefined) break;
    }
  }
  return obj;
}

function setOutput(target, outputValue, outputDocument, isRootLevel, isOutputXML) {

  var returnedResult = undefined;
  var outputSplit = customSplit(target.toString());
  var outputObject = {};
  var obj = outputObject;

  // root level will have the first outputSplit array item as the name of the output.
  // this will be removed and the associated variable added to the beginning of the array
  if (isRootLevel) {
    updateOutputSplit(outputSplit);
  }

  // do we have an outputValue and is it not a function object?
  if ((outputValue || outputValue == 0) && util.safeTypeOf(outputValue) != 'function') {
    // if the target ouput is XML and we are injecting a scalar value and the last element
    // of the output path is not a $ (ie, already provided on the set), and the last element
    // doesn't start with an @ (designates an XML attribute which is fine as is), then inject it
    if (isOutputXML && util.safeTypeOf(outputValue) != 'object' &&
        util.safeTypeOf(outputValue) != 'array' && outputSplit[outputSplit.length-1] != '$' &&
        !startsWith(outputSplit[outputSplit.length-1], '@')) {
      outputSplit[outputSplit.length] ='$';
    }

    // $item means the current item and is not an object name so remove it
    if (outputSplit[0] == "$item") {
      outputSplit.shift();
    }

    // special case where we map directly input to output
    if (outputSplit.length == 0) {
      returnedResult = outputValue;
    } else {
      // create an object based on the target string whose leaf value is the outputValue
      for (var i=0; i < outputSplit.length; i++) {
        if (i < outputSplit.length-1) {
          obj[outputSplit[i]] = {};
          obj = obj[outputSplit[i]];
        } else {
          Object.defineProperty(obj, outputSplit[i], {value: outputValue, writable: true, enumerable: true, configurable: true });
        }
      }

      // take the outputObject and inject it into the outputDocument
      try {
        var outputObjKeys = Object.keys(outputObject);
        for (var i = 0; i < outputObjKeys.length; i++) {
          var obj = {};
          obj[outputObjKeys[i]] = outputObject[outputObjKeys[i]];
          traverseOutput(outputDocument, obj);
        }
      } catch (err) {
        dbglog.error(logPrefix + 'setOutput error adding ' + target , ': ' + outputObject);
      }
    }
  } else {
    // either the output Value was undefined or illegal (a function object)
    dbglog.error(logPrefix + 'setOutput error adding '  + target , ': value is ' + (outputValue ? 'function ' + outputValue.name : outputValue));
  }
  return returnedResult;
}

////////////////////////////////////////////////////////////////////////////////////


function traverseOutput(o, setObj) {

  if( util.safeTypeOf(setObj) !== "object") {
        // can't do anything if setObj is not an object
    return;
  }

  var keys = Object.keys(setObj);
  for( var i = 0; i < keys.length; ++i) { // each property of setObj
    var property = keys[i];
    if( property) {

      if( o.hasOwnProperty(property) &&
          util.safeTypeOf( o[property]) === 'object' && Object.keys( o[property]).length > 0 &&
          util.safeTypeOf( setObj[property]) === 'object') {

          // property in o is a non-empty object, and property in setObj is an object,
          // so recurse

        traverseOutput(o[property], setObj[property]);

      } else {

          // add or overwrite property in o with value from setObj

        Object.defineProperty(o, property, {value: setObj[property], writable: true, enumerable: true, configurable: true });

      }
    }
  }
}


function updateOutputSplit(outputSplit) {
  // root level, output name is first, so use it got the the output variable definition
  var output = policyProperties.outputs[outputSplit[0]];
  if (output) {
    var variable = output.variable;
    if (variable) {
      // output variable will be <context>.<body|headers|status>[.optional.subkeys]
      var variableSplit = customSplit(variable);

      // the set or create will be of the form outputname.[1..n properties].  remove the output name from the array
      outputSplit.shift();

      // build new outputSplit that is of the form [output variable elements, rest of the target elements]
      for (var i=0; i<variableSplit.length; i++) {
        outputSplit.splice(i, 0, variableSplit[i]);
      }
    } else {
      throw new Error('Map: output ' + outputSplit[0] + ' named in action does not have a variable definition');
    }
  } else {
    throw new Error('Map: output ' + outputSplit[0] + ' named in action does not exist');
  }
}

////////////////////////////////////////////////////////////////////////////////////////
/*
 * Wrapper to eval(). This will disable sensitive modules before invoking the actual eval().
 * Note: This wrapper is duplicated in three files apim.policy.gatewayscript.js,
 * apim.conditional.js and apim.map.js as it not exportable.
 *
 * */
function evalSafe(expr, __fromArray__, __result__)
{
  var _require = require;
  return (function(){
    var require = function(mod) {
      if (mod === 'mgmt')
        throw new Error("Error: Cannot find module 'mgmt'");
      if (mod === 'multistep')
        throw new Error("Error: Cannod find module 'multistep'");
      if (mod === 'fs')
        throw new Error("Error: Cannot find module 'fs'");
      if (mod === 'service-metadata')
        throw new Error("Error: Cannot find module 'service-metadata'");
      return _require(mod);
    };
    return eval(expr);
  })();
}

//function copied from the /isp/apim.util.js module to run locally as v6 will not provide these
//functions in the compatiblity module
function escapeXML( string ){

  var entityMap = {
    "\"":"&quot;",
    "\'":"&apos;",
    "<":"&lt;",
    ">":"&gt;",
    "&":"&amp;"
  };

  function mapper(match, offset, string) {
    return entityMap[match];
  }

  if (string && typeof string === 'string') {
    string = string.replace(/\"|\'|<|>|&/g, mapper);
  }
  return string;
}
