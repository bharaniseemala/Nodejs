// ***************************************************** {COPYRIGHT-TOP} ***
//* Licensed Materials - Property of IBM
//* 5725-L30
//*
//* (C) Copyright IBM Corporation 2016
//*
//* US Government Users Restricted Rights - Use, duplication, or
//* disclosure restricted by GSA ADP Schedule Contract with IBM Corp.
// ********************************************************** {COPYRIGHT-END}**

var apim = require('local:///isp/policy/apim.custom.js');
var apimUtils = require('local:///isp/apim.util.js');

exports.getScopesForApiEndpoint = function () {
  return getPropertyFromPolicy('scopes');
}

exports.getMfpProviderAuthorizationUrl = function () {
  return getPropertyFromPolicy('azserver');
}

exports.getMfpProviderClientId = function () {
  return getPropertyFromPolicy('confClientID');
}

exports.getMfpProviderClientSecret = function () {
  return getPropertyFromPolicy('confClientPass');
}

exports.getMfpProviderName = function () {
  return getPropertyFromPolicy('mfpProviderName');
}

exports.getTlsProfile = function () {
  var tlsProfile = getPropertyFromPolicy('tlsProfile');
  var customSSLProfile = '';
  if (tlsProfile !== undefined && tlsProfile.length > 0) {
      customSSLProfile = apim.getTLSProfileObjName(tlsProfile);
  } else {
      // The profile has not been defined get and use the default
      customSSLProfile = apim.getTLSProfileObjName();
  }

  if (customSSLProfile !== undefined && customSSLProfile.indexOf('client:') == 0) {
    customSSLProfile = customSSLProfile.substr(7);
  }

  return customSSLProfile;
}

exports.getInternalWebApiIp = function () {
  var deployInfo = apimUtils.loadDeployInfo();
  var internalIp = deployInfo.endpoints['loopback-ip']; // e.g. '127.91.225.178'

  return internalIp;
}

exports.getInternalWebApiPort = function () {
  var deployInfo = apimUtils.loadDeployInfo();
  var internalPort = deployInfo ? parseInt(deployInfo.endpoints['base-port']) + 1 : 2444;
  return internalPort;
}


exports.getHttpReason = function (httpCode) {
	// TODO add defaut case for general eror ??
  if (httpCode == 200) {
		return 'OK';
	} else if (httpCode == 401) {
		return 'Unauthorized';
	} else if (httpCode == 403) {
		return 'Forbidden';
	} else if (httpCode == 400) {
		return 'Bad Request';
	} else if (httpCode == 409) {
		return 'Conflict';
	} else if (httpCode == 500) {
		return 'Internal Server Error';
	} else{
    return 'Internal Server Error';
  }
    
}

function getPropertyFromPolicy(propertyName) {
  let properties = getPolicyProperties();
  let propertiesJson = JSON.stringify(properties);
  let proertyValue = properties[propertyName];

  return proertyValue;
}


function getPolicyProperties() {
  let mfpOrSecDefFlowCtx = session.name('mfpOrSecDefFlowCtx');

  //properties object is like {"title":"security-oauth2-validate-mfp","authorizationUrl":"http://liorlu-tp.haifa.ibm.com:9080/mfp","scopes":"usernamePassword"}
  let policyProperteis;
  if (mfpOrSecDefFlowCtx) {
    policyProperteis = mfpOrSecDefFlowCtx.getVar("mfpOrSecDefCurrentPolicy");
  }
  else {
    policyProperteis = apim.getPolicyProperty();
  }

  return policyProperteis;
}

var util = require('util');

exports.isString = function(v) {
  return util.safeTypeOf(v) == 'string';
};

exports.isNumber = function(v) {
  return util.safeTypeOf(v) == 'number';
};

exports.isBoolean = function(v) {
  return util.safeTypeOf(v) == 'boolean'
};

exports.isDate = function(v) {
  return util.safeTypeOf(v) == 'date';
}

exports.isObject = function(v) {
  return util.safeTypeOf(v) == 'object';
}

exports.isArray = function(v) {
  return util.safeTypeOf(v) == 'array';
};

exports.isNull = function(obj) {
    return obj === null;
};

exports.isUndefined = function(obj) {
    return obj === undefined;
};

exports.isEmpty = function(obj) {
  // TODO need to implement carefully
  return isUndefined(obj) && isUndefined(obj);
};
