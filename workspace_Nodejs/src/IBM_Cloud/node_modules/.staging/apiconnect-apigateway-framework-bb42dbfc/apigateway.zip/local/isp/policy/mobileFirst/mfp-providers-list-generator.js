// ***************************************************** {COPYRIGHT-TOP} ***
//* Licensed Materials - Property of IBM
//* 5725-L30
//*
//* (C) Copyright IBM Corporation 2016
//*
//* US Government Users Restricted Rights - Use, duplication, or
//* disclosure restricted by GSA ADP Schedule Contract with IBM Corp.
// ********************************************************** {COPYRIGHT-END}**

var apimutil = require('local:///isp/apim.util.js');
var mfpProvidersManager = require('local:///isp/policy/mobileFirst/mfp-providers-manager');
var hm = require('header-metadata');
var sm = require('service-metadata');

sm.mpgw.skipBackside = true;
var target = hm.current.get('x-mfp-catalog-url');
if (target == undefined) {
  //catalog url not passed in correctly, bail out
  returnFailureResponse();
  return;
}
var deployInfo = apimutil.loadDeployInfo();
var productsURL = target + '/missing/deploy/info';
var swaggerURL = target + '/missing/deploy/info';
var postfix = '?type=edge-gateway';
var clusterId = 'id:onpremi:cluster';  // just set the default to that used in onpremi tests
var internalPort = deployInfo ? parseInt(deployInfo.endpoints['base-port']) + 1 : 2444;
if (deployInfo) {
  productsURL = target + deployInfo.endpoints['products-suffix'] + postfix;
  swaggerURL = target + deployInfo.endpoints['swagger-suffix'] + postfix;
  if (deployInfo.gateway && deployInfo.gateway['cluster-id']) {
      clusterId = deployInfo.gateway['cluster-id'];
  }
}

var headers = hm.current.headers;
var products;
var apis;
try {
  apimutil.getDocument(productsURL, headers, function (err, json) {
    if (!json) {
      returnFailureResponse();
    }
    else {
      products = json;
      apimutil.getDocument(swaggerURL, headers, function (err, json) {
        if (!json) {
          returnFailureResponse();
        }
        else {
          apis = json;
          var mfpProivdersConfig = mfpProvidersManager.createMfpProviderConfig(apis, products);
          returnSuccessfulResponse(mfpProivdersConfig);
        }
      });
    }
  });
} catch (err) {
    returnFailureResponse();
}

function returnSuccessfulResponse(jsonResponse) {
  hm.response.statusCode = 200;
  session.output.write(jsonResponse);
}

function returnFailureResponse() {
  hm.response.statusCode = 500;
  session.output.write("");
}
