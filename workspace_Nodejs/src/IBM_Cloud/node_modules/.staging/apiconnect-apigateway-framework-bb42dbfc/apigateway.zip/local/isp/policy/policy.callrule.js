// ***************************************************** {COPYRIGHT-TOP} ***
//* Licensed Materials - Property of IBM
//* 5725-L30, 5725-Z22, 5725-Z63, 5725-U33
//*
//* (C) Copyright IBM Corporation 2016, 2017
//*
//* US Government Users Restricted Rights - Use, duplication, or
//* disclosure restricted by GSA ADP Schedule Contract with IBM Corp.
// ********************************************************** {COPYRIGHT-END}**
//
var apim = require('local:///isp/policy/apim.custom.js');
var multistep = require('multistep');
var headersmd = require('header-metadata');
var poSession = session.name('policy');
var apiSession = session.name('api');
var verbose = apim.verbose;

var ruleName = poSession.getVar('fw/call-rule');
var sourceName = poSession.getVar('fw/source');

//@@ For tracing purposes, keep a count of these rules we kicked off
var position = poSession.getVar('fw/call-rule-count') | 0;
poSession.setVar('fw/call-rule-count', position + 1);

//@@ For logging purposes.
var logPrefix = 'policy.callrule[' + position + '] ' + ruleName;
if (sourceName) {
  logPrefix += '[' + sourceName + ']';
}

//@@ Before we kick of this next rule, we peek at the properties
//@@ of the next policy, if we find $(request.body) or $(message.body)
//@@ to be dereferenced, load them into the context.
var policyProperties = apim.getPolicyPropertyAsEntered();
var policyPropertiesString = JSON.stringify(policyProperties);

if (policyPropertiesString && (policyPropertiesString.indexOf('$(message.body)') > -1 || policyPropertiesString.indexOf('message.body') > -1)) {
  apim.readInput(function(error,messageBody) {
    if(verbose) apim.console.debug('callrule: messageBody: ' + JSON.stringify(messageBody));
    if (!error) {
      apim.setvariable('message.body',messageBody, 'save');
    }
    main();
  });
}
else {
  main();
}

//@@ Main
function main() {
  if(verbose) apim.console.debug(logPrefix + ' starting');
  multistep.callRule(ruleName, session.input, session.output, function (err) {
    if (err) {
      apim.console.error(logPrefix + ': error: ' + JSON.stringify(err));
      // comment out endWithError() here, as the task will be done by new Action.
      // endWithError(err.errorMessage);
    }
    else {
      if(verbose) apim.console.debug(logPrefix + ' done');
      // comment out policyFinished() here, as the task will be done by new Action.
      // policyFinished();
    }
  });
}

//@@ Convenience function that reads the variables set by error_template.xsl
//@@ honoring and keeping their values. When they are not available, the
//@@ default 500 Internal Server is returned.

function endWithError(message) {
  if(verbose) apim.console.debug(logPrefix + ": exception-uncaught: " + session.name('policy').getVar('flow/exception-uncaught'));
  var httpCode   = apiSession.getVar('error-protocol-response');
  var httpReason = apiSession.getVar('error-protocol-reason-phrase');
  var errorName  = apiSession.getVar('error-name');
  var errorMessg = apiSession.getVar('error-message');
  var ignorecatch= apiSession.getVar('ignore-catch');
  if(verbose) {
    apim.console.debug('endWithError: HTTP ' + httpCode + ' ' + httpReason);
    apim.console.debug('endWithError: ERRR ' + errorName + ' ' + errorMessg);
    apim.console.debug('endWithError: ignorecatch ' + ignorecatch);
  }

  //@@ if policy didn't set httpCode, check for AAA Authentication failure
  if (!httpCode || httpCode.length === 0) {
    var servicemeta = require('service-metadata'); 
    var svcErrorSubcode = servicemeta.errorSubcode;
    if (verbose) {
      apim.console.debug('endWithError: SUBC ' + svcErrorSubcode);
    }
    if (svcErrorSubcode === '0x01d30001') { // AAA Authentication Failure
      httpCode = '401';
      httpReason = 'Unauthorized';
      errorName  = 'Authentication Failure';
      errorMessg = 'This server could not verify that you are authorized to access the URL';
    }
  }

  //@@ still unknown reason, 500 Internal Server Error it is.
  if (!httpCode || httpCode.length === 0) {
    httpCode = '500';
    httpReason = 'Internal Server Error';
  }

  //@@ do not have a name for this exception?
  if (!errorName|| errorName.length === 0) {
    var errs = require('local:///isp/policy/apim.exception.js'); 
    errorName = errs.Errors.RuntimeError;
  }

  if ((errorMessg === undefined || errorMessg.length === 0) && message.indexOf('xsl:message terminate=yes') === -1) {
    errorMessg = message;
  }
  
  if (ignorecatch === undefined)
    ignorecatch = false;

  apim.error(errorName, httpCode, httpReason, errorMessg, ignorecatch);
}

//@@
//@@  policyFinished
//@@
//@@  Execution of this policy terminated. If the policy wrote anything, it was written to the
//@@  'policy-output-temp' named context, and needs to copied to `policy-output`.
//@@
//@@  In the case of JSONx output that must be converted to JSON, this conversion
//@@  is done in 'apim.policy.handle.payload.xsl', copying the JSON to 'policy-output'
//@@
function policyFinished() {
  var _apimgmt = session.name('_apimgmt');
  var outputChanged = _apimgmt.getVar('policy-output-set') === 'true';
  if(verbose) apim.console.debug(logPrefix + ' finished. Output changed: ' + outputChanged);
  if (outputChanged) {
    var policyOutput = session.name('policy-output');
    if (policyOutput === undefined) {
      policyOutput = session.createContext('policy-output');
    }
    session.name('policy-output-temp').readAsBuffer(function(error,buffer){

      _apimgmt.setVar('use-policy-output','true');
      _apimgmt.setVar('policy-output-set','false');
      if (_apimgmt.getVar('policy-output-mediaType') === 'unknown') {
        var ctype = headersmd.current.get('content-type');
        if (ctype) {
          _apimgmt.setVar('policy-output-mediaType',ctype);
          if(verbose) apim.console.debug(logPrefix + ' setting media type to ' + ctype);
        }
      }

      if (apim.isXML(_apimgmt.getVar('policy-output-mediaType')))
      {
          try {
              policyOutput.write(XML.parse(buffer));
          } catch (err) {
              apim.console.error("Error parsing as XML.");
              endWithError(err.errorMessage);  
          }
      } else {
          policyOutput.write(buffer);
      }

      if (verbose) {
        policyOutput.readAsBuffer(function (err, buffer) {
          apim.console.debug(logPrefix + ' finished: output: ' + buffer.toString());
        });
      }
    });
  }
}

