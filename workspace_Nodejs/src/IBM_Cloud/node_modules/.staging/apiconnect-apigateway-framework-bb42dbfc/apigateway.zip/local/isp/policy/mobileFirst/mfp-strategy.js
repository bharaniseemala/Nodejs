// ***************************************************** {COPYRIGHT-TOP} ***
//* Licensed Materials - Property of IBM
//* 5725-L30
//*
//* (C) Copyright IBM Corporation 2016
//*
//* US Government Users Restricted Rights - Use, duplication, or
//* disclosure restricted by GSA ADP Schedule Contract with IBM Corp.
// ********************************************************** {COPYRIGHT-END}**

var hm = require('header-metadata');
var urlopen = require('urlopen');
var sm = require('service-metadata');
var mfpApicUtils = require('local:///isp/policy/mobileFirst/util/mfp-apic-utils');

var SecurityLogger = require('local:///isp/policy/mobileFirst/util/security-logger'),
tokenValidator = require("local:///isp/policy/mobileFirst/util/mfp-token-validator"),
Constant = require('local:///isp/policy/mobileFirse/util/constant');
// Note mfp-analytics is partial/less efficient implemention of './analytics-sdk-node/analytics-sdk-node.js' NodeJs Module
// Analytics-TODO  var Analytics = require('local:///isp/policy/mobileFirst/util/mfp-analytics');  // + add implemenation for APIC

function Strategy(options) {    
    this.mfpProviderName = options && options.mfpProviderName;
    this.authServerUrl = options && options.authServerUrl;
    this.confClientID = options && options.confClientID;
    this.confClientPass = options && options.confClientPass;
    this.scope = options && options.scope;
    this._verify = tokenValidator.validate;
    this.options = options;
    var that = this;
    
    if (options && options.certificate) {
       that.certificate = options.certificate; 
    }

    /* Analytics-TODO
    if (options && options.analytics) {
        this.analytics = new Analytics(options.analytics);
        // add message was successfuly loaded
    } else {
        SecurityLogger.error("Analtycs wasn't configured - off");
    }
    */  
    
    return this;
}

Strategy.prototype.authenticate = function(req) {
    var strategy = this;
    
    if (!strategy.authServerUrl) {
        SecurityLogger.error("MobileFirst server url must be configured");
        return this.fail(500, Constant.AUTHORIZATION_FAILED_INTERNAL_SERVER_ERROR, Constant.AUTHORIZATION_FAILED_INTERNAL_SERVER_ERROR_BEARER);
    }
    
    var authenticateOptions = {};    
    authenticateOptions.authServerUrl = strategy.authServerUrl;
    authenticateOptions.confClientID = strategy.confClientID;
    authenticateOptions.confClientPass = strategy.confClientPass;
    authenticateOptions.scope = strategy.scope;
    authenticateOptions.mfpProviderName = strategy.mfpProviderName;

    var authorization;
    if (req.headers && req.headers['Authorization']) {
        authorization = req.headers['Authorization'];
    }
    
    authenticateOptions.authorization = authorization;
    var startTime = Date.now();
    
    // Verifies whether the authentication succeeded.
    function verified(err, securityContext, info) {
        if (!securityContext) {
            /* Analytics-TODO
            if (strategy.analytics) {
                strategy.analytics.sendFailureEvent(info, startTime);            
            }
            */
            try{
                strategy.fail(info.status, info.code, getChallenge(info.code,info.scope));
            }
            catch(error){
                SecurityLogger.error("Unexpected erorr occured while validating client token");
                // prevent from bubbling up the exception to mfp-token-validator catch because it will call again the same flow (callback of done function)
                strategy.fail(500, Constant.AUTHORIZATION_FAILED_INTERNAL_SERVER_ERROR, Constant.AUTHORIZATION_FAILED_INTERNAL_SERVER_ERROR_BEARER);
            }
        }
        else{
            /* Analytics-TODO + add implemenation for successful flow
           if (strategy.analytics) {
                //the securityContext has value, represents validation successfully. Otherwise, failed.
                strategy.analytics.storeSecurityContextForResponseRule(securityContext, startTime);
            }
            */

            strategy.success();         
        }

    }
    
    strategy._verify(authenticateOptions, verified);
};


Strategy.prototype.fail = function(httpCode, reason, wwwauthenticateValue) {
    SecurityLogger.debug("token wasn't successfully introspected");
    httpCode = decideOnErrorResponseCode(httpCode, wwwauthenticateValue);
    let errorMessage = decideOnErrorResponseMessage(httpCode);    
    
    // Stopping the message routing between policies
    updateHttpResponseInformation(httpCode, errorMessage, wwwauthenticateValue);
    updateApiContextForErrorResponse(httpCode, reason, errorMessage)

    session.reject(errorMessage);
}

Strategy.prototype.success = function() {
   SecurityLogger.debug('token was successfully introspected');
}

function updateHttpResponseInformation(httpCode, errorMessage, wwwauthenticateValue) {
    if(wwwauthenticateValue){
      hm.response.set('WWW-Authenticate', wwwauthenticateValue);
    }
    hm.response.statusCode = httpCode;
    hm.response.set('Content-Type', 'application/json');
    
    if (httpCode == 409) {
      hm.response.set(Constant.CONFLICT_HEADER, 'true');
    }
    
    session.output.write(errorMessage);
}

function decideOnErrorResponseMessage(httpCode){
      if(httpCode === 500){
         return 'Internal Server Error';
      }else{
         return 'This server could not verify that you are authorized to access the URL';
      }
}

function decideOnErrorResponseCode(httpCode, wwwauthenticateValue){
    let resHttpCode = httpCode;
    if (httpCode == 400 || httpCode == 401 || httpCode == 403) {
        resHttpCode = 401;        
        if (wwwauthenticateValue && wwwauthenticateValue.length>0) {
            var reg = /error="(\w*)"/;
            var t = wwwauthenticateValue.match(reg);
            var errCode = t && t.length>1 && t[1] || null;
            if (errCode) {
                if (errCode == Constant.AUTHORIZATION_FAILED_INVALID_REQUEST) {
                    resHttpCode = 400;
                }
                else if (errCode == Constant.AUTHORIZATION_FAILED_INVALID_TOKEN) {
                    resHttpCode = 401;
                }
                else if (errCode == Constant.AUTHORIZATION_FAILED_INSUFFICIENT_SCOPE) {
                    resHttpCode = 403;
                }
            } else {
                resHttpCode = 401;
            }
        }
    }
    
    if(!resHttpCode){
        // if there isn't resHttpCode it means that was some internal filter fatal exception - returns 500 to protect the API
        resHttpCode = 500;
    }

    return resHttpCode;
}

function updateApiContextForErrorResponse(httpCode, reason, errorMessage) {
    sm.mpgw.skipBackside = true;
    reason = mfpApicUtils.getHttpReason(httpCode); // TODO find way to avoid static mapping between httpCode to reason (like done in NodeFilter)
    
    // [TODO]: Trying to use local:///isp/policy/apim.custom.js - error(name,httpCode,httpReasonPhrase,message); didn't work and caused 500 'Internal Server Error'
    // local:///isp/policy/policy.callrule.js - endWithError() expects to apiSession variables which are set only later on local:///isp/policy/apim.policy.end.js 
    // Must set apiSession variables in order to stop APIC flow with the correct error code and reason
    // Follow hehavior of https://github.ibm.com/apimesh/apim/blob/master/datapower/xsl/policy/apim.policy.end.js
    let policySession = session.name('policy');
    let exception = policySession.getVariable('flow/exception');
    let apiSession = session.name('api');
    apiSession.setVar('error-protocol-response', httpCode);
    apiSession.setVar('error-protocol-reason-phrase', reason);
    apiSession.setVar('error-name', 'MFP-OAUTH-ERROR');
    apiSession.setVar('error-message', errorMessage);
    policySession.setVar('flow/exception-uncaught', true);

}

// Gets the challenge for WWW-Authenticate header.
function getChallenge(errCode,scope) {
    if (errCode == Constant.AUTHORIZATION_FAILED_MFP_SERVER_CONFLICT_RESPONSE) {
        // No WWW-Authenticate header is going to be added.
        return "";
    }
    var challenge = Constant.AUTHORIZATION_BEARER;
    if (errCode) {
        if (errCode == Constant.AUTHORIZATION_FAILED_MISSING_AUTHORIZATION) {
            return challenge;
        }
        challenge += ' error="' + errCode + '"';
        
        if (errCode == Constant.AUTHORIZATION_FAILED_INVALID_TOKEN) {
            return challenge;
        }
    }
    if (scope) {
        challenge += ', scope="' + scope + '"';
    }
    
    return challenge;
};

exports = module.exports = Strategy;
